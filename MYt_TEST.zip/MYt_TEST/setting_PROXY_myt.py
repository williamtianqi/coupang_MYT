#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
魔云腾设备完整代理设置脚本
自动连接设备、设置代理、启动Shopee、测试访问
"""

import subprocess
import time
import json
import sys
import os
import threading
import socket
import requests
from urllib.parse import urlparse

# 设备配置
DEVICE_IP = "192.168.8.104:5004"

# 代理配置
PROXY_CONFIGS = [
    {
        'name': 'Netnut-TW',
        'host': 'gw.netnut.net',
        'port': 5959,
        'username': 'Coupang-res-TW',
        'password': '6ypTfbQEqkr9ET6',
        'priority': 1,
        'region': 'Taiwan'
    },
    {
        'name': 'Rayobyte-TW',
        'host': 'la.residential.rayobyte.com',
        'port': 8000,
        'username': 'sam_kim_coupang',
        'password': 's1bmu1yu-country-TW',
        'priority': 2,
        'region': 'Taiwan'
    },
    {
        'name': 'Netnut-JP',
        'host': 'gw.netnut.net',
        'port': 5959,
        'username': 'Coupang-res-JP',
        'password': '6ypTfbQEqkr9ET6',
        'priority': 3,
        'region': 'Japan'
    },
    {
        'name': 'Netnut-KR',
        'host': 'gw.netnut.net',
        'port': 5959,
        'username': 'Coupang-res-KR',
        'password': '6ypTfbQEqkr9ET6',
        'priority': 4,
        'region': 'Korea'
    }
]

# Shopee测试URL
SHOPEE_TEST_URLS = [
    'https://shopee.tw',
    'https://shopee.tw/api/v4/pages/get_homepage_info',
    'https://mall.shopee.tw/api/v1/recommend'
]

class ProxyServer:
    """本地代理服务器，用于转发带认证的代理请求"""
    
    def __init__(self, local_port=8888):
        self.local_port = local_port
        self.proxy_config = None
        self.server = None
        self.running = False
    
    def set_upstream_proxy(self, proxy_config):
        """设置上游代理"""
        self.proxy_config = proxy_config
    
    def handle_request(self, client_socket):
        """处理代理请求"""
        try:
            # 接收客户端请求
            request_data = client_socket.recv(4096)
            if not request_data:
                return
            
            request = request_data.decode('utf-8', errors='ignore')
            lines = request.split('\n')
            if not lines:
                return
            
            # 解析请求行
            first_line = lines[0]
            method, url, protocol = first_line.split(' ', 2)
            
            # 如果是CONNECT方法（HTTPS）
            if method == 'CONNECT':
                self.handle_https_connect(client_socket, url)
            else:
                self.handle_http_request(client_socket, request)
        
        except Exception as e:
            print(f"处理请求错误: {e}")
        finally:
            try:
                client_socket.close()
            except:
                pass
    
    def handle_https_connect(self, client_socket, url):
        """处理HTTPS CONNECT请求"""
        try:
            # 解析目标主机和端口
            if ':' in url:
                host, port = url.split(':', 1)
                port = int(port)
            else:
                host, port = url, 443
            
            # 通过上游代理连接
            if self.proxy_config:
                proxy_url = f"http://{self.proxy_config['username']}:{self.proxy_config['password']}@{self.proxy_config['host']}:{self.proxy_config['port']}"
                
                # 这里简化处理，直接返回连接成功
                response = "HTTP/1.1 200 Connection Established\r\n\r\n"
                client_socket.send(response.encode())
                
                # 在实际应用中，这里需要建立到上游代理的连接并进行数据转发
                # 由于复杂性，这里只是基本实现
                
        except Exception as e:
            print(f"HTTPS CONNECT错误: {e}")
    
    def handle_http_request(self, client_socket, request):
        """处理HTTP请求"""
        try:
            lines = request.split('\n')
            first_line = lines[0]
            method, url, protocol = first_line.split(' ', 2)
            
            # 通过上游代理发送请求
            if self.proxy_config:
                proxies = {
                    'http': f"http://{self.proxy_config['username']}:{self.proxy_config['password']}@{self.proxy_config['host']}:{self.proxy_config['port']}",
                    'https': f"http://{self.proxy_config['username']}:{self.proxy_config['password']}@{self.proxy_config['host']}:{self.proxy_config['port']}"
                }
                
                response = requests.get(url, proxies=proxies, timeout=10)
                
                # 构造HTTP响应
                http_response = f"HTTP/1.1 {response.status_code} {response.reason}\r\n"
                for header, value in response.headers.items():
                    http_response += f"{header}: {value}\r\n"
                http_response += "\r\n"
                
                client_socket.send(http_response.encode())
                client_socket.send(response.content)
                
        except Exception as e:
            print(f"HTTP请求错误: {e}")
    
    def start(self):
        """启动代理服务器"""
        try:
            self.server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self.server.bind(('0.0.0.0', self.local_port))
            self.server.listen(10)
            self.running = True
            
            print(f"✅ 本地代理服务器启动在端口 {self.local_port}")
            
            while self.running:
                try:
                    client_socket, addr = self.server.accept()
                    client_thread = threading.Thread(
                        target=self.handle_request, 
                        args=(client_socket,)
                    )
                    client_thread.daemon = True
                    client_thread.start()
                except:
                    if self.running:
                        break
        except Exception as e:
            print(f"代理服务器启动失败: {e}")
    
    def stop(self):
        """停止代理服务器"""
        self.running = False
        if self.server:
            self.server.close()

class MagicCloudProxyManager:
    """魔云腾设备代理管理器"""
    
    def __init__(self, device_ip):
        self.device_ip = device_ip
        self.adb_prefix = f"adb -s {device_ip}"
        self.proxy_server = None
        self.current_proxy = None
    
    def run_adb_command(self, command, timeout=30):
        """执行ADB命令"""
        try:
            full_command = f"{self.adb_prefix} {command}"
            print(f"执行: {full_command}")
            
            result = subprocess.run(
                full_command, 
                shell=True, 
                capture_output=True, 
                text=True, 
                timeout=timeout
            )
            
            return result.returncode == 0, result.stdout.strip(), result.stderr.strip()
        except subprocess.TimeoutExpired:
            return False, "", "命令执行超时"
        except Exception as e:
            return False, "", str(e)
    
    def connect_device(self):
        """连接魔云腾设备"""
        print(f"🔌 连接魔云腾设备: {self.device_ip}")
        
        # 先断开可能存在的连接
        subprocess.run(f"adb disconnect {self.device_ip}", shell=True, capture_output=True)
        
        # 连接设备
        result = subprocess.run(f"adb connect {self.device_ip}", shell=True, capture_output=True, text=True)
        
        if "connected" in result.stdout.lower() or "already connected" in result.stdout.lower():
            print(f"✅ 设备连接成功: {self.device_ip}")
            
            # 验证设备状态
            success, stdout, stderr = self.run_adb_command("shell echo 'test'")
            if success and "test" in stdout:
                print("✅ 设备状态正常")
                return True
            else:
                print(f"❌ 设备状态异常: {stderr}")
                return False
        else:
            print(f"❌ 设备连接失败: {result.stdout}")
            return False
    
    def test_proxy_directly(self, proxy_config):
        """直接测试代理可用性"""
        print(f"🧪 测试代理: {proxy_config['name']}")
        
        proxy_url = f"http://{proxy_config['username']}:{proxy_config['password']}@{proxy_config['host']}:{proxy_config['port']}"
        proxies = {
            'http': proxy_url,
            'https': proxy_url
        }
        
        test_results = []
        
        for url in SHOPEE_TEST_URLS:
            try:
                start_time = time.time()
                response = requests.get(
                    url, 
                    proxies=proxies, 
                    timeout=15,
                    headers={'User-Agent': 'Mozilla/5.0 (Linux; Android 10; SM-G975F) AppleWebKit/537.36'}
                )
                end_time = time.time()
                
                success = response.status_code in [200, 302, 301, 403]  # 403也算成功(被限制但可达)
                response_time = round((end_time - start_time) * 1000)
                
                test_results.append({
                    'url': url,
                    'success': success,
                    'status_code': response.status_code,
                    'response_time': response_time
                })
                
                status = "✅" if success else "❌"
                print(f"  {status} {url} - {response.status_code} ({response_time}ms)")
                
            except Exception as e:
                test_results.append({
                    'url': url,
                    'success': False,
                    'error': str(e)
                })
                print(f"  ❌ {url} - 错误: {str(e)}")
        
        success_count = sum(1 for r in test_results if r.get('success', False))
        success_rate = success_count / len(test_results)
        
        print(f"代理成功率: {success_rate*100:.0f}% ({success_count}/{len(test_results)})")
        
        return success_rate > 0.5, test_results
    
    def setup_local_proxy_server(self, proxy_config):
        """设置本地代理服务器"""
        print(f"🔧 设置本地代理服务器...")
        
        # 停止现有服务器
        if self.proxy_server:
            self.proxy_server.stop()
        
        # 创建新的代理服务器
        self.proxy_server = ProxyServer(local_port=8888)
        self.proxy_server.set_upstream_proxy(proxy_config)
        
        # 在后台启动代理服务器
        server_thread = threading.Thread(target=self.proxy_server.start)
        server_thread.daemon = True
        server_thread.start()
        
        time.sleep(2)  # 等待服务器启动
        
        # 获取本机IP
        try:
            result = subprocess.run("ipconfig", shell=True, capture_output=True, text=True)
            if "IPv4" in result.stdout:
                # Windows
                for line in result.stdout.split('\n'):
                    if "IPv4" in line and "192.168" in line:
                        local_ip = line.split(':')[-1].strip()
                        break
            else:
                # 备用方法
                import socket
                s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                s.connect(("8.8.8.8", 80))
                local_ip = s.getsockname()[0]
                s.close()
        except:
            local_ip = "192.168.8.100"  # 默认IP
        
        print(f"✅ 本地代理服务器已启动: {local_ip}:8888")
        return local_ip
    
    def set_device_proxy(self, proxy_host, proxy_port):
        """设置设备代理"""
        print(f"🔧 设置设备代理: {proxy_host}:{proxy_port}")
        
        commands = [
            f"shell settings put global http_proxy {proxy_host}:{proxy_port}",
            f"shell settings put global global_http_proxy_host {proxy_host}",
            f"shell settings put global global_http_proxy_port {proxy_port}",
            "shell settings put global global_http_proxy_exclusion_list ''",
        ]
        
        for cmd in commands:
            success, stdout, stderr = self.run_adb_command(cmd)
            if not success:
                print(f"❌ 设置失败: {cmd} - {stderr}")
                return False
        
        print("✅ 设备代理设置成功")
        return True
    
    def restart_network(self):
        """重启网络服务"""
        print("🔄 重启网络服务...")
        
        # 方法1: 重启WiFi
        self.run_adb_command("shell svc wifi disable")
        time.sleep(2)
        self.run_adb_command("shell svc wifi enable")
        time.sleep(3)
        
        # 方法2: 重启网络管理器
        self.run_adb_command("shell am force-stop com.android.systemui")
        time.sleep(1)
        
        print("✅ 网络服务重启完成")
    
    def clear_proxy(self):
        """清除代理设置"""
        print("🧹 清除代理设置...")
        
        commands = [
            "shell settings delete global http_proxy",
            "shell settings delete global global_http_proxy_host",
            "shell settings delete global global_http_proxy_port",
        ]
        
        for cmd in commands:
            self.run_adb_command(cmd)
        
        print("✅ 代理设置已清除")
    
    def install_shopee_if_needed(self):
        """检查并安装Shopee应用"""
        print("📱 检查Shopee应用...")
        
        # 检查是否已安装
        success, stdout, stderr = self.run_adb_command("shell pm list packages | grep shopee")
        
        if "com.shopee.tw" in stdout:
            print("✅ Shopee TW 已安装")
            return True
        elif "com.shopee" in stdout:
            print("✅ Shopee 已安装")
            return True
        else:
            print("❌ Shopee 未安装")
            print("请手动安装Shopee应用或提供APK文件")
            return False
    
    def launch_shopee(self):
        """启动Shopee应用"""
        print("🛒 启动Shopee应用...")
        
        # 尝试不同的包名
        shopee_packages = [
            'com.shopee.tw',
            'com.shopee.id',
            'com.shopee.sg',
            'com.shopee'
        ]
        
        for package in shopee_packages:
            success, stdout, stderr = self.run_adb_command(f"shell monkey -p {package} -c android.intent.category.LAUNCHER 1")
            if success:
                print(f"✅ Shopee启动成功: {package}")
                time.sleep(3)
                return True
        
        print("❌ Shopee启动失败")
        return False
    
    def test_shopee_access(self):
        """测试Shopee访问"""
        print("🧪 测试Shopee访问...")
        
        test_results = []
        
        for url in SHOPEE_TEST_URLS:
            success, stdout, stderr = self.run_adb_command(f"shell curl -s -o /dev/null -w '%{{http_code}}' --connect-timeout 10 {url}")
            
            if success and stdout:
                status_code = stdout.strip()
                success_status = status_code in ['200', '302', '301', '403']
                test_results.append({
                    'url': url,
                    'success': success_status,
                    'status_code': status_code
                })
                
                status = "✅" if success_status else "❌"
                print(f"  {status} {url} - {status_code}")
            else:
                test_results.append({
                    'url': url,
                    'success': False,
                    'error': stderr
                })
                print(f"  ❌ {url} - 连接失败")
        
        success_count = sum(1 for r in test_results if r.get('success', False))
        success_rate = success_count / len(test_results)
        
        print(f"Shopee访问成功率: {success_rate*100:.0f}% ({success_count}/{len(test_results)})")
        
        return success_rate > 0.5
    
    def get_device_ip(self):
        """获取设备IP地址"""
        success, stdout, stderr = self.run_adb_command("shell ip route | grep wlan0")
        if success:
            print(f"设备网络信息: {stdout}")
    
    def setup_proxy_complete(self, proxy_config):
        """完整的代理设置流程"""
        print(f"\n🚀 开始为设备设置代理: {proxy_config['name']}")
        print("=" * 60)
        
        # 1. 测试代理可用性
        proxy_working, test_results = self.test_proxy_directly(proxy_config)
        if not proxy_working:
            print(f"❌ 代理 {proxy_config['name']} 不可用，跳过")
            return False
        
        # 2. 设置本地代理服务器
        local_ip = self.setup_local_proxy_server(proxy_config)
        
        # 3. 设置设备代理
        if not self.set_device_proxy(local_ip, 8888):
            return False
        
        # 4. 重启网络
        self.restart_network()
        
        # 5. 测试访问
        if self.test_shopee_access():
            print(f"✅ 代理设置成功: {proxy_config['name']}")
            self.current_proxy = proxy_config
            return True
        else:
            print(f"❌ 代理设置失败: {proxy_config['name']}")
            return False

def main():
    print("🤖 魔云腾设备完整代理设置脚本")
    print(f"目标设备: {DEVICE_IP}")
    print("=" * 60)
    
    # 初始化管理器
    manager = MagicCloudProxyManager(DEVICE_IP)
    
    # 1. 连接设备
    if not manager.connect_device():
        print("❌ 设备连接失败，请检查设备状态")
        sys.exit(1)
    
    # 2. 获取设备信息
    manager.get_device_ip()
    
    # 3. 检查Shopee应用
    manager.install_shopee_if_needed()
    
    # 4. 清除现有代理设置
    manager.clear_proxy()
    
    # 5. 尝试设置代理
    success_proxy = None
    
    for proxy_config in PROXY_CONFIGS:
        print(f"\n🔄 尝试代理: {proxy_config['name']} ({proxy_config['region']})")
        
        if manager.setup_proxy_complete(proxy_config):
            success_proxy = proxy_config
            break
        
        print(f"❌ 代理 {proxy_config['name']} 设置失败，尝试下一个...")
        time.sleep(2)
    
    # 6. 结果处理
    if success_proxy:
        print(f"\n🎉 代理设置成功!")
        print("=" * 60)
        print(f"使用代理: {success_proxy['name']} ({success_proxy['region']})")
        print(f"代理服务器: {success_proxy['host']}:{success_proxy['port']}")
        print(f"本地转发: localhost:8888")
        
        # 启动Shopee
        if manager.launch_shopee():
            print("✅ Shopee应用已启动")
        
        # 最终测试
        print("\n🧪 最终访问测试...")
        if manager.test_shopee_access():
            print("✅ Shopee TW访问正常!")
        
        print("\n💡 使用说明:")
        print("1. 代理已设置完成，Shopee应用可正常使用")
        print("2. 如需停止代理，请运行清除代理功能")
        print("3. 本地代理服务器将持续运行")
        
        # 保持脚本运行
        try:
            print("\n按 Ctrl+C 停止代理服务器...")
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            print("\n🛑 停止代理服务器...")
            manager.clear_proxy()
            if manager.proxy_server:
                manager.proxy_server.stop()
            print("✅ 代理服务器已停止")
    
    else:
        print("\n❌ 所有代理都设置失败!")
        print("建议:")
        print("1. 检查代理账号是否正常")
        print("2. 检查网络连接")
        print("3. 联系代理服务商确认服务状态")
        
        # 清除设置
        manager.clear_proxy()

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n🛑 脚本已停止")
    except Exception as e:
        print(f"\n❌ 脚本执行出错: {e}")
        import traceback
        traceback.print_exc()