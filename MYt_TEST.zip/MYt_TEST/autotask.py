#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ADB 自动点击工具
功能：截图、获取坐标、自动点击
"""

import subprocess
import os
import time
import json
from PIL import Image
import xml.etree.ElementTree as ET

class ADBClickTool:
    def __init__(self):
        self.device_id = None
        self.screenshot_path = "screenshot.png"
        self.ui_dump_path = "ui.xml"
        
    def run_adb_command(self, command):
        """执行 ADB 命令"""
        try:
            if self.device_id:
                cmd = f"adb -s {self.device_id} {command}"
            else:
                cmd = f"adb {command}"
            
            result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
            return result.stdout.strip(), result.stderr.strip()
        except Exception as e:
            return "", str(e)
    
    def check_devices(self):
        """检查连接的设备"""
        stdout, stderr = self.run_adb_command("devices")
        if stderr:
            print(f"错误: {stderr}")
            return False
        
        lines = stdout.split('\n')[1:]  # 跳过标题行
        devices = []
        for line in lines:
            if line.strip() and 'device' in line:
                device_id = line.split('\t')[0]
                devices.append(device_id)
        
        if not devices:
            print("未找到连接的设备！请确保：")
            print("1. 手机已连接并开启 USB 调试")
            print("2. 已授权此计算机进行调试")
            return False
        
        if len(devices) == 1:
            self.device_id = devices[0]
            print(f"已连接设备: {self.device_id}")
        else:
            print("发现多个设备:")
            for i, device in enumerate(devices):
                print(f"{i+1}. {device}")
            choice = int(input("请选择设备 (输入数字): ")) - 1
            self.device_id = devices[choice]
        
        return True
    
    def take_screenshot(self):
        """截取屏幕截图"""
        print("正在截取屏幕截图...")
        stdout, stderr = self.run_adb_command(f"shell screencap -p /sdcard/{self.screenshot_path}")
        if stderr:
            print(f"截图失败: {stderr}")
            return False
        
        stdout, stderr = self.run_adb_command(f"pull /sdcard/{self.screenshot_path} {self.screenshot_path}")
        if stderr and "error" in stderr.lower():
            print(f"下载截图失败: {stderr}")
            return False
        
        # 清理手机上的截图文件
        self.run_adb_command(f"shell rm /sdcard/{self.screenshot_path}")
        
        print(f"截图已保存到: {self.screenshot_path}")
        
        # 尝试打开图片显示坐标信息
        try:
            img = Image.open(self.screenshot_path)
            width, height = img.size
            print(f"屏幕分辨率: {width} x {height}")
            print("提示: 用图片查看器打开截图，鼠标悬停可查看像素坐标")
            return True
        except Exception as e:
            print(f"打开图片失败: {e}")
            return False
    
    def toggle_pointer_location(self, enable=True):
        """开启/关闭指针位置显示"""
        value = "1" if enable else "0"
        stdout, stderr = self.run_adb_command(f"shell settings put system pointer_location {value}")
        
        if enable:
            print("已开启指针位置显示")
            print("现在在手机屏幕上触摸，可以看到实时坐标")
        else:
            print("已关闭指针位置显示")
        
        return not stderr
    
    def click_coordinate(self, x, y):
        """点击指定坐标"""
        print(f"点击坐标: ({x}, {y})")
        stdout, stderr = self.run_adb_command(f"shell input tap {x} {y}")
        if stderr:
            print(f"点击失败: {stderr}")
            return False
        print("点击成功")
        return True
    
    def long_press(self, x, y, duration=1000):
        """长按指定坐标"""
        print(f"长按坐标: ({x}, {y})，持续时间: {duration}ms")
        stdout, stderr = self.run_adb_command(f"shell input swipe {x} {y} {x} {y} {duration}")
        if stderr:
            print(f"长按失败: {stderr}")
            return False
        print("长按成功")
        return True
    
    def swipe(self, x1, y1, x2, y2, duration=300):
        """滑动操作"""
        print(f"滑动: ({x1}, {y1}) -> ({x2}, {y2})，持续时间: {duration}ms")
        stdout, stderr = self.run_adb_command(f"shell input swipe {x1} {y1} {x2} {y2} {duration}")
        if stderr:
            print(f"滑动失败: {stderr}")
            return False
        print("滑动成功")
        return True
    
    def input_text(self, text):
        """输入文本"""
        # 转义特殊字符
        text = text.replace(" ", "%s")
        print(f"输入文本: {text}")
        stdout, stderr = self.run_adb_command(f'shell input text "{text}"')
        if stderr:
            print(f"输入失败: {stderr}")
            return False
        print("输入成功")
        return True
    
    def press_key(self, keycode):
        """按键操作"""
        print(f"按键: {keycode}")
        stdout, stderr = self.run_adb_command(f"shell input keyevent {keycode}")
        if stderr:
            print(f"按键失败: {stderr}")
            return False
        print("按键成功")
        return True
    
    def dump_ui(self):
        """导出UI结构"""
        print("正在导出UI结构...")
        stdout, stderr = self.run_adb_command(f"shell uiautomator dump /sdcard/{self.ui_dump_path}")
        if stderr:
            print(f"导出UI失败: {stderr}")
            return False
        
        stdout, stderr = self.run_adb_command(f"pull /sdcard/{self.ui_dump_path} {self.ui_dump_path}")
        if stderr and "error" in stderr.lower():
            print(f"下载UI文件失败: {stderr}")
            return False
        
        # 清理手机上的文件
        self.run_adb_command(f"shell rm /sdcard/{self.ui_dump_path}")
        
        print(f"UI结构已保存到: {self.ui_dump_path}")
        return True
    
    def find_element_by_text(self, text):
        """通过文本查找元素坐标"""
        if not self.dump_ui():
            return None
        
        try:
            tree = ET.parse(self.ui_dump_path)
            root = tree.getroot()
            
            # 递归查找包含指定文本的元素
            def find_text_element(element):
                if element.get('text') == text or text in (element.get('text') or ''):
                    bounds = element.get('bounds')
                    if bounds:
                        # 解析bounds属性 例如: [100,200][300,400]
                        import re
                        coords = re.findall(r'\[(\d+),(\d+)\]', bounds)
                        if len(coords) == 2:
                            x1, y1 = int(coords[0][0]), int(coords[0][1])
                            x2, y2 = int(coords[1][0]), int(coords[1][1])
                            # 返回中心点坐标
                            center_x = (x1 + x2) // 2
                            center_y = (y1 + y2) // 2
                            return center_x, center_y
                
                # 递归查找子元素
                for child in element:
                    result = find_text_element(child)
                    if result:
                        return result
                return None
            
            result = find_text_element(root)
            if result:
                print(f"找到文本 '{text}' 的坐标: {result}")
                return result
            else:
                print(f"未找到包含文本 '{text}' 的元素")
                return None
                
        except Exception as e:
            print(f"解析UI文件失败: {e}")
            return None
    
    def click_by_text(self, text):
        """通过文本点击元素"""
        coords = self.find_element_by_text(text)
        if coords:
            return self.click_coordinate(coords[0], coords[1])
        return False

def show_menu():
    """显示菜单"""
    print("\n" + "="*50)
    print("ADB 自动点击工具")
    print("="*50)
    print("1. 截取屏幕截图")
    print("2. 开启指针位置显示")
    print("3. 关闭指针位置显示")
    print("4. 点击坐标")
    print("5. 长按坐标")
    print("6. 滑动操作")
    print("7. 输入文本")
    print("8. 按键操作")
    print("9. 通过文本点击")
    print("10. 导出UI结构")
    print("0. 退出")
    print("="*50)

def main():
    tool = ADBClickTool()
    
    # 检查设备连接
    if not tool.check_devices():
        return
    
    while True:
        show_menu()
        try:
            choice = input("请选择操作 (0-10): ").strip()
            
            if choice == "0":
                print("退出程序")
                break
            elif choice == "1":
                tool.take_screenshot()
            elif choice == "2":
                tool.toggle_pointer_location(True)
            elif choice == "3":
                tool.toggle_pointer_location(False)
            elif choice == "4":
                try:
                    x = int(input("请输入X坐标: "))
                    y = int(input("请输入Y坐标: "))
                    tool.click_coordinate(x, y)
                except ValueError:
                    print("坐标必须是数字")
            elif choice == "5":
                try:
                    x = int(input("请输入X坐标: "))
                    y = int(input("请输入Y坐标: "))
                    duration = int(input("请输入长按时间(毫秒，默认1000): ") or "1000")
                    tool.long_press(x, y, duration)
                except ValueError:
                    print("输入的数值格式错误")
            elif choice == "6":
                try:
                    x1 = int(input("请输入起始X坐标: "))
                    y1 = int(input("请输入起始Y坐标: "))
                    x2 = int(input("请输入结束X坐标: "))
                    y2 = int(input("请输入结束Y坐标: "))
                    duration = int(input("请输入滑动时间(毫秒，默认300): ") or "300")
                    tool.swipe(x1, y1, x2, y2, duration)
                except ValueError:
                    print("坐标和时间必须是数字")
            elif choice == "7":
                text = input("请输入要发送的文本: ")
                tool.input_text(text)
            elif choice == "8":
                print("常用按键:")
                print("KEYCODE_BACK - 返回键")
                print("KEYCODE_HOME - Home键")
                print("KEYCODE_MENU - 菜单键")
                print("KEYCODE_ENTER - 回车键")
                keycode = input("请输入按键代码: ")
                tool.press_key(keycode)
            elif choice == "9":
                text = input("请输入要查找的文本: ")
                tool.click_by_text(text)
            elif choice == "10":
                tool.dump_ui()
            else:
                print("无效选择，请重新输入")
                
        except KeyboardInterrupt:
            print("\n\n程序被中断")
            break
        except Exception as e:
            print(f"操作失败: {e}")
    
    # 程序退出时关闭指针位置显示
    tool.toggle_pointer_location(False)

if __name__ == "__main__":
    main()