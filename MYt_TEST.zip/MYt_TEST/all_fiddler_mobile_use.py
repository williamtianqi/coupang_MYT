import subprocess
import time
import csv
import json
import os
import datetime
from urllib.parse import quote_plus

# ⚙️ 核心配置
DEEPLINK_FILE = "data1.csv"          # 支持CSV/JSON格式
RETRY_COUNT = 3                     # 失败重试次数
SCHEME_WHITELIST = ["https://", "http://", "shopee://", "myapp://"]  # 扩展协议支持
ADB_DEVICE = "172.16.102.5:5555"   # ADB设备地址
SHOPEE_PACKAGE = "com.shopee.tw"   # Shopee应用包名
APK_PATH = "shopee.apk"            # APK文件路径
SCREENSHOT_DIR = "screenshots"      # 截图目录
BATCH_SIZE = 7                     # 每批测试的链接数

# ⚙️ 时间配置
APP_STARTUP_WAIT = 15              # 启动app后等待时间(秒)
DEEPLINK_INTERVAL = 4              # 每次访问deeplink间隔(秒)
RESET_WAIT_TIME = 140              # 重置后等待时间(秒)
APK_INSTALL_WAIT = 21              # APK安装后等待时间(秒)

# ⚙️ 点击配置
ENABLE_CLICK = True                # 是否启用启动后点击
CLICK_X = 340                      # 点击X坐标
CLICK_Y = 1160                     # 点击Y坐标
CLICK_DELAY = 2                    # 点击后等待时间(秒)

LOG_FILE = "deeplink_test.log"     # 日志文件名

class Logger:
    """日志记录器"""
    @staticmethod
    def log(message, print_to_console=True):
        """记录日志到文件并可选择打印到控制台"""
        timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        log_entry = f"[{timestamp}] {message}"
        
        try:
            with open(LOG_FILE, "a", encoding="utf-8") as f:
                f.write(log_entry + "\n")
        except Exception as e:
            if print_to_console:
                print(f"❌ 写入日志失败: {str(e)}")
        
        if print_to_console:
            print(message)

class ADBManager:
    """增强型ADB连接管理器"""
    
    @staticmethod
    def connect_device(device_address):
        """连接到指定的ADB设备"""
        Logger.log(f"🔗 正在连接设备: {device_address}")
        try:
            # 检查adb服务状态
            subprocess.run("adb start-server", shell=True, capture_output=True, text=True, timeout=10)
            
            # 连接设备
            cmd = f"adb connect {device_address}"
            result = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=15)
            
            if "connected" in result.stdout.lower() or "already connected" in result.stdout.lower():
                Logger.log(f"✅ 设备连接成功: {device_address}")
                return True
            else:
                Logger.log(f"❌ 设备连接失败: {result.stdout.strip()}")
                return False
        except subprocess.TimeoutExpired:
            Logger.log(f"❌ 连接超时: {device_address}")
            return False
        except Exception as e:
            Logger.log(f"❌ 连接异常: {str(e)}")
            return False
    
    @staticmethod
    def check_device_connected():
        """检查设备是否已连接"""
        try:
            cmd = "adb devices"
            result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
            return ADB_DEVICE in result.stdout and "device" in result.stdout
        except:
            return False
    
    @staticmethod
    def ensure_connection():
        """确保设备连接"""
        if ADBManager.check_device_connected():
            return True
        return ADBManager.connect_device(ADB_DEVICE)

class DeeplinkValidator:
    @staticmethod
    def is_valid(deeplink):
        """验证深度链接合法性"""
        return any(deeplink.startswith(s) for s in SCHEME_WHITELIST)
    
    @staticmethod
    def normalize_shopee_link(link):
        """标准化Shopee链接格式"""
        if link.startswith('/'):
            link = f"https://shopee.tw{link}"
        elif not link.startswith(('http://', 'https://')):
            link = f"https://shopee.tw/{link.lstrip('/')}"
        return link

def load_deeplinks():
    """智能加载多格式数据源"""
    try:
        if DEEPLINK_FILE.endswith('.csv'):
            with open(DEEPLINK_FILE, encoding='utf-8') as f:
                reader = csv.DictReader(f)
                links = []
                for row in reader:
                    # 支持多种列名
                    url = row.get('url') or row.get('deeplink') or row.get('link')
                    if url:
                        links.append(url.strip())
                return links
                        
        elif DEEPLINK_FILE.endswith('.json'):
            with open(DEEPLINK_FILE, encoding='utf-8') as f:
                data = json.load(f)
                if isinstance(data, list):
                    return [item if isinstance(item, str) else item.get('url', '') for item in data]
                elif 'links' in data:
                    return [item.get('uri', item.get('url', '')) for item in data['links']]
                else:
                    return []
                    
    except FileNotFoundError:
        Logger.log(f"❌ 文件未找到: {DEEPLINK_FILE}")
        return []
    except Exception as e:
        Logger.log(f"❌ 文件加载失败: {str(e)}")
        return []

def click_screen(x, y):
    """点击屏幕指定坐标"""
    if not ADBManager.ensure_connection():
        Logger.log("❌ 设备连接失败，无法点击")
        return False
    
    try:
        Logger.log(f"👆 点击屏幕坐标: ({x}, {y})")
        cmd = f"adb -s {ADB_DEVICE} shell input tap {x} {y}"
        result = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=5)
        
        if result.returncode == 0:
            Logger.log(f"✅ 点击成功，等待 {CLICK_DELAY} 秒...")
            time.sleep(CLICK_DELAY)
            return True
        else:
            Logger.log(f"❌ 点击失败: {result.stderr}")
            return False
    except Exception as e:
        Logger.log(f"❌ 点击异常: {str(e)}")
        return False

def check_app_installed():
    """检查应用是否已安装"""
    if not ADBManager.ensure_connection():
        return False
    
    try:
        cmd = f"adb -s {ADB_DEVICE} shell pm list packages | grep {SHOPEE_PACKAGE}"
        result = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=10)
        
        if SHOPEE_PACKAGE in result.stdout:
            Logger.log(f"✅ 应用已安装: {SHOPEE_PACKAGE}")
            return True
        else:
            Logger.log(f"❌ 应用未安装: {SHOPEE_PACKAGE}")
            return False
    except Exception as e:
        Logger.log(f"❌ 检查应用安装状态异常: {str(e)}")
        return False

def get_app_main_activity():
    """获取应用的主Activity"""
    if not ADBManager.ensure_connection():
        return None
    
    try:
        # 获取应用的主Activity
        cmd = f"adb -s {ADB_DEVICE} shell cmd package resolve-activity --brief {SHOPEE_PACKAGE}"
        result = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=10)
        
        if result.returncode == 0 and result.stdout.strip():
            lines = result.stdout.strip().split('\n')
            for line in lines:
                if '/' in line and SHOPEE_PACKAGE in line:
                    Logger.log(f"📋 发现主Activity: {line.strip()}")
                    return line.strip()
        
        Logger.log("⚠️ 无法获取主Activity，使用通用启动方法")
        return None
    except Exception as e:
        Logger.log(f"❌ 获取主Activity异常: {str(e)}")
        return None

def start_shopee_app():
    """启动Shopee应用"""
    if not ADBManager.ensure_connection():
        Logger.log("❌ 设备连接失败")
        return False
    
    try:
        Logger.log(f"📱 启动Shopee应用: {SHOPEE_PACKAGE}")
        
        # 方法1: 获取并使用主Activity启动
        main_activity = get_app_main_activity()
        if main_activity:
            Logger.log("🎯 使用主Activity启动...")
            cmd = f"adb -s {ADB_DEVICE} shell am start -n {main_activity}"
            result = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=10)
            if result.returncode == 0:
                Logger.log("✅ 主Activity启动成功")
            else:
                Logger.log(f"⚠️ 主Activity启动失败: {result.stderr}")
        
        # 方法2: 使用Intent启动
        if not main_activity or result.returncode != 0:
            Logger.log("🔄 尝试Intent启动方法...")
            cmd = f"adb -s {ADB_DEVICE} shell am start -a android.intent.action.MAIN -c android.intent.category.LAUNCHER {SHOPEE_PACKAGE}"
            result = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=10)
            if result.returncode == 0:
                Logger.log("✅ Intent启动成功")
            else:
                Logger.log(f"⚠️ Intent启动失败: {result.stderr}")
        
        # 方法3: 使用简化的monkey启动
        if result.returncode != 0:
            Logger.log("🔄 尝试monkey启动方法...")
            cmd = f"adb -s {ADB_DEVICE} shell monkey -p {SHOPEE_PACKAGE} 1"
            result = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=10)
            if result.returncode == 0:
                Logger.log("✅ monkey启动成功")
            else:
                Logger.log(f"⚠️ monkey启动失败: {result.stderr}")
        
        # 检查启动结果
        if result.returncode == 0:
            Logger.log(f"✅ 应用启动成功，等待 {APP_STARTUP_WAIT} 秒...")
            time.sleep(APP_STARTUP_WAIT)
            
            # 启动后点击操作
            if ENABLE_CLICK:
                Logger.log("🎯 执行启动后点击操作...")
                if click_screen(CLICK_X, CLICK_Y):
                    Logger.log("✅ 启动后点击完成，准备访问deeplink")
                    return True
                else:
                    Logger.log("⚠️ 启动后点击失败，尝试继续")
                    return False
            else:
                return True
        else:
            Logger.log(f"❌ 所有启动方法都失败")
            Logger.log(f"❌ 最后一次输出: {result.stdout}")
            return False
    except Exception as e:
        Logger.log(f"❌ 启动应用异常: {str(e)}")
        return False

def execute_deeplink_test(deeplink):
    """执行deeplink测试"""
    if not ADBManager.ensure_connection():
        Logger.log("❌ 设备连接失败，跳过此链接")
        return False
    
    normalized_link = DeeplinkValidator.normalize_shopee_link(deeplink)
    
    try:
        Logger.log(f"🔗 访问链接: {normalized_link}")
        cmd = f"adb -s {ADB_DEVICE} shell am start -a android.intent.action.VIEW -d '{normalized_link}'"
        result = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=10)
        
        if result.returncode == 0 and "Error" not in result.stderr:
            Logger.log(f"✅ 链接访问成功")
            return True
        else:
            Logger.log(f"⚠️ 链接访问可能有问题，返回码: {result.returncode}")
            return False
            
    except subprocess.TimeoutExpired:
        Logger.log(f"⏱️ 链接访问超时")
        return False
    except Exception as e:
        Logger.log(f"❌ 链接访问异常: {str(e)}")
        return False

def reset_cloud_device():
    """重置云机"""
    Logger.log("🔄 开始重置云机...")
    try:
        cmd = f"adb -s {ADB_DEVICE} shell reboot"
        subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=15)
        Logger.log(f"⏱️ 重置完成，等待 {RESET_WAIT_TIME} 秒...")
        time.sleep(RESET_WAIT_TIME)
        
        # 重新连接设备
        for attempt in range(10):
            if ADBManager.connect_device(ADB_DEVICE):
                Logger.log("✅ 重置后设备重连成功")
                return True
            Logger.log(f"⚠️ 重连尝试 {attempt + 1}/10...")
            time.sleep(5)
        
        Logger.log("❌ 重置后设备重连失败")
        return False
        
    except Exception as e:
        Logger.log(f"❌ 重置云机异常: {str(e)}")
        return False

def install_apk():
    """安装APK"""
    if not ADBManager.ensure_connection():
        Logger.log("❌ 设备连接失败，无法安装APK")
        return False
        
    try:
        Logger.log(f"📦 开始安装APK: {APK_PATH}")
        cmd = f"adb -s {ADB_DEVICE} install -r -d {APK_PATH}"
        result = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=60)
        
        Logger.log(f"⏱️ APK安装完成，等待 {APK_INSTALL_WAIT} 秒...")
        time.sleep(APK_INSTALL_WAIT)
        
        if result.returncode == 0:
            Logger.log("✅ APK安装成功")
            return True
        else:
            Logger.log(f"⚠️ APK安装可能有问题: {result.stderr}")
            return True  # 继续执行，可能是重复安装
            
    except Exception as e:
        Logger.log(f"❌ APK安装异常: {str(e)}")
        return False

def take_screenshot(batch_num):
    """截图"""
    try:
        os.makedirs(SCREENSHOT_DIR, exist_ok=True)
        timestamp = datetime.datetime.now().strftime("%m%d_%H%M%S")
        screenshot_path = f"{SCREENSHOT_DIR}/batch_{batch_num:04d}_{timestamp}.png"
        cmd = f"adb -s {ADB_DEVICE} exec-out screencap -p > {screenshot_path}"
        result = subprocess.run(cmd, shell=True, timeout=10)
        
        if result.returncode == 0:
            Logger.log(f"📸 截图保存: {screenshot_path}")
            return screenshot_path
        else:
            Logger.log("⚠️ 截图失败")
            return None
    except Exception as e:
        Logger.log(f"❌ 截图异常: {str(e)}")
        return None

def save_progress(completed_batches, total_links, test_stats):
    """保存测试进度"""
    try:
        progress_data = {
            'timestamp': time.time(),
            'completed_batches': completed_batches,
            'total_links': total_links,
            'stats': test_stats
        }
        with open('test_progress.json', 'w', encoding='utf-8') as f:
            json.dump(progress_data, f, ensure_ascii=False, indent=2)
        Logger.log("✅ 进度已保存")
    except Exception as e:
        Logger.log(f"❌ 保存进度失败: {str(e)}")

def print_test_summary(total_batches, total_links, test_stats):
    """打印测试总结"""
    Logger.log(f"\n{'='*50}")
    Logger.log(f"📊 测试总结")
    Logger.log(f"{'='*50}")
    Logger.log(f"完成批次: {total_batches}")
    Logger.log(f"总链接数: {total_links}")
    
    start_time = test_stats.get('start_time', 0)
    if start_time > 0:
        duration_hours = (time.time() - start_time) / 3600
        if duration_hours > 0:
            rate_per_hour = total_links / duration_hours
            Logger.log(f"运行时间: {duration_hours:.1f} 小时")
            Logger.log(f"处理速率: {rate_per_hour:.1f} 链接/小时")
            Logger.log(f"预计日处理: {rate_per_hour * 24:.0f} 链接")

def main():
    """主函数：执行深度链接测试"""
    Logger.log("🚀 启动深度链接自动化测试系统")
    Logger.log(f"📱 目标设备: {ADB_DEVICE}")
    Logger.log(f"📱 目标应用: {SHOPEE_PACKAGE}")
    Logger.log(f"📋 批次大小: {BATCH_SIZE} 条链接")
    
    # 确保设备连接
    if not ADBManager.ensure_connection():
        Logger.log("❌ 无法连接设备，测试终止")
        return
    
    # 检查应用是否已安装
    if not check_app_installed():
        Logger.log("⚠️ 应用未安装，尝试安装APK...")
        if not install_apk():
            Logger.log("❌ APK安装失败，测试终止")
            return
    
    # 加载深度链接
    all_links = load_deeplinks()
    if not all_links:
        Logger.log("❌ 未找到可测试的链接")
        return
    
    # 过滤有效链接
    valid_links = []
    for link in all_links:
        if link and DeeplinkValidator.is_valid(link):
            valid_links.append(link)
        else:
            Logger.log(f"⚠️ 跳过无效链接: {link}")
    
    Logger.log(f"✅ 加载有效深度链接 {len(valid_links)} 条")
    
    # 测试统计
    test_stats = {'start_time': time.time()}
    batch_num = 0
    link_index = 0
    
    try:
        while True:
            batch_num += 1
            cycle_start_time = time.time()
            
            Logger.log(f"\n{'🔗' * 20}")
            Logger.log(f"🔗 第 {batch_num} 批测试开始")
            Logger.log(f"{'🔗' * 20}")
            
            # 1. 启动Shopee应用并等待15秒
            if not start_shopee_app():
                Logger.log("❌ 应用启动失败，跳过此批次")
                continue
            
            # 2. 每隔4秒访问一次deeplink，共7次
            success_count = 0
            for i in range(BATCH_SIZE):
                # 循环使用链接
                if link_index >= len(valid_links):
                    link_index = 0
                
                link = valid_links[link_index]
                Logger.log(f"📍 第 {i+1}/{BATCH_SIZE} 条链接")
                
                if execute_deeplink_test(link):
                    success_count += 1
                
                link_index += 1
                
                # 除了最后一次，都等待4秒
                if i < BATCH_SIZE - 1:
                    Logger.log(f"⏱️ 等待 {DEEPLINK_INTERVAL} 秒后继续...")
                    time.sleep(DEEPLINK_INTERVAL)
            
            # 3. 截图
            take_screenshot(batch_num)
            
            # 4. 重置云机并等待140秒
            if not reset_cloud_device():
                Logger.log("❌ 重置失败，尝试继续")
            
            # 5. 安装APK并等待21秒
            if not install_apk():
                Logger.log("❌ APK安装失败，尝试继续")
            
            # 计算周期时间
            cycle_duration = time.time() - cycle_start_time
            total_links = batch_num * BATCH_SIZE
            
            Logger.log(f"✅ 第 {batch_num} 批完成")
            Logger.log(f"📊 成功率: {success_count}/{BATCH_SIZE}")
            Logger.log(f"⏱️ 周期耗时: {cycle_duration:.1f} 秒")
            Logger.log(f"📈 累计处理: {total_links} 条链接")
            
            # 每10批显示详细统计并保存进度
            if batch_num % 10 == 0:
                elapsed_hours = (time.time() - test_stats['start_time']) / 3600
                if elapsed_hours > 0:
                    rate = total_links / elapsed_hours
                    Logger.log(f"📊 当前处理速率: {rate:.1f} 链接/小时")
                    Logger.log(f"📊 预计日处理量: {rate * 24:.0f} 链接")
                
                save_progress(batch_num, total_links, test_stats)
    
    except KeyboardInterrupt:
        Logger.log("\n👋 用户中断测试")
    except Exception as e:
        Logger.log(f"\n❌ 程序异常: {str(e)}")
        import traceback
        traceback.print_exc()
    finally:
        # 保存最终统计
        total_links = batch_num * BATCH_SIZE
        save_progress(batch_num, total_links, test_stats)
        print_test_summary(batch_num, total_links, test_stats)
        Logger.log("✅ 测试完成")

if __name__ == "__main__":
    main()