#!/usr/bin/env python3
"""
双重启动系统 - API启动 + Monkey启动备用
完整版本 - 30秒超时 + 重试机制
"""

import subprocess
import time
import csv
import json
import requests
import urllib.parse
import datetime
import os
import threading
import re
from concurrent.futures import ThreadPoolExecutor
import signal
import sys

# 云服务配置
CLOUD_BASE_URL = "http://127.0.0.1:9000"
CLOUD_HOST_IP = "172.16.253.249"
APK_PATH = "C:\\Program Files (x86)\\WuhanMoyuntengNetWork\\MYT_Zeus\\Shared\\shopee-tw-3-28-34.apk"

# 应用配置
SHOPEE_PACKAGE = "com.shopee.tw"
DEEPLINK_FILE = "shopee_deals_10k.csv"
BATCH_SIZE = 7

# 验证过的时间配置
APP_STARTUP_WAIT = 12      # 增加APP启动等待时间
CLICK_DELAY = 9            # 点击后等待时间
DEEPLINK_INTERVAL = 4      # deeplink间隔时间
STATUS_CHECK_INTERVAL = 5  # 状态检查间隔

# 验证过的点击坐标
CLICK_X = 340
CLICK_Y = 1160

# 截图配置
SCREENSHOT_DIR = "screenshots"
LOG_FILE = "dual_launch_system.log"

class Logger:
    _lock = threading.Lock()
    
    @staticmethod
    def log(message, device="MAIN"):
        timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        log_entry = f"[{timestamp}][{device}] {message}"
        
        with Logger._lock:
            try:
                with open(LOG_FILE, "a", encoding="utf-8") as f:
                    f.write(log_entry + "\n")
            except:
                pass
            print(log_entry)

class CloudAPI:
    """云机API控制类"""
    
    @staticmethod
    def get_device_list():
        """获取设备列表"""
        url = f"{CLOUD_BASE_URL}/dc_api/v1/list/{CLOUD_HOST_IP}"
        try:
            response = requests.get(url, timeout=30)
            if response.status_code == 200:
                data = response.json()
                if data.get('code') == 200 and 'data' in data:
                    return data['data']
            return []
        except Exception as e:
            Logger.log(f"❌ 获取设备列表失败: {e}")
            return []
    
    @staticmethod
    def install_apk(machine_name, device_name, max_retries=2):
        """安装APK - 30秒超时 + 重试机制"""
        encoded_path = urllib.parse.quote(APK_PATH)
        url = f"{CLOUD_BASE_URL}/install_apk/{CLOUD_HOST_IP}/{machine_name}?local={encoded_path}"
        
        for attempt in range(max_retries):
            try:
                Logger.log(f"📦 第{attempt+1}次安装APK尝试 (30秒超时)", device_name)
                response = requests.get(url, timeout=30)  # 改为30秒超时
                
                if response.status_code == 200:
                    data = response.json()
                    code = data.get('code')
                    msg = data.get('msg', '')
                    
                    Logger.log(f"📋 安装响应: code={code}, msg={msg}", device_name)
                    
                    if code == 0 and msg == 'Success':
                        Logger.log(f"✅ 第{attempt+1}次APK安装成功", device_name)
                        return True
                    else:
                        Logger.log(f"❌ 第{attempt+1}次APK安装失败: code={code}, msg={msg}", device_name)
                        if attempt < max_retries - 1:
                            Logger.log(f"⏸️ 等待10秒后重试安装", device_name)
                            time.sleep(10)
                            continue
                        else:
                            return False
                else:
                    Logger.log(f"❌ 第{attempt+1}次HTTP错误: {response.status_code}", device_name)
                    if attempt < max_retries - 1:
                        Logger.log(f"⏸️ 等待10秒后重试安装", device_name)
                        time.sleep(10)
                        continue
                    else:
                        return False
                        
            except requests.exceptions.Timeout:
                Logger.log(f"⏰ 第{attempt+1}次安装超时 (30秒)", device_name)
                if attempt < max_retries - 1:
                    Logger.log(f"⏸️ 等待15秒后重试安装", device_name)
                    time.sleep(15)
                    continue
                else:
                    Logger.log("❌ 所有安装尝试都超时", device_name)
                    return False
            except Exception as e:
                Logger.log(f"❌ 第{attempt+1}次安装异常: {e}", device_name)
                if attempt < max_retries - 1:
                    Logger.log(f"⏸️ 等待10秒后重试安装", device_name)
                    time.sleep(10)
                    continue
                else:
                    Logger.log("❌ 所有安装尝试都失败", device_name)
                    return False
        
        return False
    
    @staticmethod
    def uninstall_apk(machine_name, device_name, package_name=SHOPEE_PACKAGE, max_retries=2):
        """卸载APK - 30秒超时 + 重试机制"""
        url = f"{CLOUD_BASE_URL}/uninstall_apk/{CLOUD_HOST_IP}/{machine_name}/{package_name}"
        
        for attempt in range(max_retries):
            try:
                Logger.log(f"🗑️ 第{attempt+1}次卸载 {package_name} (30秒超时)", device_name)
                response = requests.get(url, timeout=30)  # 改为30秒超时
                
                if response.status_code == 200:
                    data = response.json()
                    code = data.get('code')
                    msg = data.get('msg', '')
                    
                    Logger.log(f"📋 卸载响应: code={code}, msg={msg}", device_name)
                    
                    if code == 200:
                        Logger.log(f"✅ 第{attempt+1}次APK卸载成功", device_name)
                        return True
                    else:
                        Logger.log(f"❌ 第{attempt+1}次卸载失败: code={code}", device_name)
                        if attempt < max_retries - 1:
                            Logger.log(f"⏸️ 等待5秒后重试卸载", device_name)
                            time.sleep(5)
                            continue
                        else:
                            return False
                else:
                    Logger.log(f"❌ 第{attempt+1}次HTTP错误: {response.status_code}", device_name)
                    if attempt < max_retries - 1:
                        Logger.log(f"⏸️ 等待5秒后重试卸载", device_name)
                        time.sleep(5)
                        continue
                    else:
                        return False
                        
            except requests.exceptions.Timeout:
                Logger.log(f"⏰ 第{attempt+1}次卸载超时 (30秒)", device_name)
                if attempt < max_retries - 1:
                    Logger.log(f"⏸️ 等待10秒后重试卸载", device_name)
                    time.sleep(10)
                    continue
                else:
                    Logger.log("❌ 所有卸载尝试都超时", device_name)
                    return False
            except Exception as e:
                Logger.log(f"❌ 第{attempt+1}次卸载异常: {e}", device_name)
                if attempt < max_retries - 1:
                    Logger.log(f"⏸️ 等待5秒后重试卸载", device_name)
                    time.sleep(5)
                    continue
                else:
                    Logger.log("❌ 所有卸载尝试都失败", device_name)
                    return False
        
        return False
    
    @staticmethod
    def get_random_devinfo(machine_name, device_name, max_retries=2):
        """获取随机设备信息 - 30秒超时 + 重试机制"""
        url = f"{CLOUD_BASE_URL}/random_devinfo_async/{CLOUD_HOST_IP}/{machine_name}"
        
        for attempt in range(max_retries):
            try:
                Logger.log(f"🎲 第{attempt+1}次请求随机设备信息 (30秒超时)", device_name)
                response = requests.get(url, timeout=30)  # 改为30秒超时
                
                if response.status_code == 200:
                    data = response.json()
                    code = data.get('code')
                    msg = data.get('msg', '')
                    
                    Logger.log(f"📋 随机设备信息响应: code={code}, msg={msg}", device_name)
                    
                    if code == 200:
                        Logger.log(f"✅ 第{attempt+1}次随机设备信息设置成功", device_name)
                        return True
                    else:
                        Logger.log(f"❌ 第{attempt+1}次随机设备信息失败: code={code}", device_name)
                        if attempt < max_retries - 1:
                            Logger.log(f"⏸️ 等待5秒后重试设置", device_name)
                            time.sleep(5)
                            continue
                        else:
                            return False
                else:
                    Logger.log(f"❌ 第{attempt+1}次HTTP错误: {response.status_code}", device_name)
                    if attempt < max_retries - 1:
                        Logger.log(f"⏸️ 等待5秒后重试设置", device_name)
                        time.sleep(5)
                        continue
                    else:
                        return False
                        
            except requests.exceptions.Timeout:
                Logger.log(f"⏰ 第{attempt+1}次随机设备信息超时 (30秒)", device_name)
                if attempt < max_retries - 1:
                    Logger.log(f"⏸️ 等待10秒后重试设置", device_name)
                    time.sleep(10)
                    continue
                else:
                    Logger.log("❌ 所有随机设备信息尝试都超时", device_name)
                    return False
            except Exception as e:
                Logger.log(f"❌ 第{attempt+1}次随机设备信息异常: {e}", device_name)
                if attempt < max_retries - 1:
                    Logger.log(f"⏸️ 等待5秒后重试设置", device_name)
                    time.sleep(5)
                    continue
                else:
                    Logger.log("❌ 所有随机设备信息尝试都失败", device_name)
                    return False
        
        return False
    
    @staticmethod
    def shell_command(machine_name, device_name, command):
        """执行shell命令"""
        url = f"{CLOUD_BASE_URL}/shell/{CLOUD_HOST_IP}/{machine_name}"
        data = {"cmd": command}
        
        try:
            response = requests.post(url, json=data, timeout=30)
            if response.status_code == 200:
                result = response.json()
                code = result.get('code', 0)
                msg = result.get('msg', '')
                shell_code = result.get('shell_code', -1)
                
                if code == 200 and shell_code == 0:
                    return True, msg
                else:
                    return False, msg
            else:
                return False, f"HTTP错误: {response.status_code}"
        except Exception as e:
            return False, f"请求异常: {e}"

class DualLaunchSystem:
    """双重启动系统"""
    
    @staticmethod
    def api_launch_app(machine_name, device_name, package_name=SHOPEE_PACKAGE, max_retries=2):
        """方法1: 使用API启动APP - 30秒超时 + 重试机制"""
        url = f"{CLOUD_BASE_URL}/run_apk/{CLOUD_HOST_IP}/{machine_name}/{package_name}"
        
        for attempt in range(max_retries):
            try:
                Logger.log(f"🚀 第{attempt+1}次API启动APP尝试 (30秒超时)", device_name)
                response = requests.get(url, timeout=30)  # 改为30秒超时
                
                if response.status_code == 200:
                    data = response.json()
                    code = data.get('code')
                    msg = data.get('msg', '')
                    
                    Logger.log(f"📋 API启动响应: code={code}, msg={msg}", device_name)
                    
                    if code == 200:
                        Logger.log(f"✅ 第{attempt+1}次API启动成功", device_name)
                        return True
                    else:
                        Logger.log(f"❌ 第{attempt+1}次API启动失败: code={code}, msg={msg}", device_name)
                        if attempt < max_retries - 1:
                            Logger.log(f"⏸️ 等待5秒后重试API启动", device_name)
                            time.sleep(5)
                            continue
                        else:
                            return False
                else:
                    Logger.log(f"❌ 第{attempt+1}次API HTTP错误: {response.status_code}", device_name)
                    if attempt < max_retries - 1:
                        Logger.log(f"⏸️ 等待5秒后重试API启动", device_name)
                        time.sleep(5)
                        continue
                    else:
                        return False
                        
            except requests.exceptions.Timeout:
                Logger.log(f"⏰ 第{attempt+1}次API启动超时 (30秒)", device_name)
                if attempt < max_retries - 1:
                    Logger.log(f"⏸️ 等待10秒后重试API启动", device_name)
                    time.sleep(10)
                    continue
                else:
                    Logger.log("❌ 所有API启动尝试都超时", device_name)
                    return False
            except Exception as e:
                Logger.log(f"❌ 第{attempt+1}次API启动异常: {e}", device_name)
                if attempt < max_retries - 1:
                    Logger.log(f"⏸️ 等待5秒后重试API启动", device_name)
                    time.sleep(5)
                    continue
                else:
                    Logger.log("❌ 所有API启动尝试都失败", device_name)
                    return False
        
        return False
    
    @staticmethod
    def shell_monkey_launch(machine_name, device_name, package_name=SHOPEE_PACKAGE):
        """方法2: 使用Shell Monkey启动APP"""
        Logger.log("🚀 方法2: Shell Monkey启动APP", device_name)
        
        # 先强制停止APP
        Logger.log("🛑 强制停止现有APP进程", device_name)
        CloudAPI.shell_command(machine_name, device_name, f"am force-stop {package_name}")
        CloudAPI.shell_command(machine_name, device_name, f"killall {package_name}")
        time.sleep(2)
        
        # 清除APP数据（可选，防止缓存问题）
        Logger.log("🧹 清除APP缓存", device_name)
        CloudAPI.shell_command(machine_name, device_name, f"pm clear {package_name}")
        time.sleep(1)
        
        # 使用多种monkey命令尝试
        monkey_commands = [
            # 标准monkey启动
            f"monkey -p {package_name} -c android.intent.category.LAUNCHER 1",
            # 增加事件数的monkey
            f"monkey -p {package_name} -c android.intent.category.LAUNCHER 3",
            # 指定更多参数的monkey
            f"monkey -p {package_name} -c android.intent.category.LAUNCHER --pct-appswitch 0 --pct-anyevent 0 1",
        ]
        
        for i, cmd in enumerate(monkey_commands):
            Logger.log(f"🐒 Monkey尝试{i+1}: {cmd}", device_name)
            success, output = CloudAPI.shell_command(machine_name, device_name, cmd)
            
            if success:
                # 检查输出中是否有错误信息
                if "No activities found" not in output and "killed" not in output.lower() and "Exception" not in output:
                    Logger.log(f"✅ Monkey尝试{i+1}成功", device_name)
                    time.sleep(3)  # 等待启动
                    
                    # 验证启动是否成功
                    if DualLaunchSystem.verify_app_launch(machine_name, device_name):
                        return True
                else:
                    Logger.log(f"❌ Monkey尝试{i+1}输出异常: {output[:100]}...", device_name)
            else:
                Logger.log(f"❌ Monkey尝试{i+1}失败: {output}", device_name)
            
            time.sleep(2)  # 尝试间隔
        
        return False
    
    @staticmethod
    def shell_am_start_launch(machine_name, device_name, package_name=SHOPEE_PACKAGE):
        """方法3: 使用Shell am start启动APP"""
        Logger.log("🚀 方法3: Shell am start启动APP", device_name)
        
        am_commands = [
            # 标准启动
            f"am start -a android.intent.action.MAIN -c android.intent.category.LAUNCHER {package_name}",
            # 强制启动
            f"am start -a android.intent.action.MAIN -c android.intent.category.LAUNCHER -f 0x10000000 {package_name}",
            # 等待完成启动
            f"am start -W -a android.intent.action.MAIN -c android.intent.category.LAUNCHER {package_name}",
        ]
        
        for i, cmd in enumerate(am_commands):
            Logger.log(f"📱 am start尝试{i+1}: {cmd[:60]}...", device_name)
            success, output = CloudAPI.shell_command(machine_name, device_name, cmd)
            
            if success and "Error" not in output and "Exception" not in output:
                Logger.log(f"✅ am start尝试{i+1}成功", device_name)
                time.sleep(3)
                
                if DualLaunchSystem.verify_app_launch(machine_name, device_name):
                    return True
            else:
                Logger.log(f"❌ am start尝试{i+1}失败: {output[:100]}...", device_name)
            
            time.sleep(2)
        
        return False
    
    @staticmethod
    def verify_app_launch(machine_name, device_name, package_name=SHOPEE_PACKAGE):
        """验证APP是否成功启动"""
        Logger.log("🔍 验证APP启动状态", device_name)
        
        verification_checks = []
        
        # 检查1: 进程是否存在
        try:
            success, output = CloudAPI.shell_command(machine_name, device_name, f"ps | grep {package_name}")
            process_running = success and package_name in output
            verification_checks.append(("进程检查", process_running))
            if process_running:
                Logger.log("✅ APP进程正在运行", device_name)
        except:
            verification_checks.append(("进程检查", False))
        
        # 检查2: 当前Activity
        try:
            success, output = CloudAPI.shell_command(machine_name, device_name, "dumpsys activity activities | grep mResumedActivity")
            activity_active = success and package_name in output
            verification_checks.append(("Activity检查", activity_active))
            if activity_active:
                Logger.log("✅ APP Activity活跃", device_name)
        except:
            verification_checks.append(("Activity检查", False))
        
        # 检查3: 包状态
        try:
            success, output = CloudAPI.shell_command(machine_name, device_name, f"dumpsys package {package_name} | grep 'running'")
            package_active = success and "running" in output
            verification_checks.append(("包状态检查", package_active))
        except:
            verification_checks.append(("包状态检查", False))
        
        # 计算验证分数
        passed_checks = sum(1 for _, status in verification_checks if status)
        total_checks = len(verification_checks)
        verification_score = passed_checks / total_checks
        
        Logger.log(f"📊 启动验证: {passed_checks}/{total_checks} 通过 ({verification_score*100:.1f}%)", device_name)
        
        # 至少通过一项检查就认为启动成功
        return verification_score > 0
    
    @staticmethod
    def ultimate_app_launch(machine_name, device_name, max_attempts=2):
        """终极APP启动 - 依次尝试所有方法"""
        Logger.log("🚀 启动终极APP启动流程", device_name)
        
        launch_methods = [
            ("API启动", DualLaunchSystem.api_launch_app),
            ("Shell Monkey启动", DualLaunchSystem.shell_monkey_launch),
            ("Shell am start启动", DualLaunchSystem.shell_am_start_launch)
        ]
        
        for attempt in range(max_attempts):
            Logger.log(f"🔄 第{attempt+1}轮启动尝试", device_name)
            
            for method_name, method_func in launch_methods:
                Logger.log(f"🎯 尝试{method_name}", device_name)
                
                try:
                    if method_func(machine_name, device_name):
                        Logger.log(f"✅ {method_name}成功!", device_name)
                        Logger.log(f"⏱️ 等待APP完全加载 {APP_STARTUP_WAIT}秒", device_name)
                        time.sleep(APP_STARTUP_WAIT)
                        
                        # 最终验证
                        if DualLaunchSystem.verify_app_launch(machine_name, device_name):
                            Logger.log("🎉 APP启动完全成功!", device_name)
                            return True
                        else:
                            Logger.log(f"⚠️ {method_name}启动但验证失败", device_name)
                    else:
                        Logger.log(f"❌ {method_name}失败", device_name)
                        
                except Exception as e:
                    Logger.log(f"❌ {method_name}异常: {e}", device_name)
                
                # 方法间隔
                time.sleep(3)
            
            if attempt < max_attempts - 1:
                Logger.log(f"⏸️ 第{attempt+1}轮失败，等待10秒后重试", device_name)
                time.sleep(10)
        
        Logger.log("❌ 所有启动方法都失败", device_name)
        return False

class ADBController:
    """ADB控制类"""
    
    @staticmethod
    def click_popup(machine_name, device_name):
        """点击弹窗"""
        Logger.log(f"🎯 点击弹窗 ({CLICK_X}, {CLICK_Y})", device_name)
        
        command = f"input tap {CLICK_X} {CLICK_Y}"
        success, output = CloudAPI.shell_command(machine_name, device_name, command)
        
        if success:
            Logger.log("✅ 弹窗点击成功", device_name)
            Logger.log(f"⏱️ 等待弹窗完全过掉 {CLICK_DELAY}秒", device_name)
            time.sleep(CLICK_DELAY)
            return True
        else:
            Logger.log(f"❌ 弹窗点击失败: {output}", device_name)
            return False
    
    @staticmethod
    def adb_deeplink(machine_name, device_name, deeplink):
        """执行deeplink"""
        # 标准化链接
        if deeplink.startswith('/'):
            normalized_link = f"https://shopee.tw{deeplink}"
        elif not deeplink.startswith(('http://', 'https://')):
            normalized_link = f"https://shopee.tw/{deeplink.lstrip('/')}"
        else:
            normalized_link = deeplink
        
        command = f"am start -a android.intent.action.VIEW -d '{normalized_link}'"
        
        try:
            Logger.log(f"🔗 访问: {normalized_link[:50]}...", device_name)
            success, output = CloudAPI.shell_command(machine_name, device_name, command)
            
            if success and "Error" not in output:
                Logger.log("✅ 链接访问成功", device_name)
                return True
            else:
                Logger.log(f"❌ 链接访问失败: {output}", device_name)
                return False
        except Exception as e:
            Logger.log(f"❌ 链接访问异常: {e}", device_name)
            return False
    
    @staticmethod
    def adb_screenshot(machine_name, device_name, batch_num, cycle_num):
        """截图"""
        try:
            Logger.log(f"📸 执行截图", device_name)
            
            timestamp = datetime.datetime.now().strftime("%m%d_%H%M%S")
            remote_path = f"/data/screenshot_{timestamp}.png"
            command = f"screencap -p {remote_path}"
            
            success, output = CloudAPI.shell_command(machine_name, device_name, command)
            
            if success:
                Logger.log(f"✅ 截图已保存: {remote_path}", device_name)
                return remote_path
            else:
                Logger.log(f"❌ 截图失败: {output}", device_name)
                return None
        except Exception as e:
            Logger.log(f"❌ 截图异常: {e}", device_name)
            return None

def load_deeplinks():
    """加载deeplinks"""
    try:
        with open(DEEPLINK_FILE, encoding='utf-8') as f:
            content = f.read().strip()
            links = []
            
            # 按行分割
            for line in content.split('\n'):
                line = line.strip()
                if line and line.startswith('http'):
                    links.append(line)
            
            # 如果没有找到，尝试CSV
            if not links:
                f.seek(0)
                try:
                    reader = csv.DictReader(f)
                    for row in reader:
                        url = row.get('url') or row.get('deeplink') or row.get('link')
                        if url and url.strip():
                            links.append(url.strip())
                except:
                    pass
            
            Logger.log(f"✅ 加载{len(links)}条链接")
            return links if links else ["https://shopee.tw/", "https://shopee.tw/search?keyword=test"]
            
    except Exception as e:
        Logger.log(f"❌ 加载链接失败: {e}")
        return ["https://shopee.tw/", "https://shopee.tw/search?keyword=test"]

def save_progress(device_name, stats):
    """保存进度"""
    try:
        progress_data = {
            'timestamp': time.time(),
            'device': device_name,
            'stats': stats
        }
        progress_file = f"progress_{device_name}.json"
        with open(progress_file, 'w', encoding='utf-8') as f:
            json.dump(progress_data, f, ensure_ascii=False, indent=2)
    except:
        pass

def device_worker(device_info, all_links, stop_event):
    """设备工作线程 - 使用双重启动系统"""
    device_name = device_info["name"]
    machine_id = device_info["id"]
    machine_name = device_info["name"]
    
    stats = {
        'total_cycles': 0,
        'total_tested': 0,
        'total_success': 0,
        'start_time': time.time(),
        'launch_failures': 0
    }
    
    Logger.log(f"🚀 设备工作线程启动 - 双重启动系统", device_name)
    
    link_index = 0
    first_run = True
    
    try:
        while not stop_event.is_set() and link_index < len(all_links):
            stats['total_cycles'] += 1
            
            Logger.log(f"\n{'='*30}", device_name)
            Logger.log(f"🔄 第{stats['total_cycles']}轮测试开始", device_name)
            Logger.log(f"{'='*30}", device_name)
            
            try:
                # 非首次运行：卸载重装
                if not first_run:
                    Logger.log("1️⃣ 卸载旧版APP", device_name)
                    CloudAPI.uninstall_apk(machine_name, device_name)
                    time.sleep(2)
                    
                    Logger.log("2️⃣ 重新安装APK", device_name)
                    if not CloudAPI.install_apk(machine_name, device_name):
                        Logger.log("❌ APK安装失败，跳过本轮", device_name)
                        continue
                    
                    Logger.log("3️⃣ 设置随机设备信息", device_name)
                    CloudAPI.get_random_devinfo(machine_name, device_name)
                else:
                    Logger.log("1️⃣ 首次运行，安装APK", device_name)
                    if not CloudAPI.install_apk(machine_name, device_name):
                        Logger.log("❌ 首次APK安装失败，跳过本轮", device_name)
                        continue
                
                # 关键步骤：使用双重启动系统
                Logger.log("4️⃣ 使用双重启动系统启动APP", device_name)
                if not DualLaunchSystem.ultimate_app_launch(machine_name, device_name):
                    Logger.log("❌ 双重启动系统失败，跳过本轮", device_name)
                    stats['launch_failures'] += 1
                    continue
                
                # 处理弹窗
                Logger.log("5️⃣ 处理弹窗", device_name)
                ADBController.click_popup(machine_name, device_name)
                
                # deeplink测试
                Logger.log("6️⃣ 开始deeplink测试", device_name)
                
                batch_tested = 0
                batch_success = 0
                
                while batch_tested < BATCH_SIZE and link_index < len(all_links) and not stop_event.is_set():
                    link = all_links[link_index]
                    link_index += 1
                    batch_tested += 1
                    stats['total_tested'] += 1
                    
                    Logger.log(f"📍 第{batch_tested}/{BATCH_SIZE}条 (总第{stats['total_tested']}条)", device_name)
                    
                    if ADBController.adb_deeplink(machine_name, device_name, link):
                        batch_success += 1
                        stats['total_success'] += 1
                    
                    # 第3条时截图
                    if batch_tested == 3:
                        Logger.log("📸 第三条完成，执行截图", device_name)
                        ADBController.adb_screenshot(machine_name, device_name, stats['total_cycles'], batch_tested)
                    
                    # 间隔等待
                    if batch_tested < BATCH_SIZE and link_index < len(all_links):
                        Logger.log(f"⏱️ 等待{DEEPLINK_INTERVAL}秒后继续", device_name)
                        time.sleep(DEEPLINK_INTERVAL)
                
                # 统计
                success_rate = (batch_success / batch_tested * 100) if batch_tested > 0 else 0
                total_success_rate = (stats['total_success'] / stats['total_tested'] * 100) if stats['total_tested'] > 0 else 0
                
                Logger.log(f"📊 第{stats['total_cycles']}轮完成: {batch_tested}条, 成功{batch_success}条({success_rate:.1f}%)", device_name)
                Logger.log(f"📊 累计: {stats['total_tested']}条, 成功{stats['total_success']}条({total_success_rate:.1f}%)", device_name)
                
                first_run = False
                
                # 保存进度
                save_progress(device_name, stats)
                
            except Exception as e:
                Logger.log(f"❌ 第{stats['total_cycles']}轮异常: {e}", device_name)
                stats['launch_failures'] += 1
                time.sleep(10)
                continue
            
            # 检查完成
            if link_index >= len(all_links):
                Logger.log("🏁 所有链接测试完成", device_name)
                break
    
    except Exception as e:
        Logger.log(f"❌ 设备线程异常: {e}", device_name)
        import traceback
        Logger.log(f"❌ 异常详情: {traceback.format_exc()}", device_name)
    
    # 最终统计
    elapsed_time = time.time() - stats['start_time']
    Logger.log(f"\n🏁 设备{device_name}测试结束", device_name)
    Logger.log(f"📊 总轮次: {stats['total_cycles']}", device_name)
    Logger.log(f"📊 总测试: {stats['total_tested']}条", device_name)
    Logger.log(f"📊 总成功: {stats['total_success']}条", device_name)
    Logger.log(f"📊 启动失败: {stats['launch_failures']}次", device_name)
    Logger.log(f"📊 成功率: {(stats['total_success']/stats['total_tested']*100) if stats['total_tested'] > 0 else 0:.1f}%", device_name)
    Logger.log(f"⏱️ 运行时间: {elapsed_time/3600:.1f}小时", device_name)

def main():
    """主函数"""
    stop_event = threading.Event()
    
    def signal_handler(signum, frame):
        Logger.log("🛑 收到中断信号")
        stop_event.set()
    
    signal.signal(signal.SIGINT, signal_handler)
    
    Logger.log("🚀 启动双重启动系统")
    Logger.log("✨ 新特性: 所有API调用30秒超时 + 自动重试")
    Logger.log("✨ 三重保障: API启动 → Shell Monkey → Shell am start")
    Logger.log("✨ 智能验证: 多维度验证APP启动状态")
    Logger.log("✨ 超时优化: install_apk, uninstall_apk, run_apk 全部30秒超时")
    
    # 获取设备列表
    devices = CloudAPI.get_device_list()
    if not devices:
        Logger.log("❌ 未获取到设备列表")
        return
    
    running_devices = [d for d in devices if d.get('state') == 'running']
    Logger.log(f"✅ 发现{len(running_devices)}个运行中的设备")
    
    if not running_devices:
        Logger.log("❌ 没有运行中的设备")
        return
    
    # 限制并发数量，提高稳定性
    max_concurrent = min(len(running_devices), 2)
    selected_devices = running_devices[:max_concurrent]
    
    Logger.log(f"🎯 选择{len(selected_devices)}个设备进行测试")
    for device in selected_devices:
        Logger.log(f"📱 设备: {device.get('name', 'Unknown')} - IP: {device.get('ip', 'Unknown')}")
    
    # 加载链接
    all_links = load_deeplinks()
    if not all_links:
        Logger.log("❌ 未找到链接")
        return
    
    Logger.log(f"📋 加载{len(all_links)}条deeplink")
    Logger.log(f"⚙️ 批次大小: {BATCH_SIZE}条/轮")
    Logger.log(f"⚙️ 时间配置: APP启动{APP_STARTUP_WAIT}秒, 点击后{CLICK_DELAY}秒, deeplink间隔{DEEPLINK_INTERVAL}秒")
    
    try:
        # 启动设备线程
        with ThreadPoolExecutor(max_workers=max_concurrent) as executor:
            futures = []
            for i, device in enumerate(selected_devices):
                future = executor.submit(device_worker, device, all_links, stop_event)
                futures.append(future)
                Logger.log(f"✅ 启动设备{i+1}: {device.get('name', 'Unknown')}")
                time.sleep(20)  # 错开启动，减少并发压力
            
            # 等待完成
            for future in futures:
                try:
                    future.result()
                except Exception as e:
                    Logger.log(f"❌ 线程异常: {e}")
        
        Logger.log("🏁 所有测试完成")
        
    except KeyboardInterrupt:
        Logger.log("⏹️ 用户中断")
        stop_event.set()
    except Exception as e:
        Logger.log(f"❌ 程序异常: {e}")
        import traceback
        Logger.log(f"❌ 异常详情: {traceback.format_exc()}")

if __name__ == "__main__":
    main()