import requests
import time

# 设备信息
devices = [
    {
        "Names": "27189f3ba9004c06a2c01ce8aed14c35_1_T1001",
        "State": "running",
        "data": "/mmc/data/data1_1749124884182",
        "index": 1,
        "ip": "172.16.253.249"
    },
    {
        "Names": "27189f3ba9004c06a2c01ce8aed14c35_2_T1002",
        "State": "running",
        "data": "/mmc/data/data2_1749124884465",
        "index": 2,
        "ip": "172.16.253.249"
    },
    {
        "Names": "27189f3ba9004c06a2c01ce8aed14c35_3_T2001",
        "State": "running",
        "data": "/mmc/data/data3_1749125013495",
        "index": 3,
        "ip": "172.16.253.249"
    },
    {
        "Names": "27189f3ba9004c06a2c01ce8aed14c35_4_T2002",
        "State": "running",
        "data": "/mmc/data/data4_1749125013780",
        "index": 4,
        "ip": "172.16.253.249"
    }
]

# API基础地址
base_url = "http://127.0.0.1:5000/random_devinfo_async"

# HTTP请求头
headers = {
    'Accept-Language': 'zh-CN,zh;q=0.9',
    'Connection': 'keep-alive',
    'Referer': 'http://127.0.0.1:5000/docs',
    'Sec-Fetch-Dest': 'empty',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Site': 'same-origin',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36',
    'accept': 'application/json',
    'sec-ch-ua': '"Google Chrome";v="137", "Chromium";v="137", "Not/A)Brand";v="24"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"'
}

# 切换所有设备指纹
for i, device in enumerate(devices):
    ip = device["ip"]
    name = device["Names"]  # 使用完整的Names
    
    print(f"正在切换设备 {i+1}/4: {name} ({ip})")
    
    try:
        url = f"{base_url}/{ip}/{name}"
        response = requests.get(url, headers=headers, timeout=10)
        result = response.json()
        
        if result.get("code") == 200:
            print(f"✅ 设备 {name} 切换成功")
        else:
            print(f"❌ 设备 {name} 切换失败: {result.get('msg', '未知错误')}")
            
    except Exception as e:
        print(f"❌ 设备 {name} 请求失败: {e}")
    
    # 等待1秒再处理下一个
    if i < len(devices) - 1:
        time.sleep(1)

print("\n所有设备处理完成！")