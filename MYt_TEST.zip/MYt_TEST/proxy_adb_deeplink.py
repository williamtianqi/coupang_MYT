"""
简化版云机deeplink测试器 - 严格时序控制版本

时序流程：
1. 重置云机 → 等待140秒
2. 安装APK → 等待20秒  
3. 连接ADB → 启动应用 → 等待8秒
4. 点击弹窗 → 等待5秒
5. 开始deeplink测试，每条间隔5秒
"""

import subprocess
import time
import csv
import json
import requests
import urllib.parse
import datetime
import os
import threading
from concurrent.futures import ThreadPoolExecutor
import signal
import sys

# 设备配置
DEVICE_LIST = [
    {"name": "T1001", "ip": "172.16.101.2:5555", "machine_id": "27189f3ba9004c06a2c01ce8aed14c35_1_T1001"},
    {"name": "T1002", "ip": "172.16.101.3:5555", "machine_id": "27189f3ba9004c06a2c01ce8aed14c35_2_T1002"},
    {"name": "T2001", "ip": "172.16.102.4:5555", "machine_id": "27189f3ba9004c06a2c01ce8aed14c35_3_T2001"},
    {"name": "T2002", "ip": "172.16.102.5:5555", "machine_id": "27189f3ba9004c06a2c01ce8aed14c35_4_T2002"},
]

# 云服务配置
CLOUD_BASE_URL = "http://127.0.0.1:9000"
CLOUD_HOST_IP = "172.16.253.249"
APK_PATH = "C:\\Program Files (x86)\\WuhanMoyuntengNetWork\\MYT_Zeus\\Shared\\shopee-tw-3-28-34.apk"

# 测试配置
DEEPLINK_FILE = "data1.csv"
SHOPEE_PACKAGE = "com.shopee.tw"
BATCH_SIZE = 7

# 严格时序配置
RESET_WAIT_TIME = 140      # 重置后等待时间
APK_INSTALL_WAIT = 20      # APK安装后等待时间
APP_STARTUP_WAIT = 8       # 应用启动后等待时间
CLICK_DELAY = 5            # 点击后等待时间
DEEPLINK_INTERVAL = 5      # deeplink间隔时间

# 点击配置
CLICK_X = 340
CLICK_Y = 1160

# 截图配置
SCREENSHOT_DIR = "screenshots"

LOG_FILE = "simple_deeplink_test.log"

class Logger:
    _lock = threading.Lock()
    
    @staticmethod
    def log(message, device="MAIN"):
        timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        log_entry = f"[{timestamp}][{device}] {message}"
        
        with Logger._lock:
            try:
                with open(LOG_FILE, "a", encoding="utf-8") as f:
                    f.write(log_entry + "\n")
            except:
                pass
            print(log_entry)

def reset_cloud_machine(machine_id, device_name):
    """重置云机"""
    url = f"{CLOUD_BASE_URL}/reset/{CLOUD_HOST_IP}/{machine_id}"
    Logger.log(f"🔄 开始重置云机", device_name)
    
    try:
        response = requests.get(url, timeout=30)
        Logger.log(f"✅ 重置请求已发送", device_name)
    except:
        Logger.log(f"⚠️ 重置请求失败", device_name)

def install_apk(machine_id, device_name):
    """安装APK"""
    encoded_path = urllib.parse.quote(APK_PATH)
    url = f"{CLOUD_BASE_URL}/install_apk/{CLOUD_HOST_IP}/{machine_id}?local={encoded_path}"
    Logger.log(f"📦 开始安装APK", device_name)
    
    try:
        response = requests.get(url, timeout=120)
        Logger.log(f"✅ APK安装请求已发送", device_name)
    except:
        Logger.log(f"⚠️ APK安装请求失败", device_name)

def connect_adb(device_ip, device_name):
    """连接ADB"""
    Logger.log(f"🔗 连接ADB", device_name)
    
    try:
        subprocess.run(f"adb disconnect {device_ip}", shell=True, capture_output=True, timeout=5)
        time.sleep(1)
        
        result = subprocess.run(f"adb connect {device_ip}", shell=True, capture_output=True, text=True, timeout=10)
        
        if "connected" in result.stdout.lower():
            Logger.log(f"✅ ADB连接成功", device_name)
            return True
        else:
            Logger.log(f"❌ ADB连接失败", device_name)
            return False
    except:
        Logger.log(f"❌ ADB连接异常", device_name)
        return False

def start_shopee_app(device_ip, device_name):
    """启动Shopee应用"""
    Logger.log(f"📱 启动Shopee应用", device_name)
    
    try:
        # 停止现有应用
        subprocess.run(f"adb -s {device_ip} shell am force-stop {SHOPEE_PACKAGE}", 
                      shell=True, capture_output=True, timeout=10)
        time.sleep(2)
        
        # 启动应用
        cmd = f"adb -s {device_ip} shell monkey -p {SHOPEE_PACKAGE} 1"
        result = subprocess.run(cmd, shell=True, capture_output=True, timeout=10)
        
        Logger.log(f"✅ 应用启动完成", device_name)
        return True
    except:
        Logger.log(f"❌ 应用启动失败", device_name)
        return False

def click_screen(device_ip, device_name):
    """点击屏幕"""
    Logger.log(f"🎯 点击弹窗", device_name)
    
    try:
        cmd = f"adb -s {device_ip} shell input tap {CLICK_X} {CLICK_Y}"
        subprocess.run(cmd, shell=True, capture_output=True, timeout=5)
        Logger.log(f"✅ 点击完成", device_name)
        return True
    except:
        Logger.log(f"❌ 点击失败", device_name)
        return False

def test_deeplink_adb(device_ip, device_name, deeplink):
    """ADB方式测试deeplink"""
    try:
        if deeplink.startswith('/'):
            deeplink = f"https://shopee.tw{deeplink}"
        elif not deeplink.startswith(('http://', 'https://', 'shopee://')):
            deeplink = f"https://shopee.tw/{deeplink.lstrip('/')}"
        
        cmd = f"adb -s {device_ip} shell am start -a android.intent.action.VIEW -d '{deeplink}'"
        result = subprocess.run(cmd, shell=True, capture_output=True, timeout=10)
        
        if result.returncode == 0:
            return True
        else:
            return False
    except:
        return False

def test_deeplink_cloud(machine_id, device_name, deeplink):
    """云端方式测试deeplink"""
    try:
        if deeplink.startswith('/'):
            deeplink = f"https://shopee.tw{deeplink}"
        elif not deeplink.startswith(('http://', 'https://', 'shopee://')):
            deeplink = f"https://shopee.tw/{deeplink.lstrip('/')}"
        
        encoded_link = urllib.parse.quote(deeplink)
        url = f"{CLOUD_BASE_URL}/send_intent/{CLOUD_HOST_IP}/{machine_id}?action=android.intent.action.VIEW&data={encoded_link}"
        
        response = requests.get(url, timeout=15)
        return response.status_code == 200
    except:
        return False

def take_screenshot(device_ip, device_name, batch_num, cycle_num):
    """截图"""
    try:
        os.makedirs(SCREENSHOT_DIR, exist_ok=True)
        
        timestamp = datetime.datetime.now().strftime("%m%d_%H%M%S")
        filename = f"batch_{batch_num:04d}_{device_name}_cycle_{cycle_num:03d}_{timestamp}.png"
        screenshot_path = os.path.join(SCREENSHOT_DIR, filename)
        
        if os.name == 'nt':
            cmd = f'adb -s {device_ip} exec-out screencap -p > "{screenshot_path}"'
        else:
            cmd = f"adb -s {device_ip} exec-out screencap -p > '{screenshot_path}'"
            
        result = subprocess.run(cmd, shell=True, timeout=15)
        
        if result.returncode == 0 and os.path.exists(screenshot_path):
            Logger.log(f"📸 截图保存: {filename}", device_name)
            return screenshot_path
        else:
            return None
    except:
        return None

def load_deeplinks():
    """加载deeplinks"""
    try:
        with open(DEEPLINK_FILE, encoding='utf-8') as f:
            reader = csv.DictReader(f)
            links = []
            for row in reader:
                url = row.get('url') or row.get('deeplink') or row.get('link')
                if url and url.strip():
                    links.append(url.strip())
            return links
    except:
        Logger.log(f"❌ 无法加载文件: {DEEPLINK_FILE}")
        return []

def device_worker(device_info, all_links, stop_event):
    """设备工作线程 - 严格时序版本"""
    device_name = device_info["name"]
    device_ip = device_info["ip"]
    machine_id = device_info["machine_id"]
    
    stats = {
        'total_cycles': 0,
        'total_tested': 0,
        'total_success': 0,
        'adb_success': 0,
        'cloud_success': 0
    }
    
    Logger.log(f"🚀 设备线程启动", device_name)
    
    link_index = 0  # 当前处理的链接索引
    
    try:
        while not stop_event.is_set() and link_index < len(all_links):
            stats['total_cycles'] += 1
            
            Logger.log(f"🔄 第{stats['total_cycles']}轮开始", device_name)
            
            # 步骤1: 重置云机
            reset_cloud_machine(machine_id, device_name)
            
            # 步骤2: 等待140秒
            Logger.log(f"⏱️ 等待{RESET_WAIT_TIME}秒", device_name)
            time.sleep(RESET_WAIT_TIME)
            
            # 步骤3: 安装APK
            install_apk(machine_id, device_name)
            
            # 步骤4: 等待20秒
            Logger.log(f"⏱️ 等待{APK_INSTALL_WAIT}秒", device_name)
            time.sleep(APK_INSTALL_WAIT)
            
            # 步骤5: 连接ADB
            adb_connected = connect_adb(device_ip, device_name)
            
            # 步骤6: 启动应用
            app_started = False
            if adb_connected:
                app_started = start_shopee_app(device_ip, device_name)
                
                # 步骤7: 等待8秒
                Logger.log(f"⏱️ 等待{APP_STARTUP_WAIT}秒", device_name)
                time.sleep(APP_STARTUP_WAIT)
                
                # 步骤8: 点击弹窗
                click_screen(device_ip, device_name)
                
                # 步骤9: 等待5秒
                Logger.log(f"⏱️ 等待{CLICK_DELAY}秒", device_name)
                time.sleep(CLICK_DELAY)
            
            # 步骤10: 测试deeplinks
            Logger.log(f"🎯 开始测试deeplinks", device_name)
            
            batch_tested = 0
            batch_success = 0
            
            while batch_tested < BATCH_SIZE and link_index < len(all_links) and not stop_event.is_set():
                link = all_links[link_index]
                link_index += 1
                batch_tested += 1
                stats['total_tested'] += 1
                
                Logger.log(f"🔗 测试第{batch_tested}/{BATCH_SIZE}条: {link[:50]}...", device_name)
                
                # 测试deeplink
                success = False
                
                # 优先ADB
                if app_started:
                    success = test_deeplink_adb(device_ip, device_name, link)
                    if success:
                        stats['adb_success'] += 1
                        Logger.log(f"✅ ADB测试成功", device_name)
                
                # 备用云端
                if not success:
                    success = test_deeplink_cloud(machine_id, device_name, link)
                    if success:
                        stats['cloud_success'] += 1
                        Logger.log(f"✅ 云端测试成功", device_name)
                
                if success:
                    batch_success += 1
                    stats['total_success'] += 1
                else:
                    Logger.log(f"❌ 测试失败", device_name)
                
                # 固定等待5秒
                if batch_tested < BATCH_SIZE and link_index < len(all_links):
                    Logger.log(f"⏱️ 等待{DEEPLINK_INTERVAL}秒", device_name)
                    time.sleep(DEEPLINK_INTERVAL)
            
            # 截图
            take_screenshot(device_ip, device_name, stats['total_cycles'], stats['total_cycles'])
            
            # 统计
            success_rate = (batch_success / batch_tested * 100) if batch_tested > 0 else 0
            total_success_rate = (stats['total_success'] / stats['total_tested'] * 100) if stats['total_tested'] > 0 else 0
            
            Logger.log(f"📊 第{stats['total_cycles']}轮完成: {batch_tested}条, 成功{batch_success}条({success_rate:.1f}%)", device_name)
            Logger.log(f"📊 累计: {stats['total_tested']}条, 成功{stats['total_success']}条({total_success_rate:.1f}%)", device_name)
            Logger.log(f"📊 ADB:{stats['adb_success']}条, 云端:{stats['cloud_success']}条", device_name)
    
    except Exception as e:
        Logger.log(f"❌ 设备线程异常: {e}", device_name)
    
    Logger.log(f"🏁 设备{device_name}测试完成", device_name)

def main():
    """主函数"""
    stop_event = threading.Event()
    
    def signal_handler(signum, frame):
        Logger.log("🛑 收到中断信号")
        stop_event.set()
    
    signal.signal(signal.SIGINT, signal_handler)
    
    Logger.log("🚀 启动简化版云机deeplink测试器")
    Logger.log(f"📱 设备数量: {len(DEVICE_LIST)}")
    Logger.log(f"⚙️ 批次大小: {BATCH_SIZE}条/轮")
    Logger.log(f"⚙️ 严格时序: 重置140s → APK安装20s → 应用启动8s → 点击5s → deeplink测试(5s间隔)")
    
    # 加载deeplinks
    all_links = load_deeplinks()
    if not all_links:
        Logger.log("❌ 未找到链接")
        return
    
    Logger.log(f"✅ 加载{len(all_links)}条链接")
    
    try:
        # 启动设备线程
        with ThreadPoolExecutor(max_workers=len(DEVICE_LIST)) as executor:
            futures = []
            for device in DEVICE_LIST:
                future = executor.submit(device_worker, device, all_links, stop_event)
                futures.append(future)
                Logger.log(f"✅ 启动设备: {device['name']}")
                time.sleep(2)  # 错开启动
            
            # 等待完成
            for future in futures:
                try:
                    future.result()
                except Exception as e:
                    Logger.log(f"❌ 线程异常: {e}")
        
        Logger.log("🏁 所有测试完成")
        
    except KeyboardInterrupt:
        Logger.log("⏹️ 用户中断")
        stop_event.set()
    except Exception as e:
        Logger.log(f"❌ 程序异常: {e}")

if __name__ == "__main__":
    main()