#!/usr/bin/env python3
"""
多设备云机deeplink测试器 - 优化版本（自动获取设备）

优化内容：
1. API地址自动切换（主地址失败自动切换备用地址）
2. 重置后通过get_android_boot_status接口判断状态
3. deeplink执行前检查ADB连接
4. 增加HTTP请求超时时间

先测试后重置流程：
1. 安装APK(不判断结果) → 等待20秒  
2. 连接ADB → 打开Shopee → 等待8秒
3. 点击弹窗 → 等待9秒 (确保弹窗完全过掉)
4. deeplink测试，每条间隔4秒，第3条时等待5秒截图再等3秒
5. 测试完成后重置云机 → 动态等待启动完成（最多180秒）

核心逻辑来自验证过的单机版本，删除复杂判断
自动获取设备列表，支持纯文本链接格式
"""

import subprocess
import time
import csv
import json
import requests
import urllib.parse
import datetime
import os
import threading
from concurrent.futures import ThreadPoolExecutor
import signal
import sys
import base64

# 云服务配置 - 支持双地址
CLOUD_BASE_URLS = ["http://127.0.0.1:9000", "http://172.16.253.240:9000"]
CLOUD_HOST_IP = "172.16.253.246"
APK_PATH = "C:\\Program Files (x86)\\WuhanMoyuntengNetWork\\MYT_Zeus\\Shared\\shopee-tw-3-28-34.apk"

# 测试配置
DEEPLINK_FILE = "data1.csv"
SHOPEE_PACKAGE = "com.shopee.tw"
BATCH_SIZE = 7

# 严格时序配置
APK_INSTALL_WAIT = 20      # APK安装后等待时间
APP_STARTUP_WAIT = 8       # 应用启动后等待时间
CLICK_DELAY = 9            # 点击后等待时间
DEEPLINK_INTERVAL = 5      # deeplink间隔时间
MAX_RESET_WAIT_TIME = 180  # 重置后最大等待时间

# 启动状态检查配置
MAX_BOOT_CHECK_TIME = 180  # 最长等待启动时间（秒）
BOOT_CHECK_INTERVAL = 5    # 启动检查间隔

# 点击配置
CLICK_X = 340
CLICK_Y = 1160

# 截图配置
SCREENSHOT_DIR = r"D:\screenshots_618"

LOG_FILE = "multi_device_deeplink_test.log"

# 全局变量记录当前可用的API地址
current_api_url = CLOUD_BASE_URLS[0]
api_lock = threading.Lock()

class Logger:
    _lock = threading.Lock()
    
    @staticmethod
    def log(message, device="MAIN"):
        timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        log_entry = f"[{timestamp}][{device}] {message}"
        
        with Logger._lock:
            try:
                with open(LOG_FILE, "a", encoding="utf-8") as f:
                    f.write(log_entry + "\n")
            except:
                pass
            print(log_entry)

def api_request_with_fallback(path, params=None, timeout=30, device_name="MAIN"):
    """带有自动切换功能的API请求"""
    global current_api_url
    
    for api_url in [current_api_url] + [url for url in CLOUD_BASE_URLS if url != current_api_url]:
        url = f"{api_url}{path}"
        try:
            response = requests.get(url, params=params, timeout=timeout)
            # 请求成功，更新当前可用地址
            with api_lock:
                if current_api_url != api_url:
                    Logger.log(f"✅ 切换到可用API地址: {api_url}", device_name)
                    current_api_url = api_url
            return response
        except Exception as e:
            Logger.log(f"⚠️ API请求失败 {api_url}: {str(e)}", device_name)
            continue
    
    Logger.log(f"❌ 所有API地址都不可用", device_name)
    return None

class CloudAPI:
    """云机API控制类"""
    
    @staticmethod
    def get_device_list():
        """获取设备列表"""
        path = f"/dc_api/v1/list/{CLOUD_HOST_IP}"
        try:
            response = api_request_with_fallback(path, timeout=30)
            if response and response.status_code == 200:
                data = response.json()
                if data.get('code') == 200 and 'data' in data:
                    return data['data']
            return []
        except Exception as e:
            Logger.log(f"❌ 获取设备列表失败: {e}")
            return []
    
    @staticmethod
    def check_android_boot_status(machine_name, device_name):
        """检查Android启动状态"""
        path = f"/get_android_boot_status/{CLOUD_HOST_IP}/{machine_name}"
        params = {"isblock": 0, "timeout": 10}
        
        Logger.log("🔍 检查Android启动状态", device_name)
        start_time = time.time()
        
        while time.time() - start_time < MAX_BOOT_CHECK_TIME:
            try:
                response = api_request_with_fallback(path, params=params, timeout=30, device_name=device_name)
                if response and response.status_code == 200:
                    data = response.json()
                    code = data.get('code')
                    
                    if code == 200:
                        Logger.log("✅ Android系统启动完成！", device_name)
                        return True
                    elif code == 201:
                        elapsed = int(time.time() - start_time)
                        Logger.log(f"📱 系统启动中... (已等待{elapsed}秒)", device_name)
                    else:
                        Logger.log(f"启动检查返回: code={code}", device_name)
            except Exception as e:
                Logger.log(f"启动检查异常: {e}", device_name)
            
            time.sleep(BOOT_CHECK_INTERVAL)
        
        Logger.log("⚠️ Android启动检查超时", device_name)
        return False
    
    @staticmethod
    def run_android_container(machine_name, device_name):
        """启动Android容器"""
        path = f"/run/{CLOUD_HOST_IP}/{machine_name}"
        
        Logger.log("🏃 启动Android容器", device_name)
        try:
            response = api_request_with_fallback(path, timeout=60, device_name=device_name)
            if response and response.status_code == 200:
                data = response.json()
                if data.get('code') == 200:
                    Logger.log("✅ Android容器启动请求已发送", device_name)
                    return True
        except Exception as e:
            Logger.log(f"Android容器启动异常: {e}", device_name)
        
        Logger.log("❌ Android容器启动失败", device_name)
        return False
    
    @staticmethod
    def stop_android_container(machine_name, device_name):
        """关闭Android容器"""
        path = f"/stop/{CLOUD_HOST_IP}/{machine_name}"
        
        Logger.log("🛑 关闭Android容器", device_name)
        try:
            response = api_request_with_fallback(path, timeout=30, device_name=device_name)
            if response and response.status_code == 200:
                Logger.log("✅ Android容器关闭请求已发送", device_name)
                return True
        except Exception as e:
            Logger.log(f"Android容器关闭异常: {e}", device_name)
        
        Logger.log("❌ Android容器关闭失败", device_name)
        return False

def ensure_android_running(machine_name, device_name):
    """确保Android系统运行"""
    Logger.log("🔧 检查并确保Android系统运行", device_name)
    
    # 首先检查启动状态
    if CloudAPI.check_android_boot_status(machine_name, device_name):
        Logger.log("✅ Android系统已经运行", device_name)
        return True
    
    # 如果未运行，尝试启动（最多重试3次）
    for attempt in range(3):
        Logger.log(f"🚀 Android未运行，尝试启动 (第{attempt + 1}/3次)", device_name)
        
        if CloudAPI.run_android_container(machine_name, device_name):
            # 启动后再次检查状态
            Logger.log("⏱️ 等待Android启动完成...", device_name)
            if CloudAPI.check_android_boot_status(machine_name, device_name):
                Logger.log("✅ Android启动成功", device_name)
                return True
            else:
                Logger.log(f"❌ 第{attempt + 1}次启动失败或超时", device_name)
                if attempt < 2:  # 不是最后一次尝试
                    Logger.log("🔄 尝试重启容器", device_name)
                    restart_android_container(machine_name, device_name)
        else:
            Logger.log(f"❌ 第{attempt + 1}次无法启动Android容器", device_name)
            if attempt < 2:
                Logger.log("⏱️ 等待10秒后重试", device_name)
                time.sleep(10)
    
    Logger.log("❌ 多次尝试后仍无法启动Android", device_name)
    return False

def restart_android_container(machine_name, device_name):
    """重启Android容器"""
    Logger.log("🔄 重启Android容器", device_name)
    
    # 先关闭
    CloudAPI.stop_android_container(machine_name, device_name)
    Logger.log("⏱️ 等待5秒让容器完全关闭", device_name)
    time.sleep(5)
    
    # 再启动
    if CloudAPI.run_android_container(machine_name, device_name):
        Logger.log("⏱️ 等待Android重启完成...", device_name)
        if CloudAPI.check_android_boot_status(machine_name, device_name):
            Logger.log("✅ Android容器重启成功", device_name)
            return True
        else:
            Logger.log("❌ Android重启后启动失败", device_name)
            return False
    else:
        Logger.log("❌ Android容器重启失败", device_name)
        return False

def reset_cloud_machine(machine_id, device_name):
    """重置云机 - 使用启动状态检查"""
    path = f"/reset/{CLOUD_HOST_IP}/{machine_id}"
    Logger.log(f"🔄 开始重置云机", device_name)
    
    try:
        response = api_request_with_fallback(path, timeout=30, device_name=device_name)
        if response:
            Logger.log(f"✅ 重置请求已发送", device_name)
        else:
            Logger.log(f"⚠️ 重置请求失败", device_name)
            return
    except:
        Logger.log(f"⚠️ 重置请求异常", device_name)
        return
    
    # 等待一会儿让重置开始
    Logger.log(f"⏱️ 等待10秒让重置开始...", device_name)
    time.sleep(10)
    
    # 使用启动状态检查等待重置完成
    Logger.log(f"🔍 等待云机重置完成（最多{MAX_RESET_WAIT_TIME}秒）", device_name)
    if CloudAPI.check_android_boot_status(device_name, device_name):
        Logger.log(f"✅ 云机重置完成，系统已启动", device_name)
    else:
        Logger.log(f"⚠️ 云机重置后启动检查超时", device_name)

def install_apk(machine_id, device_name):
    """安装APK"""
    encoded_path = urllib.parse.quote(APK_PATH)
    path = f"/install_apk/{CLOUD_HOST_IP}/{machine_id}?local={encoded_path}"
    Logger.log(f"📦 开始安装APK", device_name)
    
    try:
        response = api_request_with_fallback(path, timeout=120, device_name=device_name)
        if response:
            Logger.log(f"📦 APK安装请求已发送", device_name)
        else:
            Logger.log(f"📦 APK安装请求失败", device_name)
    except Exception as e:
        Logger.log(f"📦 APK安装请求异常: {str(e)}", device_name)

def run_cmd(cmd, device_name, timeout=10):
    """执行ADB命令"""
    try:
        result = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=timeout)
        return result.returncode == 0, result.stdout, result.stderr
    except:
        return False, "", "超时或异常"

def ensure_connection(device_ip, device_name):
    """确保设备连接"""
    Logger.log(f"🔗 连接ADB设备", device_name)
    
    try:
        # 先断开再连接，确保连接状态
        subprocess.run(f"adb disconnect {device_ip}", shell=True, capture_output=True, timeout=5)
        time.sleep(1)
        
        # 连接设备
        subprocess.run(f"adb connect {device_ip}", shell=True, capture_output=True, timeout=10)
        time.sleep(1)
        
        # 验证连接
        result = subprocess.run("adb devices", shell=True, capture_output=True, text=True, timeout=5)
        if device_ip in result.stdout and "device" in result.stdout:
            Logger.log(f"✅ ADB连接成功", device_name)
            return True
        else:
            Logger.log(f"❌ ADB连接失败", device_name)
            return False
    except:
        Logger.log(f"❌ ADB连接异常", device_name)
        return False

def normalize_shopee_link(link):
    """标准化Shopee链接格式"""
    if link.startswith('/'):
        link = f"https://shopee.tw{link}"
    elif not link.startswith(('http://', 'https://')):
        link = f"https://shopee.tw/{link.lstrip('/')}"
    return link

def open_shopee(device_ip, device_name):
    """打开Shopee应用"""
    Logger.log(f"🚀 准备启动Shopee应用", device_name)
    
    # 确保连接
    if not ensure_connection(device_ip, device_name):
        return False
    
    # 停止现有应用
    Logger.log(f"🛑 停止现有Shopee进程", device_name)
    success, _, _ = run_cmd(f"adb -s {device_ip} shell am force-stop {SHOPEE_PACKAGE}", device_name)
    time.sleep(2)
    
    # 方案1: 优先使用API启动
    Logger.log(f"📱 尝试使用API启动Shopee", device_name)
    
    machine_name = device_name
    api_path = f"/run_apk/{CLOUD_HOST_IP}/{machine_name}/{SHOPEE_PACKAGE}"
    
    # 尝试API启动（最多重试2次）
    for attempt in range(2):
        try:
            Logger.log(f"🔄 API启动尝试 {attempt + 1}/2", device_name)
            response = api_request_with_fallback(api_path, timeout=30, device_name=device_name)
            
            if response and response.status_code == 200:
                data = response.json()
                if data.get('code') == 200:
                    Logger.log(f"✅ API启动成功，Shopee已启动", device_name)
                    return True
                else:
                    Logger.log(f"❌ API返回错误: code={data.get('code')}", device_name)
            else:
                Logger.log(f"❌ API请求失败", device_name)
                
        except Exception as e:
            Logger.log(f"❌ API启动异常: {str(e)}", device_name)
        
        if attempt == 0:
            Logger.log(f"⏱️ 等待3秒后重试", device_name)
            time.sleep(3)
    
    # 方案2: API失败后尝试monkey方式
    Logger.log(f"🐒 API启动失败，尝试使用monkey启动", device_name)
    
    # 重新确保连接
    if not ensure_connection(device_ip, device_name):
        return False
    
    # 使用monkey启动
    success, stdout, stderr = run_cmd(f"adb -s {device_ip} shell monkey -p {SHOPEE_PACKAGE} 1", device_name, timeout=15)
    
    if success:
        Logger.log(f"✅ Monkey启动成功，Shopee已启动", device_name)
        return True
    else:
        Logger.log(f"❌ Monkey启动失败: {stderr}", device_name)
        
        # 最后尝试：使用am start命令
        Logger.log(f"🔧 最后尝试使用am start启动", device_name)
        am_cmd = f"adb -s {device_ip} shell am start -n {SHOPEE_PACKAGE}/.MainActivity"
        am_result = subprocess.run(am_cmd, shell=True, capture_output=True, text=True, timeout=10)
        
        if am_result.returncode == 0:
            Logger.log(f"✅ am start启动成功，Shopee已启动", device_name)
            return True
    
    Logger.log(f"❌ 所有启动方式都失败了", device_name)
    return False

def click_popup(device_ip, device_name):
    """点击弹窗"""
    Logger.log(f"🎯 点击弹窗 ({CLICK_X}, {CLICK_Y})", device_name)
    
    success, _, _ = run_cmd(f"adb -s {device_ip} shell input tap {CLICK_X} {CLICK_Y}", device_name)
    
    if success:
        Logger.log(f"✅ 弹窗点击成功", device_name)
    else:
        Logger.log(f"❌ 弹窗点击失败", device_name)
    
    Logger.log(f"⏱️ 等待{CLICK_DELAY}秒确保弹窗完全过掉...", device_name)
    time.sleep(CLICK_DELAY)

def execute_deeplink_test(device_ip, device_name, deeplink):
    """执行deeplink测试 - 基于稳定版本的简化逻辑"""
    # 每次执行前检查ADB连接
    if not ensure_connection(device_ip, device_name):
        Logger.log(f"❌ deeplink执行前ADB连接失败", device_name)
        return False
    
    # 标准化链接
    normalized_link = normalize_shopee_link(deeplink)
    
    try:
        Logger.log(f"🔗 访问链接: {normalized_link[:50]}...", device_name)
        
        # 使用简单的am start命令（基于稳定版本）
        cmd = f"adb -s {device_ip} shell am start -a android.intent.action.VIEW -d '{normalized_link}'"
        result = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=10)
        
        if result.returncode == 0 and "Error" not in result.stderr:
            Logger.log(f"✅ 链接访问成功", device_name)
            return True
        else:
            Logger.log(f"⚠️ 链接访问可能有问题，返回码: {result.returncode}", device_name)
            if result.stderr:
                Logger.log(f"错误信息: {result.stderr[:200]}", device_name)
            return False
            
    except subprocess.TimeoutExpired:
        Logger.log(f"⏱️ 链接访问超时", device_name)
        return False
    except Exception as e:
        Logger.log(f"❌ 链接访问异常: {str(e)}", device_name)
        return False

def take_screenshot(device_ip, device_name, batch_num, cycle_num):
    """截图功能 - 使用API接口"""
    try:
        os.makedirs(SCREENSHOT_DIR, exist_ok=True)
        
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"{device_name}_{timestamp}.png"
        screenshot_path = os.path.join(SCREENSHOT_DIR, filename)
        
        Logger.log(f"📸 开始截图 - 设备:{device_name} 文件:{filename}", device_name)
        
        # 使用API接口截图，level=1表示低质量
        screenshot_path_api = f"/screenshots/{CLOUD_HOST_IP}/{device_name}/1"
        Logger.log(f"📸 调用截图API", device_name)
        
        try:
            response = api_request_with_fallback(screenshot_path_api, timeout=30, device_name=device_name)
            if response and response.status_code == 200:
                data = response.json()
                if data.get('code') == 200:
                    # 获取base64编码的图片数据
                    base64_data = data.get('msg', '')
                    if base64_data:
                        # 解码base64数据并保存为图片
                        image_data = base64.b64decode(base64_data)
                        
                        with open(screenshot_path, 'wb') as f:
                            f.write(image_data)
                        
                        file_size = os.path.getsize(screenshot_path)
                        if file_size > 1000:
                            Logger.log(f"✅ 截图成功 - 设备:{device_name} 文件:{filename} 大小:{file_size}字节", device_name)
                            Logger.log(f"📂 截图保存: {screenshot_path}", device_name)
                            return screenshot_path
                        else:
                            Logger.log(f"❌ 截图文件太小 - 设备:{device_name} 大小:{file_size}字节", device_name)
                            try:
                                os.remove(screenshot_path)
                            except:
                                pass
                            return None
                    else:
                        Logger.log(f"❌ API返回的截图数据为空", device_name)
                        return None
                else:
                    error_msg = {
                        0: "容器不存在",
                        1: "主机不通",
                        2: "当前Android主机未运行"
                    }.get(data.get('code'), f"未知错误: code={data.get('code')}")
                    Logger.log(f"❌ 截图API返回错误: {error_msg}", device_name)
                    return None
            else:
                Logger.log(f"❌ 截图API请求失败", device_name)
                return None
                
        except Exception as e:
            Logger.log(f"❌ 截图API请求异常: {str(e)}", device_name)
            return None
            
    except Exception as e:
        Logger.log(f"❌ 截图功能异常 - 设备:{device_name} 错误:{str(e)}", device_name)
        return None

def load_deeplinks():
    """加载deeplinks"""
    try:
        with open(DEEPLINK_FILE, encoding='utf-8') as f:
            content = f.read().strip()
            links = []
            
            # 按行分割，每行一个链接
            for line in content.split('\n'):
                line = line.strip()
                if line and line.startswith('http'):
                    links.append(line)
            
            # 如果没有找到http链接，尝试CSV格式作为备用
            if not links:
                f.seek(0)
                try:
                    reader = csv.DictReader(f)
                    for row in reader:
                        url = row.get('url') or row.get('deeplink') or row.get('link')
                        if url and url.strip():
                            links.append(url.strip())
                except:
                    pass
            
            if links:
                Logger.log(f"✅ 加载{len(links)}条链接")
                return links
            else:
                Logger.log(f"❌ 文件中未找到有效链接")
                return ["https://shopee.tw/", "https://shopee.tw/search?keyword=test"]
            
    except Exception as e:
        Logger.log(f"❌ 无法加载文件: {DEEPLINK_FILE}, 错误: {e}")
        return ["https://shopee.tw/", "https://shopee.tw/search?keyword=test"]

def save_progress(device_name, stats):
    """保存进度"""
    try:
        progress_data = {
            'timestamp': time.time(),
            'device': device_name,
            'stats': stats
        }
        progress_file = f"progress_{device_name}.json"
        with open(progress_file, 'w', encoding='utf-8') as f:
            json.dump(progress_data, f, ensure_ascii=False, indent=2)
    except:
        pass

def device_worker(device_info, all_links, stop_event, device_index, total_devices):
    """设备工作线程"""
    device_name = device_info["name"]
    device_ip = device_info["ip"]
    machine_id = device_info["machine_id"]
    machine_name = device_info["name"]
    
    stats = {
        'total_cycles': 0,
        'total_tested': 0,
        'total_success': 0,
        'start_time': time.time()
    }
    
    Logger.log(f"🚀 设备工作线程启动 - 设备索引:{device_index}/{total_devices}", device_name)
    Logger.log(f"📡 当前使用API地址: {current_api_url}", device_name)
    
    # 为每台设备分配不同的链接段
    device_links = []
    for i in range(device_index, len(all_links), total_devices):
        device_links.append(all_links[i])
    
    Logger.log(f"📋 分配{len(device_links)}条链接给设备{device_name}", device_name)
    
    link_index = 0
    first_run = True
    
    try:
        while not stop_event.is_set() and link_index < len(device_links):
            stats['total_cycles'] += 1
            
            Logger.log(f"\n{'='*30}", device_name)
            Logger.log(f"🔄 第{stats['total_cycles']}轮测试开始", device_name)
            Logger.log(f"{'='*30}", device_name)
            
            # 首次运行或每轮开始前确保Android运行
            if first_run:
                Logger.log("🔧 首次运行，确保Android系统运行", device_name)
                if not ensure_android_running(machine_name, device_name):
                    Logger.log("❌ 无法确保Android运行，跳过本轮", device_name)
                    continue
                first_run = False
            else:
                Logger.log("🔧 检查Android系统状态", device_name)
                if not CloudAPI.check_android_boot_status(machine_name, device_name):
                    Logger.log("⚠️ Android未运行，尝试启动", device_name)
                    if not ensure_android_running(machine_name, device_name):
                        Logger.log("❌ 无法启动Android，跳过本轮", device_name)
                        continue
            
            # 步骤1: 安装APK
            install_apk(machine_id, device_name)
            
            # 步骤2: 等待安装完成
            Logger.log(f"⏱️ 等待APK安装完成 {APK_INSTALL_WAIT}秒", device_name)
            time.sleep(APK_INSTALL_WAIT)
            
            # 步骤3: 打开Shopee
            shopee_opened = open_shopee(device_ip, device_name)
            
            if shopee_opened:
                # 步骤4: 等待启动完成
                Logger.log(f"⏱️ 等待Shopee完全启动 {APP_STARTUP_WAIT}秒", device_name)
                time.sleep(APP_STARTUP_WAIT)
                
                # 步骤5: 点击弹窗
                click_popup(device_ip, device_name)
                
                # 步骤6: 测试deeplinks
                Logger.log(f"🎯 开始测试deeplinks", device_name)
                
                batch_tested = 0
                batch_success = 0
                
                while batch_tested < BATCH_SIZE and link_index < len(device_links) and not stop_event.is_set():
                    link = device_links[link_index]
                    link_index += 1
                    batch_tested += 1
                    stats['total_tested'] += 1
                    
                    Logger.log(f"📍 第{batch_tested}/{BATCH_SIZE}条 (设备总第{stats['total_tested']}条)", device_name)
                    
                    # 执行deeplink测试
                    if execute_deeplink_test(device_ip, device_name, link):
                        batch_success += 1
                        stats['total_success'] += 1
                    
                    # 在第三条deeplink时截图
                    if batch_tested == 3:
                        Logger.log(f"📸 第三条deeplink完成，等待5秒后截图", device_name)
                        time.sleep(5)
                        take_screenshot(device_ip, device_name, stats['total_cycles'], batch_tested)
                        Logger.log(f"📸 截图完成，再等待3秒后继续", device_name)
                        time.sleep(3)
                    
                    # 测试间隔
                    if batch_tested < BATCH_SIZE and link_index < len(device_links):
                        Logger.log(f"⏱️ 等待{DEEPLINK_INTERVAL}秒后继续", device_name)
                        time.sleep(DEEPLINK_INTERVAL)
                
                # 统计
                success_rate = (batch_success / batch_tested * 100) if batch_tested > 0 else 0
                total_success_rate = (stats['total_success'] / stats['total_tested'] * 100) if stats['total_tested'] > 0 else 0
                
                Logger.log(f"📊 第{stats['total_cycles']}轮完成: {batch_tested}条, 成功{batch_success}条({success_rate:.1f}%)", device_name)
                Logger.log(f"📊 累计: {stats['total_tested']}条, 成功{stats['total_success']}条({total_success_rate:.1f}%)", device_name)
                
            else:
                Logger.log(f"❌ Shopee启动失败，跳过本轮测试", device_name)
            
            # 步骤7: 重置云机
            if link_index < len(device_links):
                Logger.log(f"🔄 测试完成，重置云机准备下一轮", device_name)
                reset_cloud_machine(machine_id, device_name)
            
            # 保存进度
            save_progress(device_name, stats)
            
            # 如果还有更多链接，继续下一轮
            if link_index < len(device_links):
                Logger.log(f"⏱️ 准备下一轮测试", device_name)
            else:
                Logger.log(f"🏁 设备分配的所有链接测试完成", device_name)
    
    except Exception as e:
        Logger.log(f"❌ 设备线程异常: {e}", device_name)
    
    # 最终统计
    elapsed_time = time.time() - stats['start_time']
    Logger.log(f"\n🏁 设备{device_name}测试结束", device_name)
    Logger.log(f"📊 总轮次: {stats['total_cycles']}", device_name)
    Logger.log(f"📊 总测试: {stats['total_tested']}条", device_name)
    Logger.log(f"📊 总成功: {stats['total_success']}条", device_name)
    Logger.log(f"📊 成功率: {(stats['total_success']/stats['total_tested']*100) if stats['total_tested'] > 0 else 0:.1f}%", device_name)
    Logger.log(f"⏱️ 运行时间: {elapsed_time/3600:.1f}小时", device_name)

def main():
    """主函数"""
    stop_event = threading.Event()
    
    def signal_handler(signum, frame):
        Logger.log("🛑 收到中断信号")
        stop_event.set()
    
    signal.signal(signal.SIGINT, signal_handler)
    
    Logger.log("🚀 启动多设备云机deeplink测试器 - 优化版本")
    Logger.log(f"📡 主API地址: {CLOUD_BASE_URLS[0]}")
    Logger.log(f"📡 备用API地址: {CLOUD_BASE_URLS[1]}")
    Logger.log(f"🖥️ 主机IP: {CLOUD_HOST_IP}")
    Logger.log(f"⚙️ 批次大小: {BATCH_SIZE}条/轮")
    Logger.log(f"⚙️ 核心时序: 启动Shopee→等8秒→点击弹窗→等9秒→deeplink测试(4秒间隔)")
    Logger.log(f"⚙️ 完整流程: 安装APK→等20秒→打开Shopee→点击弹窗→deeplink测试→重置云机→动态等待")
    Logger.log(f"📸 截图时机: 第3条deeplink测试后 - 使用API接口截图")
    Logger.log(f"🆕 优化功能: API地址自动切换、重置动态等待、deeplink前ADB检查")
    
    # 获取设备列表
    Logger.log("🔍 自动获取设备列表...")
    devices = CloudAPI.get_device_list()
    if not devices:
        Logger.log("❌ 未获取到设备列表")
        return
    
    # 筛选running状态的设备
    device_list = []
    running_count = 0
    
    for device in devices:
        if device.get('state') == 'running':
            device_name = device.get('name', 'Unknown')
            device_ip = device.get('ip', 'Unknown')
            machine_id = device.get('id', 'Unknown')
            
            Logger.log(f"📱 设备: {device_name} - IP: {device_ip}")
            
            device_info = {
                'name': device_name,
                'ip': f"{device_ip}:5555",
                'machine_id': machine_id
            }
            device_list.append(device_info)
            running_count += 1
    
    Logger.log(f"✅ 发现{running_count}个运行中的设备")
    
    if not device_list:
        Logger.log("❌ 没有运行中的设备")
        return
    
    # 加载deeplinks
    all_links = load_deeplinks()
    if not all_links:
        Logger.log("❌ 未找到链接")
        return
    
    Logger.log(f"✅ 加载{len(all_links)}条链接")
    
    # 显示任务分配预览
    Logger.log("📋 任务分配预览:")
    for i, device in enumerate(device_list):
        device_link_count = len(range(i, len(all_links), len(device_list)))
        Logger.log(f"   {device['name']}: {device_link_count}条链接")
    
    try:
        # 启动设备线程
        with ThreadPoolExecutor(max_workers=len(device_list)) as executor:
            futures = []
            for device_index, device in enumerate(device_list):
                future = executor.submit(device_worker, device, all_links, stop_event, device_index, len(device_list))
                futures.append(future)
                Logger.log(f"✅ 启动设备: {device['name']} (索引:{device_index})", device['name'])
                time.sleep(5)  # 错开启动
            
            # 等待完成
            for future in futures:
                try:
                    future.result()
                except Exception as e:
                    Logger.log(f"❌ 线程异常: {e}")
        
        Logger.log("🏁 所有测试完成")
        
    except KeyboardInterrupt:
        Logger.log("⏹️ 用户中断")
        stop_event.set()
    except Exception as e:
        Logger.log(f"❌ 程序异常: {e}")

if __name__ == "__main__":
    main()