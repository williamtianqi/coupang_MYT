#!/usr/bin/env python3
"""
多设备云机deeplink测试器 - 自动获取设备版本

先测试后重置流程：
1. 安装APK(不判断结果) → 等待20秒  
2. 连接ADB → 打开Shopee → 等待8秒
3. 点击弹窗 → 等待9秒 (确保弹窗完全过掉)
4. deeplink测试，每条间隔4秒，第3条时截图
5. 测试完成后重置云机 → 等待140秒

核心逻辑来自验证过的单机版本，删除复杂判断
自动获取运行中的设备，无需手动配置
"""

import subprocess
import time
import csv
import json
import requests
import urllib.parse
import datetime
import os
import threading
from concurrent.futures import ThreadPoolExecutor
import signal
import sys

# 云服务配置
CLOUD_BASE_URL = "http://127.0.0.1:9000"
CLOUD_HOST_IP = "172.16.253.249"
APK_PATH = "C:\\Program Files (x86)\\WuhanMoyuntengNetWork\\MYT_Zeus\\Shared\\shopee-tw-3-28-34.apk"

# 测试配置
DEEPLINK_FILE = "data1.csv"
SHOPEE_PACKAGE = "com.shopee.tw"
BATCH_SIZE = 7

# 严格时序配置 - 先测试后重置版本
APK_INSTALL_WAIT = 20      # APK安装后等待时间
APP_STARTUP_WAIT = 8       # 应用启动后等待时间 - 验证过的时间
CLICK_DELAY = 9            # 点击后等待时间 - 确保弹窗完全过掉
DEEPLINK_INTERVAL = 4      # deeplink间隔时间 - 验证过的时间
RESET_WAIT_TIME = 140      # 重置后等待时间 - 确保云机完全重置

# 点击配置 - 验证过的坐标
CLICK_X = 340
CLICK_Y = 1160

# 截图配置
SCREENSHOT_DIR = "screenshots"

LOG_FILE = "multi_device_deeplink_test.log"

class Logger:
    _lock = threading.Lock()
    
    @staticmethod
    def log(message, device="MAIN"):
        timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        log_entry = f"[{timestamp}][{device}] {message}"
        
        with Logger._lock:
            try:
                with open(LOG_FILE, "a", encoding="utf-8") as f:
                    f.write(log_entry + "\n")
            except:
                pass
            print(log_entry)

class CloudAPI:
    """云机API控制类"""
    
    @staticmethod
    def get_device_list():
        """获取设备列表"""
        url = f"{CLOUD_BASE_URL}/dc_api/v1/list/{CLOUD_HOST_IP}"
        try:
            response = requests.get(url, timeout=30)
            if response.status_code == 200:
                data = response.json()
                if data.get('code') == 200 and 'data' in data:
                    return data['data']
            return []
        except Exception as e:
            Logger.log(f"❌ 获取设备列表失败: {e}")
            return []

def reset_cloud_machine(machine_id, device_name):
    """重置云机 - 简化版本"""
    url = f"{CLOUD_BASE_URL}/reset/{CLOUD_HOST_IP}/{machine_id}"
    Logger.log(f"🔄 开始重置云机", device_name)
    
    try:
        response = requests.get(url, timeout=30)
        Logger.log(f"✅ 重置请求已发送", device_name)
    except:
        Logger.log(f"⚠️ 重置请求失败", device_name)
    
    # 固定等待140秒
    Logger.log(f"⏱️ 等待云机完全重置 {RESET_WAIT_TIME}秒", device_name)
    time.sleep(RESET_WAIT_TIME)
    Logger.log(f"✅ 云机重置等待完成", device_name)

def install_apk(machine_id, device_name):
    """安装APK - 简化版本，发送请求就完事"""
    encoded_path = urllib.parse.quote(APK_PATH)
    url = f"{CLOUD_BASE_URL}/install_apk/{CLOUD_HOST_IP}/{machine_id}?local={encoded_path}"
    Logger.log(f"📦 开始安装APK", device_name)
    
    try:
        response = requests.get(url, timeout=120)
        Logger.log(f"📦 APK安装请求已发送", device_name)
    except Exception as e:
        Logger.log(f"📦 APK安装请求异常: {str(e)}", device_name)

def run_cmd(cmd, device_name, timeout=10):
    """执行ADB命令 - 基于验证过的逻辑"""
    try:
        result = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=timeout)
        return result.returncode == 0, result.stdout, result.stderr
    except:
        return False, "", "超时或异常"

def ensure_connection(device_ip, device_name):
    """确保设备连接 - 简化版本"""
    Logger.log(f"🔗 连接ADB设备", device_name)
    
    try:
        # 连接设备
        subprocess.run(f"adb connect {device_ip}", shell=True, capture_output=True, timeout=10)
        
        # 简单验证
        result = subprocess.run("adb devices", shell=True, capture_output=True, text=True, timeout=5)
        if device_ip in result.stdout and "device" in result.stdout:
            Logger.log(f"✅ ADB连接成功", device_name)
            return True
        else:
            Logger.log(f"❌ ADB连接失败", device_name)
            return False
    except:
        Logger.log(f"❌ ADB连接异常", device_name)
        return False

def normalize_shopee_link(link):
    """标准化Shopee链接格式 - 基于验证过的逻辑"""
    if link.startswith('/'):
        link = f"https://shopee.tw{link}"
    elif not link.startswith(('http://', 'https://')):
        link = f"https://shopee.tw/{link.lstrip('/')}"
    return link

def open_shopee(device_ip, device_name):
    """用monkey打开Shopee - 基于验证过的逻辑"""
    Logger.log(f"🚀 用monkey打开Shopee", device_name)
    
    # 确保连接
    if not ensure_connection(device_ip, device_name):
        return False
    
    # 停止现有应用
    success, _, _ = run_cmd(f"adb -s {device_ip} shell am force-stop {SHOPEE_PACKAGE}", device_name)
    time.sleep(2)
    
    # 用monkey启动
    success, stdout, stderr = run_cmd(f"adb -s {device_ip} shell monkey -p {SHOPEE_PACKAGE} 1", device_name)
    
    if success:
        Logger.log(f"✅ Shopee启动成功", device_name)
        return True
    else:
        Logger.log(f"❌ Shopee启动失败: {stderr}", device_name)
        return False

def click_popup(device_ip, device_name):
    """点击弹窗一次 - 基于验证过的逻辑"""
    Logger.log(f"🎯 点击弹窗 ({CLICK_X}, {CLICK_Y})", device_name)
    
    success, _, _ = run_cmd(f"adb -s {device_ip} shell input tap {CLICK_X} {CLICK_Y}", device_name)
    
    if success:
        Logger.log(f"✅ 弹窗点击成功", device_name)
    else:
        Logger.log(f"❌ 弹窗点击失败", device_name)
    
    Logger.log(f"⏱️ 等待{CLICK_DELAY}秒确保弹窗完全过掉...", device_name)
    time.sleep(CLICK_DELAY)

def execute_deeplink_test(device_ip, device_name, deeplink):
    """执行deeplink测试 - 基于验证过的逻辑"""
    # 标准化链接
    normalized_link = normalize_shopee_link(deeplink)
    
    try:
        Logger.log(f"🔗 访问链接: {normalized_link[:50]}...", device_name)
        cmd = f"adb -s {device_ip} shell am start -a android.intent.action.VIEW -d '{normalized_link}'"
        result = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=10)
        
        if result.returncode == 0 and "Error" not in result.stderr:
            Logger.log(f"✅ 链接访问成功", device_name)
            return True
        else:
            Logger.log(f"❌ 链接访问失败", device_name)
            return False
            
    except subprocess.TimeoutExpired:
        Logger.log(f"⏱️ 链接访问超时", device_name)
        return False
    except Exception as e:
        Logger.log(f"❌ 链接访问异常: {str(e)}", device_name)
        return False

def take_screenshot(device_ip, device_name, batch_num, cycle_num):
    """截图功能"""
    try:
        os.makedirs(SCREENSHOT_DIR, exist_ok=True)
        
        timestamp = datetime.datetime.now().strftime("%m%d_%H%M%S")
        filename = f"batch_{batch_num:04d}_{device_name}_cycle_{cycle_num:03d}_{timestamp}.png"
        screenshot_path = os.path.join(SCREENSHOT_DIR, filename)
        
        Logger.log(f"📸 开始截图: {filename}", device_name)
        
        if os.name == 'nt':
            cmd = f'adb -s {device_ip} exec-out screencap -p > "{screenshot_path}"'
        else:
            cmd = f"adb -s {device_ip} exec-out screencap -p > '{screenshot_path}'"
            
        result = subprocess.run(cmd, shell=True, timeout=15)
        
        if result.returncode == 0 and os.path.exists(screenshot_path):
            file_size = os.path.getsize(screenshot_path)
            if file_size > 1000:
                Logger.log(f"✅ 截图成功: {filename} ({file_size} bytes)", device_name)
                return screenshot_path
            else:
                try:
                    os.remove(screenshot_path)
                except:
                    pass
                return None
        else:
            return None
    except:
        return None

def load_deeplinks():
    """加载deeplinks - 基于验证过的逻辑"""
    try:
        with open(DEEPLINK_FILE, encoding='utf-8') as f:
            reader = csv.DictReader(f)
            links = []
            for row in reader:
                url = row.get('url') or row.get('deeplink') or row.get('link')
                if url and url.strip():
                    links.append(url.strip())
            return links
    except:
        Logger.log(f"❌ 无法加载文件: {DEEPLINK_FILE}")
        return ["https://shopee.tw/", "https://shopee.tw/search?keyword=test"]

def save_progress(device_name, stats):
    """保存进度"""
    try:
        progress_data = {
            'timestamp': time.time(),
            'device': device_name,
            'stats': stats
        }
        progress_file = f"progress_{device_name}.json"
        with open(progress_file, 'w', encoding='utf-8') as f:
            json.dump(progress_data, f, ensure_ascii=False, indent=2)
    except:
        pass

def device_worker(device_info, all_links, stop_event):
    """设备工作线程 - 集成验证过的核心逻辑"""
    device_name = device_info["name"]
    device_ip = device_info["ip"]
    machine_id = device_info["id"]
    
    stats = {
        'total_cycles': 0,
        'total_tested': 0,
        'total_success': 0,
        'start_time': time.time()
    }
    
    Logger.log(f"🚀 设备工作线程启动", device_name)
    
    link_index = 0  # 顺序处理链接
    
    try:
        while not stop_event.is_set() and link_index < len(all_links):
            stats['total_cycles'] += 1
            
            Logger.log(f"\n{'='*30}", device_name)
            Logger.log(f"🔄 第{stats['total_cycles']}轮测试开始", device_name)
            Logger.log(f"{'='*30}", device_name)
            
            # 步骤1: 安装APK
            install_apk(machine_id, device_name)
            
            # 步骤2: 等待20秒
            Logger.log(f"⏱️ 等待APK安装完成 {APK_INSTALL_WAIT}秒", device_name)
            time.sleep(APK_INSTALL_WAIT)
            
            # 步骤3: 用验证过的逻辑打开Shopee
            shopee_opened = open_shopee(device_ip, device_name)
            
            if shopee_opened:
                # 步骤4: 等待8秒让Shopee完全启动
                Logger.log(f"⏱️ 等待Shopee完全启动 {APP_STARTUP_WAIT}秒", device_name)
                time.sleep(APP_STARTUP_WAIT)
                
                # 步骤5: 点击弹窗，等待9秒确保完全过掉
                click_popup(device_ip, device_name)
                
                # 步骤6: 测试deeplinks
                Logger.log(f"🎯 开始测试deeplinks", device_name)
                
                batch_tested = 0
                batch_success = 0
                
                while batch_tested < BATCH_SIZE and link_index < len(all_links) and not stop_event.is_set():
                    link = all_links[link_index]
                    link_index += 1
                    batch_tested += 1
                    stats['total_tested'] += 1
                    
                    Logger.log(f"📍 第{batch_tested}/{BATCH_SIZE}条 (总第{stats['total_tested']}条)", device_name)
                    
                    # 使用验证过的deeplink测试逻辑
                    if execute_deeplink_test(device_ip, device_name, link):
                        batch_success += 1
                        stats['total_success'] += 1
                    
                    # 在第三条deeplink时截图
                    if batch_tested == 3:
                        Logger.log(f"📸 第三条deeplink完成，预留2秒后截图", device_name)
                        time.sleep(2)  # 多预留2秒时间
                        take_screenshot(device_ip, device_name, stats['total_cycles'], batch_tested)
                    
                    # 测试间隔4秒 - 验证过的时间
                    if batch_tested < BATCH_SIZE and link_index < len(all_links):
                        Logger.log(f"⏱️ 等待{DEEPLINK_INTERVAL}秒后继续", device_name)
                        time.sleep(DEEPLINK_INTERVAL)
                
                # 统计
                success_rate = (batch_success / batch_tested * 100) if batch_tested > 0 else 0
                total_success_rate = (stats['total_success'] / stats['total_tested'] * 100) if stats['total_tested'] > 0 else 0
                
                Logger.log(f"📊 第{stats['total_cycles']}轮完成: {batch_tested}条, 成功{batch_success}条({success_rate:.1f}%)", device_name)
                Logger.log(f"📊 累计: {stats['total_tested']}条, 成功{stats['total_success']}条({total_success_rate:.1f}%)", device_name)
                
            else:
                Logger.log(f"❌ Shopee启动失败，跳过本轮测试", device_name)
            
            # 步骤7: 正常完成测试后重置云机 (为下一轮准备)
            if link_index < len(all_links):  # 还有链接要测试才重置
                Logger.log(f"🔄 测试完成，重置云机准备下一轮", device_name)
                reset_cloud_machine(machine_id, device_name)
            
            # 保存进度
            save_progress(device_name, stats)
            
            # 如果还有更多链接，继续下一轮
            if link_index < len(all_links):
                Logger.log(f"⏱️ 准备下一轮测试", device_name)
            else:
                Logger.log(f"🏁 所有链接测试完成", device_name)
    
    except Exception as e:
        Logger.log(f"❌ 设备线程异常: {e}", device_name)
    
    # 最终统计
    elapsed_time = time.time() - stats['start_time']
    Logger.log(f"\n🏁 设备{device_name}测试结束", device_name)
    Logger.log(f"📊 总轮次: {stats['total_cycles']}", device_name)
    Logger.log(f"📊 总测试: {stats['total_tested']}条", device_name)
    Logger.log(f"📊 总成功: {stats['total_success']}条", device_name)
    Logger.log(f"📊 成功率: {(stats['total_success']/stats['total_tested']*100) if stats['total_tested'] > 0 else 0:.1f}%", device_name)
    Logger.log(f"⏱️ 运行时间: {elapsed_time/3600:.1f}小时", device_name)

def main():
    """主函数"""
    stop_event = threading.Event()
    
    def signal_handler(signum, frame):
        Logger.log("🛑 收到中断信号")
        stop_event.set()
    
    signal.signal(signal.SIGINT, signal_handler)
    
    Logger.log("🚀 启动多设备云机deeplink测试器 - 自动获取设备版本")
    Logger.log(f"📡 云服务地址: {CLOUD_BASE_URL}")
    Logger.log(f"🖥️ 主机IP: {CLOUD_HOST_IP}")
    Logger.log(f"⚙️ 批次大小: {BATCH_SIZE}条/轮")
    Logger.log(f"⚙️ 核心时序: monkey启动Shopee→等8秒→点击弹窗→等9秒→deeplink测试(4秒间隔)")
    Logger.log(f"⚙️ 完整流程: 安装APK→等20秒→核心测试流程→重置云机→等140秒")
    Logger.log(f"📸 截图时机: 第3条deeplink测试后(预留2秒)")
    Logger.log(f"📦 APK安装: 发送请求不判断结果，直接继续")
    
    # 自动获取设备列表
    Logger.log("🔍 自动获取设备列表...")
    devices = CloudAPI.get_device_list()
    if not devices:
        Logger.log("❌ 未获取到设备列表")
        return
    
    # 筛选running状态的设备
    running_devices = [d for d in devices if d.get('state') == 'running']
    Logger.log(f"✅ 发现{len(running_devices)}个运行中的设备")
    
    if not running_devices:
        Logger.log("❌ 没有运行中的设备")
        return
    
    # 显示设备信息并转换为所需格式
    device_list = []
    for device in running_devices:
        device_name = device.get('name', 'Unknown')
        device_ip = device.get('ip', 'Unknown')
        machine_id = device.get('id', 'Unknown')
        
        Logger.log(f"📱 设备: {device_name} - IP: {device_ip}")
        
        # 转换为worker需要的格式
        device_info = {
            'name': device_name,
            'ip': f"{device_ip}:5555",  # 添加ADB端口
            'id': machine_id
        }
        device_list.append(device_info)
    
    # 加载deeplinks
    all_links = load_deeplinks()
    if not all_links:
        Logger.log("❌ 未找到链接")
        return
    
    Logger.log(f"✅ 加载{len(all_links)}条链接")
    
    try:
        # 启动设备线程
        with ThreadPoolExecutor(max_workers=len(device_list)) as executor:
            futures = []
            for device in device_list:
                future = executor.submit(device_worker, device, all_links, stop_event)
                futures.append(future)
                Logger.log(f"✅ 启动设备: {device['name']}")
                time.sleep(5)  # 错开启动
            
            # 等待完成
            for future in futures:
                try:
                    future.result()
                except Exception as e:
                    Logger.log(f"❌ 线程异常: {e}")
        
        Logger.log("🏁 所有测试完成")
        
    except KeyboardInterrupt:
        Logger.log("⏹️ 用户中断")
        stop_event.set()
    except Exception as e:
        Logger.log(f"❌ 程序异常: {e}")

if __name__ == "__main__":
    main()