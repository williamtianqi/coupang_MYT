#!/usr/bin/env python3
"""
多设备云机deeplink测试器 - 优化版本

优化内容：
1. 点击弹窗改为两次点击，间隔2秒
2. 140秒固定等待改为智能获取云机状态
3. 增强重置流程的稳定性

基于测试验证的最稳定启动方式：固定种子monkey
"""

import subprocess
import time
import csv
import json
import requests
import urllib.parse
import datetime
import os
import threading
from concurrent.futures import ThreadPoolExecutor
import signal
import sys

# 云服务配置
CLOUD_BASE_URL = "http://127.0.0.1:5000"
CLOUD_HOST_IP = "172.16.253.246"
APK_PATH = "C:\\Program Files (x86)\\WuhanMoyuntengNetWork\\MYT_Zeus\\Shared\\shopee-tw-3-28-34.apk"

# 测试配置
DEEPLINK_FILE = r"C:\Users\Apple\Desktop\MYt_TEST\data1.csv"
SHOPEE_PACKAGE = "com.shopee.tw"
BATCH_SIZE = 7

# 严格时序配置
APK_INSTALL_WAIT = 15      # APK安装后等待时间
APP_STARTUP_WAIT = 8       # 应用启动后等待时间
CLICK_DELAY = 9            # 点击后等待时间
DEEPLINK_INTERVAL = 5      # deeplink间隔时间
CLICK_INTERVAL = 2         # 两次点击之间的间隔（新增）

# 启动状态检查配置
MAX_BOOT_CHECK_TIME = 180  # 最长等待启动时间（秒）
BOOT_CHECK_INTERVAL = 5    # 启动检查间隔

# 重置状态检查配置（新增）
MAX_RESET_CHECK_TIME = 180  # 最长等待重置时间（秒）
RESET_CHECK_INTERVAL = 5    # 重置检查间隔

# 点击配置
CLICK_X = 340
CLICK_Y = 1160

# 截图配置
SCREENSHOT_DIR = r"D:\screenshots_626"
LOG_FILE = "multi_device_deeplink_test_0626.log"

# ========== 增强版ADB管理 ==========
# 全局ADB管理变量，避免并发冲突
_adb_lock = threading.Lock()
_last_server_restart = 0

class Logger:
    _lock = threading.Lock()
    
    @staticmethod
    def log(message, device="MAIN"):
        timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        log_entry = f"[{timestamp}][{device}] {message}"
        
        with Logger._lock:
            try:
                with open(LOG_FILE, "a", encoding="utf-8") as f:
                    f.write(log_entry + "\n")
            except:
                pass
            print(log_entry)

def run_adb_safe(cmd, device_name, timeout=15, silent=False):
    """安全的ADB命令执行 - 增强版"""
    try:
        if not silent:
            Logger.log(f"🔧 执行: {cmd}", device_name)
        
        result = subprocess.run(
            cmd, 
            shell=True, 
            capture_output=True, 
            text=True, 
            timeout=timeout,
            encoding='utf-8',
            errors='ignore'
        )
        
        success = result.returncode == 0
        stdout = result.stdout.strip()
        stderr = result.stderr.strip()
        
        if not silent:
            if success:
                Logger.log(f"✅ 命令成功: {stdout[:100]}", device_name)
            else:
                Logger.log(f"❌ 命令失败: {stderr[:100]}", device_name)
        
        return success, stdout, stderr
        
    except subprocess.TimeoutExpired:
        Logger.log(f"⏱️ 命令超时: {cmd}", device_name)
        return False, "", f"超时({timeout}秒)"
    except Exception as e:
        Logger.log(f"❌ 命令异常: {e}", device_name)
        return False, "", str(e)

def restart_adb_server_smart():
    """智能重启ADB服务器 - 避免频繁重启"""
    global _last_server_restart
    
    with _adb_lock:
        current_time = time.time()
        
        # 30秒内不重复重启
        if current_time - _last_server_restart < 30:
            Logger.log("🔄 ADB服务器最近已重启，跳过")
            return True
        
        Logger.log("🔄 重启ADB服务器")
        
        # 停止ADB服务器
        subprocess.run("adb kill-server", shell=True, capture_output=True, timeout=10)
        time.sleep(2)
        
        # 启动ADB服务器
        result = subprocess.run("adb start-server", shell=True, capture_output=True, timeout=15)
        
        if result.returncode == 0:
            _last_server_restart = current_time
            Logger.log("✅ ADB服务器重启成功")
            time.sleep(3)  # 等待服务器完全启动
            return True
        else:
            Logger.log("❌ ADB服务器重启失败")
            return False

def check_device_status(device_ip, device_name):
    """检查设备状态: device, offline, unauthorized, not_found"""
    success, stdout, _ = run_adb_safe("adb devices", device_name, timeout=10, silent=True)
    
    if not success:
        return "unknown"
    
    # 解析设备状态
    for line in stdout.split('\n'):
        if device_ip in line:
            parts = line.split()
            if len(parts) >= 2:
                return parts[1]  # device, offline, unauthorized 等
    
    return "not_found"

def recover_offline_device(device_ip, device_name):
    """专门恢复offline设备"""
    Logger.log("🔧 尝试恢复offline设备", device_name)
    
    # 方法1: 断开重连
    Logger.log("🔌 方法1: 断开重连", device_name)
    run_adb_safe(f"adb disconnect {device_ip}", device_name, timeout=10, silent=True)
    time.sleep(3)
    
    success, stdout, _ = run_adb_safe(f"adb connect {device_ip}", device_name, timeout=15, silent=True)
    if success and "connected" in stdout.lower():
        time.sleep(2)
        if check_device_status(device_ip, device_name) == "device":
            Logger.log("✅ 断开重连成功恢复", device_name)
            return True
    
    # 方法2: 重启ADB服务器后重连
    Logger.log("🔄 方法2: 重启ADB服务器", device_name)
    if restart_adb_server_smart():
        time.sleep(5)
        
        success, stdout, _ = run_adb_safe(f"adb connect {device_ip}", device_name, timeout=15, silent=True)
        if success and "connected" in stdout.lower():
            time.sleep(2)
            if check_device_status(device_ip, device_name) == "device":
                Logger.log("✅ 重启ADB后恢复成功", device_name)
                return True
    
    # 方法3: 强制多次重试
    Logger.log("🔄 方法3: 强制多次重试", device_name)
    for i in range(3):
        run_adb_safe(f"adb disconnect {device_ip}", device_name, timeout=5, silent=True)
        time.sleep(2)
        
        success, stdout, _ = run_adb_safe(f"adb connect {device_ip}", device_name, timeout=10, silent=True)
        if success and "connected" in stdout.lower():
            time.sleep(2)
            if check_device_status(device_ip, device_name) == "device":
                Logger.log(f"✅ 第{i+1}次重试成功", device_name)
                return True
        time.sleep(3)
    
    Logger.log("❌ 所有恢复方法都失败", device_name)
    return False

def ensure_connection(device_ip, device_name):
    """增强版连接确保函数 - 替换原来的ensure_connection"""
    Logger.log(f"🔧 建立稳定连接", device_name)
    
    max_attempts = 5
    
    for attempt in range(max_attempts):
        Logger.log(f"🔗 连接尝试 {attempt + 1}/{max_attempts}", device_name)
        
        # 检查当前状态
        current_status = check_device_status(device_ip, device_name)
        Logger.log(f"📊 设备状态: {current_status}", device_name)
        
        if current_status == "device":
            # 测试通信
            success, stdout, _ = run_adb_safe(f"adb -s {device_ip} shell echo 'test'", device_name, timeout=10, silent=True)
            if success and "test" in stdout:
                Logger.log("✅ 连接正常", device_name)
                return True
            else:
                Logger.log("⚠️ 状态正常但通信失败", device_name)
        
        # 处理不同的异常状态
        if current_status == "offline":
            Logger.log("⚠️ 设备offline，尝试恢复", device_name)
            if recover_offline_device(device_ip, device_name):
                continue  # 恢复成功，重新检查
        
        # 强制断开重连
        Logger.log("🔌 强制断开重连", device_name)
        run_adb_safe(f"adb disconnect {device_ip}", device_name, timeout=10, silent=True)
        time.sleep(2)
        
        # 尝试连接
        success, stdout, stderr = run_adb_safe(f"adb connect {device_ip}", device_name, timeout=15, silent=True)
        
        if success and any(keyword in stdout.lower() for keyword in ['connected', 'already connected']):
            Logger.log(f"✅ 连接成功: {stdout}", device_name)
            time.sleep(2)  # 等待连接稳定
            
            # 验证连接
            if check_device_status(device_ip, device_name) == "device":
                success, test_stdout, _ = run_adb_safe(f"adb -s {device_ip} shell echo 'test'", device_name, timeout=10, silent=True)
                if success and "test" in test_stdout:
                    Logger.log("✅ 连接验证成功", device_name)
                    return True
        else:
            Logger.log(f"❌ 连接失败: {stderr}", device_name)
        
        # 第3次尝试时重启ADB服务器
        if attempt == 2:
            Logger.log("🔄 第3次尝试，重启ADB服务器", device_name)
            restart_adb_server_smart()
            time.sleep(5)
        
        # 等待后重试
        if attempt < max_attempts - 1:
            wait_time = 3 + attempt  # 递增等待时间
            Logger.log(f"⏱️ 等待{wait_time}秒后重试", device_name)
            time.sleep(wait_time)
    
    Logger.log("❌ 所有连接尝试都失败", device_name)
    return False

# ========== 云机API控制 ==========
class CloudAPI:
    """云机API控制类"""
    
    @staticmethod
    def get_device_list():
        """获取设备列表"""
        url = f"{CLOUD_BASE_URL}/dc_api/v1/list/{CLOUD_HOST_IP}"
        try:
            response = requests.get(url, timeout=30)
            if response.status_code == 200:
                data = response.json()
                if data.get('code') == 200 and 'data' in data:
                    return data['data']
            return []
        except Exception as e:
            Logger.log(f"❌ 获取设备列表失败: {e}")
            return []
    
    @staticmethod
    def check_android_boot_status(machine_name, device_name):
        """检查Android启动状态"""
        url = f"{CLOUD_BASE_URL}/get_android_boot_status/{CLOUD_HOST_IP}/{machine_name}"
        params = {"isblock": 0, "timeout": 10}
        
        Logger.log("🔍 检查Android启动状态", device_name)
        start_time = time.time()
        
        while time.time() - start_time < MAX_BOOT_CHECK_TIME:
            try:
                response = requests.get(url, params=params, timeout=15)
                if response.status_code == 200:
                    data = response.json()
                    code = data.get('code')
                    
                    if code == 200:
                        Logger.log("✅ Android系统启动完成！", device_name)
                        return True
                    elif code == 201:
                        elapsed = int(time.time() - start_time)
                        Logger.log(f"📱 系统启动中... (已等待{elapsed}秒)", device_name)
                    else:
                        Logger.log(f"启动检查返回: code={code}", device_name)
            except Exception as e:
                Logger.log(f"启动检查请求异常: {e}", device_name)
            
            time.sleep(BOOT_CHECK_INTERVAL)
        
        Logger.log("⚠️ Android启动检查超时", device_name)
        return False
    
    @staticmethod
    def run_android_container(machine_name, device_name):
        """启动Android容器"""
        url = f"{CLOUD_BASE_URL}/run/{CLOUD_HOST_IP}/{machine_name}"
        
        Logger.log("🏃 启动Android容器", device_name)
        try:
            response = requests.get(url, timeout=60)
            if response.status_code == 200:
                data = response.json()
                if data.get('code') == 200:
                    Logger.log("✅ Android容器启动请求已发送", device_name)
                    return True
        except Exception as e:
            Logger.log(f"Android容器启动异常: {e}", device_name)
        
        Logger.log("❌ Android容器启动失败", device_name)
        return False
    
    @staticmethod
    def stop_android_container(machine_name, device_name):
        """关闭Android容器"""
        url = f"{CLOUD_BASE_URL}/stop/{CLOUD_HOST_IP}/{machine_name}"
        
        Logger.log("🛑 关闭Android容器", device_name)
        try:
            response = requests.get(url, timeout=30)
            if response.status_code == 200:
                Logger.log("✅ Android容器关闭请求已发送", device_name)
                return True
        except Exception as e:
            Logger.log(f"Android容器关闭异常: {e}", device_name)
        
        Logger.log("❌ Android容器关闭失败", device_name)
        return False

def ensure_android_running(machine_name, device_name):
    """确保Android系统运行 - 增强重试版本"""
    Logger.log("🔧 检查并确保Android系统运行", device_name)
    
    # 首先检查启动状态
    if CloudAPI.check_android_boot_status(machine_name, device_name):
        Logger.log("✅ Android系统已经运行", device_name)
        return True
    
    # 如果未运行，尝试启动（最多重试3次）
    for attempt in range(3):
        Logger.log(f"🚀 Android未运行，尝试启动 (第{attempt + 1}/3次)", device_name)
        
        if CloudAPI.run_android_container(machine_name, device_name):
            # 启动后再次检查状态
            Logger.log("⏱️ 等待Android启动完成...", device_name)
            if CloudAPI.check_android_boot_status(machine_name, device_name):
                Logger.log("✅ Android启动成功", device_name)
                return True
            else:
                Logger.log(f"❌ 第{attempt + 1}次启动失败或超时", device_name)
                if attempt < 2:  # 不是最后一次尝试
                    Logger.log("🔄 尝试重启容器", device_name)
                    restart_android_container(machine_name, device_name)
        else:
            Logger.log(f"❌ 第{attempt + 1}次无法启动Android容器", device_name)
            if attempt < 2:
                Logger.log("⏱️ 等待10秒后重试", device_name)
                time.sleep(10)
    
    Logger.log("❌ 多次尝试后仍无法启动Android", device_name)
    return False

def restart_android_container(machine_name, device_name):
    """重启Android容器"""
    Logger.log("🔄 重启Android容器", device_name)
    
    # 先关闭
    CloudAPI.stop_android_container(machine_name, device_name)
    Logger.log("⏱️ 等待5秒让容器完全关闭", device_name)
    time.sleep(5)
    
    # 再启动
    if CloudAPI.run_android_container(machine_name, device_name):
        Logger.log("⏱️ 等待Android重启完成...", device_name)
        if CloudAPI.check_android_boot_status(machine_name, device_name):
            Logger.log("✅ Android容器重启成功", device_name)
            return True
        else:
            Logger.log("❌ Android重启后启动失败", device_name)
            return False
    else:
        Logger.log("❌ Android容器重启失败", device_name)
        return False

def reset_cloud_machine(machine_id, machine_name, device_name):
    """重置云机 - 优化版，使用智能状态检测替代固定等待"""
    url = f"{CLOUD_BASE_URL}/reset/{CLOUD_HOST_IP}/{machine_id}"
    Logger.log(f"🔄 开始重置云机", device_name)
    
    try:
        response = requests.get(url, timeout=30)
        Logger.log(f"✅ 重置请求已发送", device_name)
    except:
        Logger.log(f"⚠️ 重置请求失败", device_name)
    
    # 智能等待云机重置完成
    Logger.log(f"🔍 智能检测云机重置状态...", device_name)
    
    start_time = time.time()
    last_status_check = time.time()
    
    # 首先等待一段时间，让重置过程开始
    initial_wait = 20
    Logger.log(f"⏱️ 初始等待{initial_wait}秒让重置过程开始", device_name)
    time.sleep(initial_wait)
    
    # 开始智能检测
    while time.time() - start_time < MAX_RESET_CHECK_TIME:
        elapsed = int(time.time() - start_time)
        
        # 尝试检查Android状态
        try:
            # 使用短超时检查状态，避免阻塞
            url_check = f"{CLOUD_BASE_URL}/get_android_boot_status/{CLOUD_HOST_IP}/{machine_name}"
            params = {"isblock": 0, "timeout": 5}
            
            response = requests.get(url_check, params=params, timeout=10)
            if response.status_code == 200:
                data = response.json()
                code = data.get('code')
                
                if code == 200:
                    Logger.log(f"✅ 云机重置完成，Android系统已启动！(耗时{elapsed}秒)", device_name)
                    # 额外等待几秒确保系统稳定
                    Logger.log("⏱️ 等待5秒确保系统稳定", device_name)
                    time.sleep(5)
                    return True
                elif code == 201:
                    Logger.log(f"📱 云机重置中，系统正在启动... (已等待{elapsed}秒)", device_name)
                else:
                    # 可能还在重置过程中
                    Logger.log(f"🔄 云机仍在重置中... (已等待{elapsed}秒)", device_name)
        except Exception as e:
            # 请求失败可能表示系统还在重置
            if time.time() - last_status_check > 10:
                Logger.log(f"🔄 云机重置中... (已等待{elapsed}秒)", device_name)
                last_status_check = time.time()
        
        time.sleep(RESET_CHECK_INTERVAL)
    
    # 如果超时，使用备用等待时间
    Logger.log(f"⚠️ 智能检测超时，使用备用等待30秒", device_name)
    time.sleep(30)
    
    # 最后尝试确认状态
    if CloudAPI.check_android_boot_status(machine_name, device_name):
        Logger.log(f"✅ 云机重置完成", device_name)
        return True
    else:
        Logger.log(f"⚠️ 云机重置可能未完成，继续执行", device_name)
        return False

def install_apk(machine_id, device_name):
    """安装APK"""
    encoded_path = urllib.parse.quote(APK_PATH)
    url = f"{CLOUD_BASE_URL}/install_apk/{CLOUD_HOST_IP}/{machine_id}?local={encoded_path}"
    Logger.log(f"📦 开始安装APK", device_name)
    
    try:
        response = requests.get(url, timeout=120)
        Logger.log(f"📦 APK安装请求已发送", device_name)
    except Exception as e:
        Logger.log(f"📦 APK安装请求异常: {str(e)}", device_name)

def normalize_shopee_link(link):
    """标准化Shopee链接格式"""
    if link.startswith('/'):
        link = f"https://shopee.tw{link}"
    elif not link.startswith(('http://', 'https://')):
        link = f"https://shopee.tw/{link.lstrip('/')}"
    return link

def open_shopee(device_ip, device_name):
    """增强版Shopee启动函数 - 使用最稳定的固定种子monkey"""
    Logger.log(f"🚀 启动Shopee (增强版)", device_name)
    
    # 确保连接稳定
    if not ensure_connection(device_ip, device_name):
        Logger.log("❌ 无法建立稳定连接", device_name)
        return False
    
    # 停止现有应用
    Logger.log("🛑 停止现有Shopee", device_name)
    success, _, _ = run_adb_safe(f"adb -s {device_ip} shell am force-stop {SHOPEE_PACKAGE}", device_name, timeout=10, silent=True)
    time.sleep(2)
    
    # 使用最稳定的固定种子monkey启动 (基于测试结果：100%成功率，0.51秒平均耗时)
    Logger.log("🐒 使用固定种子monkey启动(最稳定方式)", device_name)
    success, stdout, stderr = run_adb_safe(
        f"adb -s {device_ip} shell monkey -p {SHOPEE_PACKAGE} -c android.intent.category.LAUNCHER -s 1000 1",
        device_name, 
        timeout=15
    )
    
    if success and ("Events injected:" in stdout or "Monkey finished" in stdout):
        Logger.log("✅ monkey启动命令成功", device_name)
        
        # 验证应用是否真的启动了
        time.sleep(3)
        verify_success, verify_output, _ = run_adb_safe(
            f"adb -s {device_ip} shell pidof {SHOPEE_PACKAGE}",
            device_name,
            timeout=10,
            silent=True
        )
        
        if verify_success and verify_output.strip():
            Logger.log(f"✅ Shopee启动成功，PID: {verify_output.strip()}", device_name)
            return True
        else:
            Logger.log("❌ monkey成功但应用未运行", device_name)
    else:
        Logger.log(f"❌ monkey启动失败: {stderr}", device_name)
        
        # 如果是连接问题，尝试重连后再试
        if "device offline" in stderr or "device not found" in stderr:
            Logger.log("🔄 检测到连接问题，重连后重试", device_name)
            if ensure_connection(device_ip, device_name):
                # 重新尝试启动
                success2, stdout2, stderr2 = run_adb_safe(
                    f"adb -s {device_ip} shell monkey -p {SHOPEE_PACKAGE} -c android.intent.category.LAUNCHER -s 1000 1",
                    device_name,
                    timeout=15
                )
                
                if success2 and ("Events injected:" in stdout2 or "Monkey finished" in stdout2):
                    Logger.log("✅ 重连后启动成功", device_name)
                    return True
                else:
                    Logger.log(f"❌ 重连后仍失败: {stderr2}", device_name)
    
    return False

def click_popup(device_ip, device_name):
    """优化版点击弹窗 - 两次点击，间隔2秒"""
    Logger.log(f"🎯 开始处理弹窗（两次点击）", device_name)
    
    # 第一次点击
    Logger.log(f"🎯 第1次点击弹窗 ({CLICK_X}, {CLICK_Y})", device_name)
    success1, _, _ = run_adb_safe(f"adb -s {device_ip} shell input tap {CLICK_X} {CLICK_Y}", device_name, timeout=10, silent=True)
    
    if success1:
        Logger.log(f"✅ 第1次弹窗点击成功", device_name)
    else:
        Logger.log(f"❌ 第1次弹窗点击失败", device_name)
    
    # 等待2秒
    Logger.log(f"⏱️ 等待{CLICK_INTERVAL}秒后进行第2次点击", device_name)
    time.sleep(CLICK_INTERVAL)
    
    # 最后等待确保弹窗完全过掉
    Logger.log(f"⏱️ 等待{CLICK_DELAY}秒确保弹窗完全过掉...", device_name)
    time.sleep(CLICK_DELAY)

     # 第二次点击
    Logger.log(f"🎯 第2次点击弹窗 ({CLICK_X}, {CLICK_Y})", device_name)
    success2, _, _ = run_adb_safe(f"adb -s {device_ip} shell input tap {CLICK_X} {CLICK_Y}", device_name, timeout=10, silent=True)
    
    if success2:
        Logger.log(f"✅ 第2次弹窗点击成功", device_name)
    else:
        Logger.log(f"❌ 第2次弹窗点击失败", device_name)
        
    # 返回两次点击是否都成功
    return success1 and success2

def execute_deeplink_test(device_ip, device_name, deeplink):
    """增强版deeplink测试 - 加强连接检查"""
    # 在执行deeplink前确保连接稳定
    if check_device_status(device_ip, device_name) != "device":
        Logger.log("⚠️ deeplink前检测到连接异常，尝试恢复", device_name)
        if not ensure_connection(device_ip, device_name):
            Logger.log("❌ deeplink前连接恢复失败", device_name)
            return False
    
    # 标准化链接
    normalized_link = normalize_shopee_link(deeplink)
    
    try:
        Logger.log(f"🔗 访问链接: {normalized_link[:50]}...", device_name)
        
        # 确保Shopee在前台
        run_adb_safe(f"adb -s {device_ip} shell monkey -p {SHOPEE_PACKAGE} 1", device_name, timeout=5, silent=True)
        time.sleep(1)
        
        # 执行deeplink
        cmd = f"adb -s {device_ip} shell am start -W -a android.intent.action.VIEW -d '{normalized_link}' {SHOPEE_PACKAGE}"
        success, stdout, stderr = run_adb_safe(cmd, device_name, timeout=10)
        
        if success and "Error" not in stderr:
            Logger.log(f"✅ 链接访问成功", device_name)
            return True
        else:
            # 检查是否是连接问题
            if "device offline" in stderr or "device not found" in stderr:
                Logger.log("🔄 deeplink时连接异常，尝试恢复", device_name)
                if ensure_connection(device_ip, device_name):
                    # 重试deeplink
                    success2, stdout2, stderr2 = run_adb_safe(cmd, device_name, timeout=10)
                    if success2 and "Error" not in stderr2:
                        Logger.log("✅ 重连后deeplink成功", device_name)
                        return True
            
            Logger.log(f"❌ 链接访问失败: {stderr}", device_name)
            return False
            
    except Exception as e:
        Logger.log(f"❌ deeplink异常: {e}", device_name)
        return False

def take_screenshot(device_ip, device_name, batch_num, cycle_num):
    """截图功能"""
    try:
        os.makedirs(SCREENSHOT_DIR, exist_ok=True)
        
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"{device_name}_{timestamp}.png"
        screenshot_path = os.path.join(SCREENSHOT_DIR, filename)
        
        Logger.log(f"📸 开始截图 - 设备:{device_name} 文件:{filename}", device_name)
        
        if os.name == 'nt':
            cmd = f'adb -s {device_ip} exec-out screencap -p > "{screenshot_path}"'
        else:
            cmd = f"adb -s {device_ip} exec-out screencap -p > '{screenshot_path}'"
            
        result = subprocess.run(cmd, shell=True, timeout=15)
        
        if result.returncode == 0 and os.path.exists(screenshot_path):
            file_size = os.path.getsize(screenshot_path)
            if file_size > 1000:
                Logger.log(f"✅ 截图成功 - 设备:{device_name} 文件:{filename} 大小:{file_size}字节", device_name)
                return screenshot_path
            else:
                Logger.log(f"❌ 截图文件太小 - 设备:{device_name} 大小:{file_size}字节", device_name)
                try:
                    os.remove(screenshot_path)
                except:
                    pass
                return None
        else:
            Logger.log(f"❌ 截图命令失败 - 设备:{device_name} 返回码:{result.returncode}", device_name)
            return None
    except Exception as e:
        Logger.log(f"❌ 截图异常 - 设备:{device_name} 错误:{str(e)}", device_name)
        return None

def load_deeplinks():
    """加载deeplinks - 支持纯文本格式（每行一个链接）"""
    try:
        with open(DEEPLINK_FILE, encoding='utf-8') as f:
            content = f.read().strip()
            links = []
            
            # 按行分割，每行一个链接
            for line in content.split('\n'):
                line = line.strip()
                if line and line.startswith('http'):
                    links.append(line)
            
            # 如果没有找到http链接，尝试CSV格式作为备用
            if not links:
                f.seek(0)
                try:
                    reader = csv.DictReader(f)
                    for row in reader:
                        url = row.get('url') or row.get('deeplink') or row.get('link')
                        if url and url.strip():
                            links.append(url.strip())
                except:
                    pass
            
            if links:
                Logger.log(f"✅ 加载{len(links)}条链接")
                return links
            else:
                Logger.log(f"❌ 文件中未找到有效链接")
                return ["https://shopee.tw/", "https://shopee.tw/search?keyword=test"]
            
    except Exception as e:
        Logger.log(f"❌ 无法加载文件: {DEEPLINK_FILE}, 错误: {e}")
        return ["https://shopee.tw/", "https://shopee.tw/search?keyword=test"]

def save_progress(device_name, stats):
    """保存进度"""
    try:
        progress_data = {
            'timestamp': time.time(),
            'device': device_name,
            'stats': stats
        }
        progress_file = f"progress_{device_name}.json"
        with open(progress_file, 'w', encoding='utf-8') as f:
            json.dump(progress_data, f, ensure_ascii=False, indent=2)
    except:
        pass

def device_worker(device_info, all_links, stop_event, device_index, total_devices):
    """设备工作线程 - 优化版"""
    device_name = device_info["name"]
    device_ip = device_info["ip"]
    machine_id = device_info["machine_id"]
    machine_name = device_info["name"]
    
    stats = {
        'total_cycles': 0,
        'total_tested': 0,
        'total_success': 0,
        'start_time': time.time()
    }
    
    Logger.log(f"🚀 设备工作线程启动 - 设备索引:{device_index}/{total_devices}", device_name)
    
    # 错开启动时间，避免并发冲突
    startup_delay = 10 + device_index * 5
    Logger.log(f"⏱️ 错开启动，等待{startup_delay}秒", device_name)
    time.sleep(startup_delay)
    
    # 为每台设备分配不同的链接段，避免重复任务
    device_links = []
    for i in range(device_index, len(all_links), total_devices):
        device_links.append(all_links[i])
    
    Logger.log(f"📋 分配{len(device_links)}条链接给设备{device_name}", device_name)
    
    link_index = 0
    first_run = True
    
    try:
        while not stop_event.is_set() and link_index < len(device_links):
            stats['total_cycles'] += 1
            
            Logger.log(f"\n{'='*30}", device_name)
            Logger.log(f"🔄 第{stats['total_cycles']}轮测试开始", device_name)
            Logger.log(f"{'='*30}", device_name)
            
            # 确保Android运行
            if first_run:
                Logger.log("🔧 首次运行，确保Android系统运行", device_name)
                if not ensure_android_running(machine_name, device_name):
                    Logger.log("❌ 无法确保Android运行，跳过本轮", device_name)
                    continue
                first_run = False
            else:
                Logger.log("🔧 检查Android系统状态", device_name)
                if not CloudAPI.check_android_boot_status(machine_name, device_name):
                    Logger.log("⚠️ Android未运行，尝试启动", device_name)
                    if not ensure_android_running(machine_name, device_name):
                        Logger.log("❌ 无法启动Android，跳过本轮", device_name)
                        continue
            
            # 步骤1: 安装APK
            install_apk(machine_id, device_name)
            
            # 步骤2: 等待APK安装
            Logger.log(f"⏱️ 等待APK安装完成 {APK_INSTALL_WAIT}秒", device_name)
            time.sleep(APK_INSTALL_WAIT)
            
            # 步骤3: 启动Shopee
            shopee_opened = open_shopee(device_ip, device_name)
            
            if shopee_opened:
                # 步骤4: 等待Shopee完全启动
                Logger.log(f"⏱️ 等待Shopee完全启动 {APP_STARTUP_WAIT}秒", device_name)
                time.sleep(APP_STARTUP_WAIT)
                
                # 步骤5: 点击弹窗（优化版，两次点击）
                click_popup(device_ip, device_name)
                
                # 步骤6: 测试deeplinks
                Logger.log(f"🎯 开始测试deeplinks", device_name)
                
                batch_tested = 0
                batch_success = 0
                
                while batch_tested < BATCH_SIZE and link_index < len(device_links) and not stop_event.is_set():
                    link = device_links[link_index]
                    link_index += 1
                    batch_tested += 1
                    stats['total_tested'] += 1
                    
                    Logger.log(f"📍 第{batch_tested}/{BATCH_SIZE}条 (设备总第{stats['total_tested']}条)", device_name)
                    
                    # 执行deeplink测试
                    if execute_deeplink_test(device_ip, device_name, link):
                        batch_success += 1
                        stats['total_success'] += 1
                    
                    # 在第三条deeplink时截图
                    if batch_tested == 3:
                        Logger.log(f"📸 第三条deeplink完成，等待5秒后截图", device_name)
                        time.sleep(5)
                        take_screenshot(device_ip, device_name, stats['total_cycles'], batch_tested)
                        Logger.log(f"📸 截图完成，再等待3秒后继续", device_name)
                        time.sleep(3)
                    
                    # 测试间隔
                    if batch_tested < BATCH_SIZE and link_index < len(device_links):
                        Logger.log(f"⏱️ 等待{DEEPLINK_INTERVAL}秒后继续", device_name)
                        time.sleep(DEEPLINK_INTERVAL)
                
                # 统计
                success_rate = (batch_success / batch_tested * 100) if batch_tested > 0 else 0
                total_success_rate = (stats['total_success'] / stats['total_tested'] * 100) if stats['total_tested'] > 0 else 0
                
                Logger.log(f"📊 第{stats['total_cycles']}轮完成: {batch_tested}条, 成功{batch_success}条({success_rate:.1f}%)", device_name)
                Logger.log(f"📊 累计: {stats['total_tested']}条, 成功{stats['total_success']}条({total_success_rate:.1f}%)", device_name)
                
            else:
                Logger.log(f"❌ Shopee启动失败，跳过本轮测试", device_name)
            
            # 步骤7: 重置云机准备下一轮（使用优化版重置函数）
            if link_index < len(device_links):
                Logger.log(f"🔄 测试完成，智能重置云机准备下一轮", device_name)
                reset_cloud_machine(machine_id, machine_name, device_name)
            
            # 保存进度
            save_progress(device_name, stats)
            
            # 继续下一轮
            if link_index < len(device_links):
                Logger.log(f"⏱️ 准备下一轮测试", device_name)
            else:
                Logger.log(f"🏁 设备分配的所有链接测试完成", device_name)
    
    except Exception as e:
        Logger.log(f"❌ 设备线程异常: {e}", device_name)
    
    # 最终统计
    elapsed_time = time.time() - stats['start_time']
    Logger.log(f"\n🏁 设备{device_name}测试结束", device_name)
    Logger.log(f"📊 总轮次: {stats['total_cycles']}", device_name)
    Logger.log(f"📊 总测试: {stats['total_tested']}条", device_name)
    Logger.log(f"📊 总成功: {stats['total_success']}条", device_name)
    Logger.log(f"📊 成功率: {(stats['total_success']/stats['total_tested']*100) if stats['total_tested'] > 0 else 0:.1f}%", device_name)
    Logger.log(f"⏱️ 运行时间: {elapsed_time/3600:.1f}小时", device_name)

def main():
    """主函数"""
    stop_event = threading.Event()
    
    def signal_handler(signum, frame):
        Logger.log("🛑 收到中断信号")
        stop_event.set()
    
    signal.signal(signal.SIGINT, signal_handler)
    
    Logger.log("🚀 启动多设备云机deeplink测试器 - 优化版本")
    Logger.log(f"📡 云服务地址: {CLOUD_BASE_URL}")
    Logger.log(f"🖥️ 主机IP: {CLOUD_HOST_IP}")
    Logger.log(f"⚙️ 批次大小: {BATCH_SIZE}条/轮")
    Logger.log(f"🛡️ 优化功能: 两次点击处理弹窗、智能重置状态检测")
    Logger.log(f"🎯 使用固定种子monkey启动(100%成功率，0.51秒平均耗时)")
    Logger.log(f"🔧 并发冲突避免: 全局ADB锁、错开启动、智能重试")
    
    # 自动获取设备列表
    Logger.log("🔍 自动获取设备列表...")
    devices = CloudAPI.get_device_list()
    if not devices:
        Logger.log("❌ 未获取到设备列表")
        return
    
    # 筛选running状态的设备
    device_list = []
    running_count = 0
    
    for device in devices:
        if device.get('state') == 'running':
            device_name = device.get('name', 'Unknown')
            device_ip = device.get('ip', 'Unknown')
            machine_id = device.get('id', 'Unknown')
            
            Logger.log(f"📱 设备: {device_name} - IP: {device_ip}")
            
            device_info = {
                'name': device_name,
                'ip': f"{device_ip}:5555",
                'machine_id': machine_id
            }
            device_list.append(device_info)
            running_count += 1
    
    Logger.log(f"✅ 发现{running_count}个运行中的设备")
    
    if not device_list:
        Logger.log("❌ 没有运行中的设备")
        return
    
    # 加载deeplinks
    all_links = load_deeplinks()
    if not all_links:
        Logger.log("❌ 未找到链接")
        return
    
    Logger.log(f"✅ 加载{len(all_links)}条链接")
    
    # 显示任务分配预览
    Logger.log("📋 任务分配预览:")
    for i, device in enumerate(device_list):
        device_link_count = len(range(i, len(all_links), len(device_list)))
        Logger.log(f"   {device['name']}: {device_link_count}条链接")
    
    try:
        # 启动设备线程
        with ThreadPoolExecutor(max_workers=len(device_list)) as executor:
            futures = []
            for device_index, device in enumerate(device_list):
                future = executor.submit(device_worker, device, all_links, stop_event, device_index, len(device_list))
                futures.append(future)
                Logger.log(f"✅ 启动设备: {device['name']} (索引:{device_index})", device['name'])
                time.sleep(2)  # 错开线程创建
            
            # 等待完成
            for future in futures:
                try:
                    future.result()
                except Exception as e:
                    Logger.log(f"❌ 线程异常: {e}")
        
        Logger.log("🏁 所有测试完成")
        
    except KeyboardInterrupt:
        Logger.log("⏹️ 用户中断")
        stop_event.set()
    except Exception as e:
        Logger.log(f"❌ 程序异常: {e}")

if __name__ == "__main__":
    main()