#!/usr/bin/env python3
"""
云机群控脚本 - 模块化重构版

功能：自动化测试Shopee deeplink
流程：安装APP → 启动 → deeplink测试 → 卸载 → 更换设备信息 → 循环

模块结构：
- config: 配置管理
- logger: 日志系统
- cloud_api: 云机API封装
- device_manager: 设备信息管理
- adb_controller: ADB操作控制
- utils: 工具函数
- worker: 设备工作流程
- main: 主程序入口
"""

import subprocess
import time
import csv
import json
import requests
import urllib.parse
import datetime
import os
import threading
import re
from concurrent.futures import ThreadPoolExecutor
import signal
import sys
from typing import List, Dict, Tuple, Optional
from dataclasses import dataclass
from enum import Enum


# ==================== 配置模块 ====================

@dataclass
class Config:
    """全局配置类"""
    # 云服务配置
    CLOUD_BASE_URL: str = "http://127.0.0.1:9000"
    CLOUD_HOST_IP: str = "172.16.253.249"
    
    # APK配置
    APK_PATH: str = "C:\\Program Files (x86)\\WuhanMoyuntengNetWork\\MYT_Zeus\\Shared\\shopee-tw-3-28-34.apk"
    SHOPEE_PACKAGE: str = "com.shopee.tw"
    
    # 测试配置
    DEEPLINK_FILE: str = "shopee_deals_10k.csv"
    BATCH_SIZE: int = 7
    
    # 时序配置（经过验证的时间）
    APP_STARTUP_WAIT: int = 8       # APP启动后等待
    CLICK_DELAY: int = 9            # 点击弹窗后等待
    DEEPLINK_INTERVAL: int = 5      # deeplink间隔 - 修改为5秒
    NETWORK_RECOVERY_WAIT: int = 15 # 设备信息更换后网络恢复时间
    UNINSTALL_WAIT: int = 3        # 卸载后等待
    INSTALL_WAIT: int = 5          # 安装后等待
    
    # UI配置
    CLICK_X: int = 340
    CLICK_Y: int = 1160
    
    # 文件配置
    SCREENSHOT_DIR: str = "screenshots"
    LOG_FILE: str = "cloud_control_optimized.log"
    
    # 重试配置
    MAX_INSTALL_RETRY: int = 2
    MAX_DEVICE_INFO_RETRY: int = 2
    MAX_NETWORK_CHECK: int = 3
    
    # 超时配置 - 新增40秒超时
    API_TIMEOUT: int = 40


class ErrorCode(Enum):
    """API错误码枚举"""
    SUCCESS = 200
    CONTAINER_NOT_EXIST = 0
    HOST_UNREACHABLE = 1
    ANDROID_NOT_RUNNING = 2
    OPERATION_FAILED = 3
    API_FAILED = 4


# ==================== 日志模块 ====================

class Logger:
    """线程安全的日志记录器"""
    _lock = threading.Lock()
    _config = Config()
    
    @staticmethod
    def log(message: str, device: str = "MAIN", level: str = "INFO"):
        """
        记录日志
        
        Args:
            message: 日志消息
            device: 设备名称
            level: 日志级别
        """
        timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        log_entry = f"[{timestamp}][{level}][{device}] {message}"
        
        with Logger._lock:
            # 写入文件
            try:
                with open(Logger._config.LOG_FILE, "a", encoding="utf-8") as f:
                    f.write(log_entry + "\n")
            except Exception:
                pass
            
            # 控制台输出
            print(log_entry)
    
    @staticmethod
    def error(message: str, device: str = "MAIN"):
        Logger.log(message, device, "ERROR")
    
    @staticmethod
    def warning(message: str, device: str = "MAIN"):
        Logger.log(message, device, "WARN")
    
    @staticmethod
    def info(message: str, device: str = "MAIN"):
        Logger.log(message, device, "INFO")


# ==================== 云API模块 ====================

class CloudAPI:
    """云机API操作封装"""
    
    def __init__(self, config: Config):
        self.config = config
        self.base_url = config.CLOUD_BASE_URL
        self.host_ip = config.CLOUD_HOST_IP
    
    def get_device_list(self) -> List[Dict]:
        """获取设备列表"""
        url = f"{self.base_url}/dc_api/v1/list/{self.host_ip}"
        try:
            response = requests.get(url, timeout=self.config.API_TIMEOUT)
            if response.status_code == 200:
                data = response.json()
                if data.get('code') == 200 and 'data' in data:
                    return data['data']
            return []
        except Exception as e:
            Logger.error(f"获取设备列表失败: {e}")
            return []
    
    def get_device_status(self, machine_id: str) -> Tuple[str, Optional[Dict]]:
        """获取单个设备状态"""
        try:
            devices = self.get_device_list()
            for device in devices:
                if device.get('id') == machine_id:
                    return device.get('state', ''), device
            return 'unknown', None
        except Exception as e:
            Logger.warning(f"获取状态异常: {e}")
            return 'error', None
    
    def run_android_container(self, machine_name: str, device_name: str) -> bool:
        """运行Android容器"""
        url = f"{self.base_url}/run/{self.host_ip}/{machine_name}"
        try:
            Logger.info("🏃 启动Android容器", device_name)
            response = requests.get(url, timeout=60)
            
            if response.status_code == 200:
                data = response.json()
                if data.get('code') == ErrorCode.SUCCESS.value:
                    Logger.info("✅ Android容器启动成功", device_name)
                    return True
            
            Logger.error(f"Android容器启动失败", device_name)
            return False
            
        except Exception as e:
            Logger.error(f"启动Android容器异常: {e}", device_name)
            return False
    
    def check_android_boot_status(self, machine_name: str, device_name: str) -> bool:
        """检查Android启动状态"""
        url = f"{self.base_url}/get_android_boot_status/{self.host_ip}/{machine_name}"
        params = {"isblock": 0, "timeout": 10}
        
        Logger.info("🔍 检查Android启动状态", device_name)
        max_attempts = 36  # 3分钟
        
        for attempt in range(max_attempts):
            try:
                response = requests.get(url, params=params, timeout=15)
                
                if response.status_code == 200:
                    data = response.json()
                    code = data.get('code')
                    msg = data.get('msg', '')
                    
                    if code == ErrorCode.SUCCESS.value and "启动完成" in msg:
                        Logger.info("✅ Android系统启动完成!", device_name)
                        return True
                    elif code == 201 and "启动未完成" in msg:
                        Logger.info(f"📱 Android启动中... ({attempt + 1}/{max_attempts})", device_name)
                        time.sleep(5)
                        continue
                    else:
                        Logger.error(f"Android启动失败: code={code}, msg={msg}", device_name)
                        return False
                        
            except Exception as e:
                Logger.warning(f"检查异常: {e}, 重试中...", device_name)
                time.sleep(5)
                continue
        
        Logger.error("Android启动检查超时", device_name)
        return False
    
    def install_apk(self, machine_name: str, device_name: str) -> bool:
        """安装APK"""
        encoded_path = urllib.parse.quote(self.config.APK_PATH)
        url = f"{self.base_url}/install_apk/{self.host_ip}/{machine_name}?local={encoded_path}"
        
        try:
            Logger.info("📦 开始安装APK", device_name)
            response = requests.get(url, timeout=120)
            
            if response.status_code == 200:
                data = response.json()
                code = data.get('code')
                msg = data.get('msg', '')
                
                if code == 0 and msg == 'Success':
                    Logger.info("✅ APK安装成功", device_name)
                    return True
                else:
                    Logger.error(f"安装失败: code={code}, msg={msg}", device_name)
                    return False
            else:
                Logger.error(f"HTTP错误: {response.status_code}", device_name)
                return False
                
        except requests.exceptions.Timeout:
            Logger.warning("安装请求超时，检查实际安装状态", device_name)
            return self.check_apk_installed(machine_name, device_name)
        except Exception as e:
            Logger.error(f"安装异常: {e}", device_name)
            return False
    
    def uninstall_apk(self, machine_name: str, device_name: str) -> bool:
        """卸载APK"""
        url = f"{self.base_url}/uninstall_apk/{self.host_ip}/{machine_name}/{self.config.SHOPEE_PACKAGE}"
        
        try:
            Logger.info(f"🗑️ 开始卸载 {self.config.SHOPEE_PACKAGE}", device_name)
            response = requests.get(url, timeout=60)
            
            if response.status_code == 200:
                data = response.json()
                code = data.get('code')
                
                if code == ErrorCode.SUCCESS.value:
                    Logger.info("✅ APK卸载成功", device_name)
                    return True
                else:
                    Logger.error(f"卸载失败: code={code}", device_name)
                    return False
            else:
                Logger.error(f"HTTP错误: {response.status_code}", device_name)
                return False
                
        except Exception as e:
            Logger.error(f"卸载异常: {e}", device_name)
            return False
    
    def run_apk(self, machine_name: str, device_name: str) -> bool:
        """启动APK"""
        url = f"{self.base_url}/run_apk/{self.host_ip}/{machine_name}/{self.config.SHOPEE_PACKAGE}"
        try:
            Logger.info(f"🚀 启动APP: {self.config.SHOPEE_PACKAGE}", device_name)
            response = requests.get(url, timeout=60)
            
            if response.status_code == 200:
                data = response.json()
                code = data.get('code')
                
                if code == ErrorCode.SUCCESS.value:
                    Logger.info("✅ APP启动成功", device_name)
                    Logger.info(f"⏱️ 等待APP完全加载 {self.config.APP_STARTUP_WAIT}秒", device_name)
                    time.sleep(self.config.APP_STARTUP_WAIT)
                    return True
                else:
                    Logger.error(f"APP启动失败: code={code}", device_name)
                    return False
            else:
                Logger.error(f"HTTP错误: {response.status_code}", device_name)
                return False
                
        except Exception as e:
            Logger.error(f"启动异常: {e}", device_name)
            return False
    
    def shell_command(self, machine_name: str, device_name: str, command: str) -> Tuple[bool, str]:
        """执行shell命令"""
        url = f"{self.base_url}/shell/{self.host_ip}/{machine_name}"
        data = {"cmd": command}
        
        try:
            response = requests.post(url, json=data, timeout=self.config.API_TIMEOUT)
            if response.status_code == 200:
                result = response.json()
                code = result.get('code', 0)
                msg = result.get('msg', '')
                shell_code = result.get('shell_code', -1)
                
                if code == ErrorCode.SUCCESS.value and shell_code == 0:
                    return True, msg
                else:
                    return False, msg
            else:
                return False, f"HTTP错误: {response.status_code}"
        except Exception as e:
            return False, f"请求异常: {e}"
    
    def check_apk_installed(self, machine_name: str, device_name: str) -> bool:
        """检查APK是否已安装"""
        Logger.info(f"🔍 检查{self.config.SHOPEE_PACKAGE}是否已安装", device_name)
        
        command = f"pm list packages | grep {self.config.SHOPEE_PACKAGE}"
        success, output = self.shell_command(machine_name, device_name, command)
        
        if success and self.config.SHOPEE_PACKAGE in output:
            Logger.info("✅ APK已安装", device_name)
            return True
        else:
            Logger.info("❌ APK未安装", device_name)
            return False


# ==================== 设备信息管理模块 ====================

class DeviceInfoManager:
    """设备信息管理器"""
    
    def __init__(self, config: Config, cloud_api: CloudAPI):
        self.config = config
        self.cloud_api = cloud_api
    
    def change_device_info(self, machine_name: str, device_name: str) -> bool:
        """
        更换设备信息 - 使用异步接口
        
        Returns:
            bool: 是否成功
        """
        for attempt in range(self.config.MAX_DEVICE_INFO_RETRY + 1):
            try:
                Logger.info(f"🔄 第{attempt + 1}次尝试更换设备信息", device_name)
                
                # 步骤1: 停止APP
                Logger.info("📱 停止Shopee APP", device_name)
                stop_cmd = f"am force-stop {self.config.SHOPEE_PACKAGE}"
                self.cloud_api.shell_command(machine_name, device_name, stop_cmd)
                time.sleep(2)
                
                # 步骤2: 调用异步API
                Logger.info("🎲 调用设备信息更换API", device_name)
                if not self._call_random_devinfo_api(machine_name, device_name):
                    if attempt < self.config.MAX_DEVICE_INFO_RETRY:
                        time.sleep(5)
                        continue
                    return False
                
                # 步骤3: 等待网络恢复
                Logger.info(f"⏳ 等待网络恢复 {self.config.NETWORK_RECOVERY_WAIT}秒", device_name)
                time.sleep(self.config.NETWORK_RECOVERY_WAIT)
                
                # 步骤4: 验证网络恢复
                if self._verify_network_recovery(machine_name, device_name):
                    Logger.info("✅ 设备信息更换成功", device_name)
                    return True
                else:
                    Logger.warning("网络未完全恢复", device_name)
                    if attempt < self.config.MAX_DEVICE_INFO_RETRY:
                        time.sleep(10)
                        continue
                        
            except Exception as e:
                Logger.error(f"更换设备信息异常: {e}", device_name)
                if attempt < self.config.MAX_DEVICE_INFO_RETRY:
                    time.sleep(5)
                    continue
        
        Logger.error("设备信息更换最终失败", device_name)
        return False
    
    def _call_random_devinfo_api(self, machine_name: str, device_name: str, 
                                 userip: Optional[str] = None, 
                                 modelid: Optional[str] = None) -> bool:
        """调用随机设备信息API"""
        url = f"{self.cloud_api.base_url}/random_devinfo_async/{self.cloud_api.host_ip}/{machine_name}"
        
        params = {}
        if userip:
            params['userip'] = userip
        if modelid:
            params['modelid'] = modelid
        
        try:
            response = requests.get(url, params=params if params else None, timeout=self.config.API_TIMEOUT)
            
            # 打印完整的响应信息
            Logger.info(f"📡 设备信息API响应状态码: {response.status_code}", device_name)
            
            if response.status_code == 200:
                data = response.json()
                code = data.get('code')
                
                # 打印完整的响应数据
                Logger.info(f"📡 设备信息API完整响应: {json.dumps(data, ensure_ascii=False)}", device_name)
                
                if code == ErrorCode.SUCCESS.value:
                    Logger.info("✅ 设备信息更换请求已接受", device_name)
                    return True
                else:
                    error_msgs = {
                        0: "容器不存在",
                        1: "主机不通",
                        2: "当前Android主机未运行",
                        3: "随机设备信息失败! 请检查Android网络!",
                        4: "获取容器api 接口失败!"
                    }
                    Logger.error(f"设备信息更换失败 - {error_msgs.get(code, '未知错误')} (code={code})", device_name)
                    return False
            else:
                Logger.error(f"HTTP错误: {response.status_code}, 响应内容: {response.text}", device_name)
                return False
                
        except Exception as e:
            Logger.error(f"设备信息请求异常: {e}", device_name)
            return False
    
    def _verify_network_recovery(self, machine_name: str, device_name: str) -> bool:
        """验证网络是否恢复"""
        for i in range(self.config.MAX_NETWORK_CHECK):
            try:
                success, output = self.cloud_api.shell_command(
                    machine_name, 
                    device_name, 
                    "getprop | grep ip"
                )
                if success:
                    Logger.info("✅ 网络连接已恢复", device_name)
                    return True
            except:
                pass
            
            if i < self.config.MAX_NETWORK_CHECK - 1:
                Logger.info(f"⏳ 网络恢复检查 {i+1}/{self.config.MAX_NETWORK_CHECK}", device_name)
                time.sleep(5)
        
        return False


# ==================== ADB控制模块 ====================

class ADBController:
    """ADB操作控制器"""
    
    def __init__(self, config: Config, cloud_api: CloudAPI):
        self.config = config
        self.cloud_api = cloud_api
    
    def click_popup(self, machine_name: str, device_name: str) -> bool:
        """点击弹窗"""
        Logger.info(f"🎯 点击弹窗 ({self.config.CLICK_X}, {self.config.CLICK_Y})", device_name)
        
        command = f"input tap {self.config.CLICK_X} {self.config.CLICK_Y}"
        success, output = self.cloud_api.shell_command(machine_name, device_name, command)
        
        if success:
            Logger.info("✅ 弹窗点击成功", device_name)
            Logger.info(f"⏱️ 等待弹窗完全消失 {self.config.CLICK_DELAY}秒", device_name)
            time.sleep(self.config.CLICK_DELAY)
            return True
        else:
            Logger.error(f"弹窗点击失败: {output}", device_name)
            return False
    
    def execute_deeplink(self, machine_name: str, device_name: str, deeplink: str) -> bool:
        """执行deeplink"""
        # 标准化链接
        normalized_link = self._normalize_deeplink(deeplink)
        
        command = f"am start -a android.intent.action.VIEW -d '{normalized_link}'"
        
        try:
            Logger.info(f"🔗 访问: {normalized_link[:50]}...", device_name)
            success, output = self.cloud_api.shell_command(machine_name, device_name, command)
            
            if success and "Error" not in output:
                Logger.info("✅ 链接访问成功", device_name)
                return True
            else:
                Logger.error(f"链接访问失败: {output[:100]}", device_name)
                return False
        except Exception as e:
            Logger.error(f"链接访问异常: {e}", device_name)
            return False
    
    def take_screenshot(self, machine_name: str, device_name: str, 
                       batch_num: int, link_num: int) -> Optional[str]:
        """截图"""
        try:
            Logger.info("📸 执行截图", device_name)
            
            timestamp = datetime.datetime.now().strftime("%m%d_%H%M%S")
            remote_path = f"/data/screenshot_{device_name}_{timestamp}.png"
            command = f"screencap -p {remote_path}"
            
            success, output = self.cloud_api.shell_command(machine_name, device_name, command)
            
            if success:
                Logger.info(f"✅ 截图已保存: {remote_path}", device_name)
                return remote_path
            else:
                Logger.error(f"截图失败: {output}", device_name)
                return None
        except Exception as e:
            Logger.error(f"截图异常: {e}", device_name)
            return None
    
    def _normalize_deeplink(self, deeplink: str) -> str:
        """标准化deeplink"""
        if deeplink.startswith('/'):
            return f"https://shopee.tw{deeplink}"
        elif not deeplink.startswith(('http://', 'https://')):
            return f"https://shopee.tw/{deeplink.lstrip('/')}"
        return deeplink


# ==================== 工具函数模块 ====================

class Utils:
    """工具函数集合"""
    
    @staticmethod
    def load_deeplinks(filepath: str) -> List[str]:
        """加载deeplinks"""
        try:
            with open(filepath, encoding='utf-8') as f:
                content = f.read().strip()
                links = []
                
                # 尝试纯文本格式
                for line in content.split('\n'):
                    line = line.strip()
                    if line and line.startswith('http'):
                        links.append(line)
                
                # 如果没有找到，尝试CSV格式
                if not links:
                    f.seek(0)
                    try:
                        reader = csv.DictReader(f)
                        for row in reader:
                            url = row.get('url') or row.get('deeplink') or row.get('link')
                            if url and url.strip():
                                links.append(url.strip())
                    except:
                        pass
                
                Logger.info(f"✅ 加载{len(links)}条链接")
                return links if links else []
                
        except Exception as e:
            Logger.error(f"加载链接失败: {e}")
            return []
    
    @staticmethod
    def save_progress(device_name: str, stats: Dict):
        """保存进度"""
        try:
            progress_data = {
                'timestamp': time.time(),
                'device': device_name,
                'stats': stats
            }
            progress_file = f"progress_{device_name}.json"
            with open(progress_file, 'w', encoding='utf-8') as f:
                json.dump(progress_data, f, ensure_ascii=False, indent=2)
        except Exception as e:
            Logger.warning(f"保存进度失败: {e}", device_name)


# ==================== 设备状态管理 ====================

@dataclass
class DeviceStats:
    """设备统计信息"""
    total_cycles: int = 0
    total_tested: int = 0
    total_success: int = 0
    start_time: float = 0
    
    def get_success_rate(self) -> float:
        """获取成功率"""
        if self.total_tested == 0:
            return 0.0
        return (self.total_success / self.total_tested) * 100
    
    def get_elapsed_hours(self) -> float:
        """获取运行时间（小时）"""
        return (time.time() - self.start_time) / 3600


# ==================== 设备工作流程模块 ====================

class DeviceWorker:
    """设备工作流程管理"""
    
    def __init__(self, config: Config):
        self.config = config
        self.cloud_api = CloudAPI(config)
        self.device_manager = DeviceInfoManager(config, self.cloud_api)
        self.adb_controller = ADBController(config, self.cloud_api)
    
    def run(self, device_info: Dict, all_links: List[str], stop_event: threading.Event):
        """运行设备工作流程"""
        device_name = device_info["name"]
        machine_id = device_info["id"]
        machine_name = device_info["name"]
        
        stats = DeviceStats(start_time=time.time())
        
        Logger.info(f"🚀 设备工作线程启动", device_name)
        Logger.info(f"📱 设备信息: ID={machine_id}, Name={device_name}", device_name)
        
        link_index = 0
        first_run = True
        
        try:
            while not stop_event.is_set() and link_index < len(all_links):
                stats.total_cycles += 1
                
                self._log_cycle_start(stats.total_cycles, device_name)
                
                # 执行测试循环
                if first_run:
                    if not self._first_run_setup(machine_id, machine_name, device_name):
                        continue
                    first_run = False
                else:
                    if not self._cycle_setup(machine_name, device_name):
                        continue
                
                # 启动APP
                if not self.cloud_api.run_apk(machine_name, device_name):
                    Logger.error("APP启动失败，跳过本轮", device_name)
                    continue
                
                # 处理弹窗
                self.adb_controller.click_popup(machine_name, device_name)
                
                # 执行deeplink测试
                link_index = self._execute_deeplink_batch(
                    machine_name, device_name, all_links, 
                    link_index, stats, stop_event
                )
                
                # 保存进度
                Utils.save_progress(device_name, stats.__dict__)
                
                # 显示统计
                self._log_cycle_stats(stats, device_name)
        
        except Exception as e:
            Logger.error(f"设备线程异常: {e}", device_name)
            import traceback
            Logger.error(f"异常详情: {traceback.format_exc()}", device_name)
        
        # 最终统计
        self._log_final_stats(stats, device_name)
    
    def _first_run_setup(self, machine_id: str, machine_name: str, device_name: str) -> bool:
        """首次运行设置"""
        Logger.info("🔧 初次运行，进行初始化设置", device_name)
        
        # 检查容器状态
        status, _ = self.cloud_api.get_device_status(machine_id)
        if status != 'running':
            Logger.info("1️⃣ 启动Android容器", device_name)
            if not self.cloud_api.run_android_container(machine_name, device_name):
                Logger.error("Android容器启动失败", device_name)
                return False
        
        # 检查Android启动状态
        Logger.info("2️⃣ 检查Android启动状态", device_name)
        if not self.cloud_api.check_android_boot_status(machine_name, device_name):
            Logger.error("Android系统未完全启动", device_name)
            return False
        
        # 安装APK
        Logger.info("3️⃣ 初次安装APK", device_name)
        if not self._install_apk_with_retry(machine_name, device_name):
            Logger.error("APK安装失败", device_name)
            return False
        
        return True
    
    def _cycle_setup(self, machine_name: str, device_name: str) -> bool:
        """循环设置"""
        # 卸载APP
        Logger.info("1️⃣ 卸载Shopee APP", device_name)
        self.cloud_api.uninstall_apk(machine_name, device_name)
        time.sleep(self.config.UNINSTALL_WAIT)
        
        # 更换设备信息
        Logger.info("2️⃣ 更换设备信息", device_name)
        if not self.device_manager.change_device_info(machine_name, device_name):
            Logger.warning("设备信息更换失败，使用当前信息继续", device_name)
        
        # 重新安装APP
        Logger.info("3️⃣ 重新安装APP", device_name)
        if not self._install_apk_with_retry(machine_name, device_name):
            Logger.error("APP重新安装失败", device_name)
            return False
        
        return True
    
    def _install_apk_with_retry(self, machine_name: str, device_name: str) -> bool:
        """带重试的APK安装"""
        for attempt in range(self.config.MAX_INSTALL_RETRY):
            if self.cloud_api.install_apk(machine_name, device_name):
                time.sleep(self.config.INSTALL_WAIT)
                return True
            Logger.warning(f"安装失败，重试 {attempt + 1}/{self.config.MAX_INSTALL_RETRY}", device_name)
            time.sleep(5)
        return False
    
    def _execute_deeplink_batch(self, machine_name: str, device_name: str, 
                               all_links: List[str], start_index: int, 
                               stats: DeviceStats, stop_event: threading.Event) -> int:
        """执行一批deeplink测试"""
        Logger.info("🎯 开始deeplink测试", device_name)
        
        batch_tested = 0
        batch_success = 0
        current_index = start_index
        
        while (batch_tested < self.config.BATCH_SIZE and 
               current_index < len(all_links) and 
               not stop_event.is_set()):
            
            link = all_links[current_index]
            current_index += 1
            batch_tested += 1
            stats.total_tested += 1
            
            Logger.info(f"📍 第{batch_tested}/{self.config.BATCH_SIZE}条 "
                       f"(总第{stats.total_tested}条)", device_name)
            
            # 执行deeplink
            if self.adb_controller.execute_deeplink(machine_name, device_name, link):
                batch_success += 1
                stats.total_success += 1
            
            # 第3条时截图
            if batch_tested == 3:
                Logger.info("📸 第三条完成，截图", device_name)
                self.adb_controller.take_screenshot(
                    machine_name, device_name, 
                    stats.total_cycles, batch_tested
                )
            
            # 间隔等待
            if batch_tested < self.config.BATCH_SIZE and current_index < len(all_links):
                Logger.info(f"⏱️ 等待{self.config.DEEPLINK_INTERVAL}秒", device_name)
                time.sleep(self.config.DEEPLINK_INTERVAL)
        
        # 批次统计
        if batch_tested > 0:
            batch_rate = (batch_success / batch_tested) * 100
            Logger.info(f"📊 本批次: {batch_tested}条, 成功{batch_success}条"
                       f"({batch_rate:.1f}%)", device_name)
        
        return current_index
    
    def _log_cycle_start(self, cycle_num: int, device_name: str):
        """记录循环开始"""
        Logger.info(f"\n{'='*50}", device_name)
        Logger.info(f"🔄 第{cycle_num}轮测试开始", device_name)
        Logger.info(f"{'='*50}", device_name)
    
    def _log_cycle_stats(self, stats: DeviceStats, device_name: str):
        """记录循环统计"""
        Logger.info(f"📊 累计测试: {stats.total_tested}条, "
                   f"成功: {stats.total_success}条 "
                   f"({stats.get_success_rate():.1f}%)", device_name)
    
    def _log_final_stats(self, stats: DeviceStats, device_name: str):
        """记录最终统计"""
        Logger.info(f"\n{'='*50}", device_name)
        Logger.info(f"🏁 设备{device_name}测试结束", device_name)
        Logger.info(f"📊 总轮次: {stats.total_cycles}", device_name)
        Logger.info(f"📊 总测试: {stats.total_tested}条", device_name)
        Logger.info(f"📊 总成功: {stats.total_success}条", device_name)
        Logger.info(f"📊 成功率: {stats.get_success_rate():.1f}%", device_name)
        Logger.info(f"⏱️ 运行时间: {stats.get_elapsed_hours():.1f}小时", device_name)
        Logger.info(f"{'='*50}", device_name)


# ==================== 主程序模块 ====================

class CloudControlMain:
    """主程序控制器"""
    
    def __init__(self):
        self.config = Config()
        self.cloud_api = CloudAPI(self.config)
        self.stop_event = threading.Event()
        
        # 设置信号处理
        signal.signal(signal.SIGINT, self._signal_handler)
    
    def _signal_handler(self, signum, frame):
        """信号处理器"""
        Logger.info("🛑 收到中断信号，正在停止...")
        self.stop_event.set()
    
    def run(self):
        """运行主程序"""
        self._print_banner()
        
        # 获取设备列表
        devices = self._get_running_devices()
        if not devices:
            Logger.error("没有可用的运行中设备")
            return
        
        # 加载deeplinks
        all_links = Utils.load_deeplinks(self.config.DEEPLINK_FILE)
        if not all_links:
            Logger.error("未找到有效的deeplink")
            return
        
        # 显示任务信息
        self._print_task_info(devices, all_links)
        
        # 执行测试
        self._execute_tests(devices, all_links)
    
    def _print_banner(self):
        """打印启动横幅"""
        Logger.info("=" * 70)
        Logger.info("🚀 云机群控脚本 - 模块化重构版")
        Logger.info("=" * 70)
        Logger.info(f"📡 云服务地址: {self.config.CLOUD_BASE_URL}")
        Logger.info(f"🖥️ 主机IP: {self.config.CLOUD_HOST_IP}")
        Logger.info(f"📦 APK路径: {self.config.APK_PATH}")
        Logger.info(f"⚙️ 批次大小: {self.config.BATCH_SIZE}条/轮")
        Logger.info(f"⏱️ 时序配置:")
        Logger.info(f"   - APP启动等待: {self.config.APP_STARTUP_WAIT}秒")
        Logger.info(f"   - 弹窗处理等待: {self.config.CLICK_DELAY}秒")
        Logger.info(f"   - Deeplink间隔: {self.config.DEEPLINK_INTERVAL}秒")
        Logger.info(f"   - 设备信息更换等待: {self.config.NETWORK_RECOVERY_WAIT}秒")
        Logger.info(f"   - API超时时间: {self.config.API_TIMEOUT}秒")
        Logger.info("🔄 工作流程: 安装 → 测试 → 卸载 → 更换设备信息 → 循环")
        Logger.info("=" * 70)
    
    def _get_running_devices(self) -> List[Dict]:
        """获取运行中的设备"""
        Logger.info("🔍 获取设备列表...")
        devices = self.cloud_api.get_device_list()
        
        if not devices:
            return []
        
        # 筛选运行中的设备
        running_devices = [d for d in devices if d.get('state') == 'running']
        
        Logger.info(f"✅ 发现{len(running_devices)}个运行中的设备")
        for device in running_devices:
            Logger.info(f"📱 {device.get('name', 'Unknown')} - "
                       f"IP: {device.get('ip', 'Unknown')}")
        
        return running_devices
    
    def _print_task_info(self, devices: List[Dict], links: List[str]):
        """打印任务信息"""
        Logger.info(f"\n📋 任务信息:")
        Logger.info(f"   - 设备数量: {len(devices)}")
        Logger.info(f"   - 链接总数: {len(links)}")
        Logger.info(f"   - 每设备链接数: ~{len(links) // len(devices)}")
        Logger.info("")
    
    def _execute_tests(self, devices: List[Dict], all_links: List[str]):
        """执行测试"""
        try:
            with ThreadPoolExecutor(max_workers=len(devices)) as executor:
                futures = []
                
                for i, device in enumerate(devices):
                    worker = DeviceWorker(self.config)
                    future = executor.submit(
                        worker.run, 
                        device, 
                        all_links, 
                        self.stop_event
                    )
                    futures.append(future)
                    Logger.info(f"✅ 启动设备: {device.get('name', 'Unknown')}")
                    
                    # 错开启动时间
                    if i < len(devices) - 1:
                        time.sleep(10)
                
                # 等待所有任务完成
                for future in futures:
                    try:
                        future.result()
                    except Exception as e:
                        Logger.error(f"线程异常: {e}")
            
            Logger.info("\n🏁 所有测试完成")
            
        except KeyboardInterrupt:
            Logger.info("⏹️ 用户中断")
            self.stop_event.set()
        except Exception as e:
            Logger.error(f"程序异常: {e}")


# ==================== 程序入口 ====================

def main():
    """程序入口"""
    app = CloudControlMain()
    app.run()


if __name__ == "__main__":
    main()