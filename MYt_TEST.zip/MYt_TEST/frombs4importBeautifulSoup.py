#!/usr/bin/env python3
"""
多设备云机deeplink测试器 - 智能监控集成版

核心优化：
1. 智能云机状态检测，替代固定140秒等待
2. 多层级状态检查：云机状态→网络→Android→ADB→服务
3. 动态等待时间，通常30-90秒即可完成
4. 保留offline问题修复和稳定启动机制
"""

import subprocess
import time
import csv
import json
import requests
import urllib.parse
import datetime
import os
import threading
from concurrent.futures import ThreadPoolExecutor
import signal
import sys
from enum import Enum
from typing import Tuple, Dict, Optional

# 云服务配置
CLOUD_BASE_URL = "http://127.0.0.1:9000"
CLOUD_HOST_IP = "172.16.253.246"
APK_PATH = "C:\\Program Files (x86)\\WuhanMoyuntengNetWork\\MYT_Zeus\\Shared\\shopee-tw-3-28-34.apk"

# 测试配置
DEEPLINK_FILE = "data1.csv"
SHOPEE_PACKAGE = "com.shopee.tw"
BATCH_SIZE = 7

# 时序配置
APK_INSTALL_WAIT = 20
APP_STARTUP_WAIT = 8
CLICK_DELAY = 9
DEEPLINK_INTERVAL = 5

# 智能等待配置
MAX_SMART_WAIT_TIME = 300  # 最大智能等待时间5分钟
MIN_SAFE_WAIT_TIME = 30    # 最小安全等待时间30秒
STATUS_CHECK_INTERVAL = 5   # 状态检查间隔5秒

# 启动状态检查配置
MAX_BOOT_CHECK_TIME = 180
BOOT_CHECK_INTERVAL = 5

# 点击配置
CLICK_X = 340
CLICK_Y = 1160

# 截图配置
SCREENSHOT_DIR = r"D:\screenshots_618"
LOG_FILE = "multi_device_deeplink_test.log"

# ADB管理全局变量
_adb_lock = threading.Lock()
_last_server_restart = 0

# ========== 智能云机状态监控 ==========

class CloudMachineState(Enum):
    """云机状态枚举"""
    UNKNOWN = "unknown"
    RESETTING = "resetting"
    BOOTING = "booting"
    ANDROID_STARTING = "android_starting"
    ADB_CONNECTING = "adb_connecting"
    READY = "ready"
    ERROR = "error"

class Logger:
    _lock = threading.Lock()
    
    @staticmethod
    def log(message, device="MAIN"):
        timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        log_entry = f"[{timestamp}][{device}] {message}"
        
        with Logger._lock:
            try:
                with open(LOG_FILE, "a", encoding="utf-8") as f:
                    f.write(log_entry + "\n")
            except:
                pass
            print(log_entry)

class SmartCloudMonitor:
    """智能云机监控器"""
    
    def __init__(self):
        self.max_total_wait = MAX_SMART_WAIT_TIME
        self.check_interval = STATUS_CHECK_INTERVAL
        
    def check_cloud_machine_basic_status(self, machine_id: str) -> Optional[Dict]:
        """检查云机基础状态"""
        url = f"{CLOUD_BASE_URL}/dc_api/v1/list/{CLOUD_HOST_IP}"
        try:
            response = requests.get(url, timeout=10)
            if response.status_code == 200:
                data = response.json()
                if data.get('code') == 200 and 'data' in data:
                    for device in data['data']:
                        if device.get('id') == machine_id:
                            return device
            return None
        except Exception:
            return None
    
    def check_android_boot_status(self, machine_name: str) -> Tuple[bool, str]:
        """检查Android启动状态"""
        url = f"{CLOUD_BASE_URL}/get_android_boot_status/{CLOUD_HOST_IP}/{machine_name}"
        params = {"isblock": 0, "timeout": 10}
        
        try:
            response = requests.get(url, params=params, timeout=15)
            if response.status_code == 200:
                data = response.json()
                code = data.get('code')
                
                if code == 200:
                    return True, "Android系统启动完成"
                elif code == 201:
                    return False, "Android系统启动中"
                else:
                    return False, f"Android状态未知: code={code}"
            return False, "无法获取Android状态"
        except Exception as e:
            return False, f"Android状态检查异常: {e}"
    
    def check_network_connectivity(self, device_ip: str) -> bool:
        """检查网络连通性"""
        try:
            if os.name == 'nt':
                cmd = f"ping -n 1 -w 2000 {device_ip}"
            else:
                cmd = f"ping -c 1 -W 2 {device_ip}"
            
            result = subprocess.run(cmd, shell=True, capture_output=True, timeout=5)
            return result.returncode == 0
        except:
            return False
    
    def check_adb_connectivity(self, device_ip: str) -> Tuple[bool, str]:
        """检查ADB连接状态"""
        try:
            device_address = f"{device_ip}:5555"
            
            # 尝试连接ADB
            connect_cmd = f"adb connect {device_address}"
            result = subprocess.run(connect_cmd, shell=True, capture_output=True, text=True, timeout=10)
            
            if result.returncode == 0:
                time.sleep(2)
                
                # 检查设备状态
                devices_cmd = "adb devices"
                devices_result = subprocess.run(devices_cmd, shell=True, capture_output=True, text=True, timeout=5)
                
                if devices_result.returncode == 0 and device_address in devices_result.stdout:
                    if "device" in devices_result.stdout:
                        # 测试简单命令
                        test_cmd = f"adb -s {device_address} shell echo 'test'"
                        test_result = subprocess.run(test_cmd, shell=True, capture_output=True, text=True, timeout=10)
                        
                        if test_result.returncode == 0 and "test" in test_result.stdout:
                            return True, "ADB连接正常且可通信"
                        else:
                            return False, "ADB连接成功但无法通信"
                    elif "offline" in devices_result.stdout:
                        return False, "ADB设备offline"
                    else:
                        return False, "ADB设备状态异常"
                else:
                    return False, "ADB设备未在列表中"
            
            return False, f"ADB连接失败"
        except Exception as e:
            return False, f"ADB连接检查异常: {e}"
    
    def check_android_services_ready(self, device_ip: str) -> Tuple[bool, str]:
        """检查Android关键服务是否就绪"""
        device_address = f"{device_ip}:5555"
        
        try:
            # 检查包管理器服务
            pm_cmd = f"adb -s {device_address} shell pm list packages -f | head -1"
            pm_result = subprocess.run(pm_cmd, shell=True, capture_output=True, text=True, timeout=15)
            
            if pm_result.returncode != 0:
                return False, "包管理器服务未就绪"
            
            # 检查Activity Manager服务
            am_cmd = f"adb -s {device_address} shell am get-config"
            am_result = subprocess.run(am_cmd, shell=True, capture_output=True, text=True, timeout=10)
            
            if am_result.returncode != 0:
                return False, "Activity Manager服务未就绪"
            
            return True, "Android关键服务已就绪"
            
        except Exception as e:
            return False, f"Android服务检查异常: {e}"
    
    def get_comprehensive_status(self, machine_id: str, machine_name: str, device_ip: str) -> Tuple[CloudMachineState, str, Dict]:
        """获取云机综合状态"""
        status_details = {}
        
        # 1. 检查云机基础状态
        basic_status = self.check_cloud_machine_basic_status(machine_id)
        if basic_status is None:
            return CloudMachineState.ERROR, "无法获取云机基础状态", status_details
        
        machine_state = basic_status.get('state', 'unknown')
        status_details['machine_state'] = machine_state
        
        if machine_state not in ['running', 'started']:
            return CloudMachineState.BOOTING, f"云机状态: {machine_state}", status_details
        
        # 2. 检查网络连通性
        network_ok = self.check_network_connectivity(device_ip)
        status_details['network'] = network_ok
        
        if not network_ok:
            return CloudMachineState.BOOTING, "网络连接不可达", status_details
        
        # 3. 检查Android启动状态
        android_ready, android_msg = self.check_android_boot_status(machine_name)
        status_details['android_ready'] = android_ready
        status_details['android_msg'] = android_msg
        
        if not android_ready:
            return CloudMachineState.ANDROID_STARTING, android_msg, status_details
        
        # 4. 检查ADB连接
        adb_ok, adb_msg = self.check_adb_connectivity(device_ip)
        status_details['adb_ready'] = adb_ok
        status_details['adb_msg'] = adb_msg
        
        if not adb_ok:
            return CloudMachineState.ADB_CONNECTING, adb_msg, status_details
        
        # 5. 检查Android服务
        services_ok, services_msg = self.check_android_services_ready(device_ip)
        status_details['services_ready'] = services_ok
        status_details['services_msg'] = services_msg
        
        if not services_ok:
            return CloudMachineState.ADB_CONNECTING, services_msg, status_details
        
        return CloudMachineState.READY, "云机完全就绪", status_details
    
    def smart_wait_for_ready(self, machine_id: str, machine_name: str, device_ip: str, device_name: str) -> bool:
        """智能等待云机就绪"""
        Logger.log("🧠 开始智能等待云机就绪", device_name)
        
        start_time = time.time()
        last_state = None
        consecutive_ready_count = 0
        
        while time.time() - start_time < self.max_total_wait:
            current_state, message, details = self.get_comprehensive_status(machine_id, machine_name, device_ip)
            
            elapsed = int(time.time() - start_time)
            
            # 状态变化时记录
            if current_state != last_state:
                Logger.log(f"📊 状态: {current_state.value} - {message} (已等待{elapsed}秒)", device_name)
                last_state = current_state
                consecutive_ready_count = 0
            
            # 如果完全就绪
            if current_state == CloudMachineState.READY:
                consecutive_ready_count += 1
                Logger.log(f"✅ 就绪确认 {consecutive_ready_count}/3 (已等待{elapsed}秒)", device_name)
                
                # 连续3次检查都就绪才确认
                if consecutive_ready_count >= 3:
                    total_time = time.time() - start_time
                    saved_time = 140 - total_time
                    Logger.log(f"🎉 云机完全就绪! 耗时: {total_time:.1f}秒 (节省: {saved_time:.1f}秒)", device_name)
                    return True
            else:
                consecutive_ready_count = 0
                
                # 错误状态特殊处理
                if current_state == CloudMachineState.ERROR:
                    Logger.log(f"❌ {message}", device_name)
                    time.sleep(10)  # 错误状态等待更长时间
                    continue
            
            time.sleep(self.check_interval)
        
        # 超时处理
        total_time = time.time() - start_time
        Logger.log(f"⏱️ 智能等待超时({total_time:.1f}秒)，使用最小安全等待", device_name)
        return False

# 创建全局监控器实例
_cloud_monitor = SmartCloudMonitor()

# ========== ADB管理功能 (保留原有的增强功能) ==========

def run_adb_safe(cmd, device_name, timeout=15, silent=False):
    """安全的ADB命令执行"""
    try:
        if not silent:
            Logger.log(f"🔧 执行: {cmd}", device_name)
        
        result = subprocess.run(
            cmd, 
            shell=True, 
            capture_output=True, 
            text=True, 
            timeout=timeout,
            encoding='utf-8',
            errors='ignore'
        )
        
        success = result.returncode == 0
        stdout = result.stdout.strip()
        stderr = result.stderr.strip()
        
        return success, stdout, stderr
        
    except subprocess.TimeoutExpired:
        Logger.log(f"⏱️ 命令超时: {cmd}", device_name)
        return False, "", f"超时({timeout}秒)"
    except Exception as e:
        Logger.log(f"❌ 命令异常: {e}", device_name)
        return False, "", str(e)

def restart_adb_server_smart():
    """智能重启ADB服务器"""
    global _last_server_restart
    
    with _adb_lock:
        current_time = time.time()
        
        if current_time - _last_server_restart < 30:
            Logger.log("🔄 ADB服务器最近已重启，跳过")
            return True
        
        Logger.log("🔄 重启ADB服务器")
        
        subprocess.run("adb kill-server", shell=True, capture_output=True, timeout=10)
        time.sleep(2)
        
        result = subprocess.run("adb start-server", shell=True, capture_output=True, timeout=15)
        
        if result.returncode == 0:
            _last_server_restart = current_time
            Logger.log("✅ ADB服务器重启成功")
            time.sleep(3)
            return True
        else:
            Logger.log("❌ ADB服务器重启失败")
            return False

def check_device_status(device_ip, device_name):
    """检查设备状态"""
    success, stdout, _ = run_adb_safe("adb devices", device_name, timeout=10, silent=True)
    
    if not success:
        return "unknown"
    
    for line in stdout.split('\n'):
        if device_ip in line:
            parts = line.split()
            if len(parts) >= 2:
                return parts[1]
    
    return "not_found"

def recover_offline_device(device_ip, device_name):
    """恢复offline设备"""
    Logger.log("🔧 尝试恢复offline设备", device_name)
    
    # 方法1: 断开重连
    run_adb_safe(f"adb disconnect {device_ip}", device_name, timeout=10, silent=True)
    time.sleep(3)
    
    success, stdout, _ = run_adb_safe(f"adb connect {device_ip}", device_name, timeout=15, silent=True)
    if success and "connected" in stdout.lower():
        time.sleep(2)
        if check_device_status(device_ip, device_name) == "device":
            Logger.log("✅ 断开重连成功恢复", device_name)
            return True
    
    # 方法2: 重启ADB服务器后重连
    if restart_adb_server_smart():
        time.sleep(5)
        
        success, stdout, _ = run_adb_safe(f"adb connect {device_ip}", device_name, timeout=15, silent=True)
        if success and "connected" in stdout.lower():
            time.sleep(2)
            if check_device_status(device_ip, device_name) == "device":
                Logger.log("✅ 重启ADB后恢复成功", device_name)
                return True
    
    Logger.log("❌ offline设备恢复失败", device_name)
    return False

def ensure_connection(device_ip, device_name):
    """确保设备连接"""
    Logger.log(f"🔧 建立稳定连接", device_name)
    
    max_attempts = 5
    
    for attempt in range(max_attempts):
        Logger.log(f"🔗 连接尝试 {attempt + 1}/{max_attempts}", device_name)
        
        current_status = check_device_status(device_ip, device_name)
        Logger.log(f"📊 设备状态: {current_status}", device_name)
        
        if current_status == "device":
            success, stdout, _ = run_adb_safe(f"adb -s {device_ip} shell echo 'test'", device_name, timeout=10, silent=True)
            if success and "test" in stdout:
                Logger.log("✅ 连接正常", device_name)
                return True
            else:
                Logger.log("⚠️ 状态正常但通信失败", device_name)
        
        if current_status == "offline":
            Logger.log("⚠️ 设备offline，尝试恢复", device_name)
            if recover_offline_device(device_ip, device_name):
                continue
        
        # 强制断开重连
        run_adb_safe(f"adb disconnect {device_ip}", device_name, timeout=10, silent=True)
        time.sleep(2)
        
        success, stdout, stderr = run_adb_safe(f"adb connect {device_ip}", device_name, timeout=15, silent=True)
        
        if success and any(keyword in stdout.lower() for keyword in ['connected', 'already connected']):
            Logger.log(f"✅ 连接成功: {stdout}", device_name)
            time.sleep(2)
            
            if check_device_status(device_ip, device_name) == "device":
                success, test_stdout, _ = run_adb_safe(f"adb -s {device_ip} shell echo 'test'", device_name, timeout=10, silent=True)
                if success and "test" in test_stdout:
                    Logger.log("✅ 连接验证成功", device_name)
                    return True
        else:
            Logger.log(f"❌ 连接失败: {stderr}", device_name)
        
        if attempt == 2:
            restart_adb_server_smart()
            time.sleep(5)
        
        if attempt < max_attempts - 1:
            wait_time = 3 + attempt
            Logger.log(f"⏱️ 等待{wait_time}秒后重试", device_name)
            time.sleep(wait_time)
    
    Logger.log("❌ 所有连接尝试都失败", device_name)
    return False

# ========== 云机API控制 ==========

class CloudAPI:
    @staticmethod
    def get_device_list():
        """获取设备列表"""
        url = f"{CLOUD_BASE_URL}/dc_api/v1/list/{CLOUD_HOST_IP}"
        try:
            response = requests.get(url, timeout=30)
            if response.status_code == 200:
                data = response.json()
                if data.get('code') == 200 and 'data' in data:
                    return data['data']
            return []
        except Exception as e:
            Logger.log(f"❌ 获取设备列表失败: {e}")
            return []
    
    @staticmethod
    def check_android_boot_status(machine_name, device_name):
        """检查Android启动状态"""
        url = f"{CLOUD_BASE_URL}/get_android_boot_status/{CLOUD_HOST_IP}/{machine_name}"
        params = {"isblock": 0, "timeout": 10}
        
        Logger.log("🔍 检查Android启动状态", device_name)
        start_time = time.time()
        
        while time.time() - start_time < MAX_BOOT_CHECK_TIME:
            try:
                response = requests.get(url, params=params, timeout=15)
                if response.status_code == 200:
                    data = response.json()
                    code = data.get('code')
                    
                    if code == 200:
                        Logger.log("✅ Android系统启动完成！", device_name)
                        return True
                    elif code == 201:
                        elapsed = int(time.time() - start_time)
                        Logger.log(f"📱 系统启动中... (已等待{elapsed}秒)", device_name)
                    else:
                        Logger.log(f"启动检查返回: code={code}", device_name)
            except Exception as e:
                Logger.log(f"启动检查请求异常: {e}", device_name)
            
            time.sleep(BOOT_CHECK_INTERVAL)
        
        Logger.log("⚠️ Android启动检查超时", device_name)
        return False

def ensure_android_running(machine_name, device_name):
    """确保Android系统运行"""
    Logger.log("🔧 检查并确保Android系统运行", device_name)
    
    if CloudAPI.check_android_boot_status(machine_name, device_name):
        Logger.log("✅ Android系统已经运行", device_name)
        return True
    
    Logger.log("❌ Android系统未就绪", device_name)
    return False

def reset_cloud_machine(machine_id, device_name, device_ip=None):
    """智能重置云机 - 替换原来的固定140秒等待"""
    # 发送重置请求
    url = f"{CLOUD_BASE_URL}/reset/{CLOUD_HOST_IP}/{machine_id}"
    Logger.log(f"🔄 开始重置云机", device_name)
    
    try:
        response = requests.get(url, timeout=30)
        Logger.log(f"✅ 重置请求已发送", device_name)
    except Exception as e:
        Logger.log(f"⚠️ 重置请求失败: {e}", device_name)
    
    # 等待10秒让重置开始
    Logger.log(f"⏱️ 等待10秒让重置开始", device_name)
    time.sleep(10)
    
    # 智能等待云机就绪
    if device_ip:
        # 提取IP地址（去掉端口）
        clean_ip = device_ip.split(':')[0] if ':' in device_ip else device_ip
        machine_name = device_name  # 使用device_name作为machine_name
        
        Logger.log(f"🧠 使用智能监控等待云机就绪", device_name)
        success = _cloud_monitor.smart_wait_for_ready(machine_id, machine_name, clean_ip, device_name)
        
        if not success:
            # 智能等待失败，使用最小安全等待时间
            Logger.log(f"⚠️ 智能等待未完全确认，使用最小安全等待{MIN_SAFE_WAIT_TIME}秒", device_name)
            time.sleep(MIN_SAFE_WAIT_TIME)
    else:
        # 没有IP信息，使用最小安全等待
        Logger.log(f"⚠️ 无IP信息，使用最小安全等待{MIN_SAFE_WAIT_TIME}秒", device_name)
        time.sleep(MIN_SAFE_WAIT_TIME)
    
    Logger.log(f"✅ 云机重置等待完成", device_name)

# ========== 应用功能 ==========

def install_apk(machine_id, device_name):
    """安装APK"""
    encoded_path = urllib.parse.quote(APK_PATH)
    url = f"{CLOUD_BASE_URL}/install_apk/{CLOUD_HOST_IP}/{machine_id}?local={encoded_path}"
    Logger.log(f"📦 开始安装APK", device_name)
    
    try:
        response = requests.get(url, timeout=120)
        Logger.log(f"📦 APK安装请求已发送", device_name)
    except Exception as e:
        Logger.log(f"📦 APK安装请求异常: {str(e)}", device_name)

def normalize_shopee_link(link):
    """标准化Shopee链接格式"""
    if link.startswith('/'):
        link = f"https://shopee.tw{link}"
    elif not link.startswith(('http://', 'https://')):
        link = f"https://shopee.tw/{link.lstrip('/')}"
    return link

def open_shopee(device_ip, device_name):
    """启动Shopee - 使用最稳定的固定种子monkey"""
    Logger.log(f"🚀 启动Shopee (智能增强版)", device_name)
    
    if not ensure_connection(device_ip, device_name):
        Logger.log("❌ 无法建立稳定连接", device_name)
        return False
    
    Logger.log("🛑 停止现有Shopee", device_name)
    run_adb_safe(f"adb -s {device_ip} shell am force-stop {SHOPEE_PACKAGE}", device_name, timeout=10, silent=True)
    time.sleep(2)
    
    Logger.log("🐒 使用固定种子monkey启动(最稳定方式)", device_name)
    success, stdout, stderr = run_adb_safe(
        f"adb -s {device_ip} shell monkey -p {SHOPEE_PACKAGE} -c android.intent.category.LAUNCHER -s 1000 1",
        device_name, 
        timeout=15
    )
    
    if success and ("Events injected:" in stdout or "Monkey finished" in stdout):
        Logger.log("✅ monkey启动命令成功", device_name)
        
        time.sleep(3)
        verify_success, verify_output, _ = run_adb_safe(
            f"adb -s {device_ip} shell pidof {SHOPEE_PACKAGE}",
            device_name,
            timeout=10,
            silent=True
        )
        
        if verify_success and verify_output.strip():
            Logger.log(f"✅ Shopee启动成功，PID: {verify_output.strip()}", device_name)
            return True
        else:
            Logger.log("❌ monkey成功但应用未运行", device_name)
    else:
        Logger.log(f"❌ monkey启动失败: {stderr}", device_name)
        
        if "device offline" in stderr or "device not found" in stderr:
            Logger.log("🔄 检测到连接问题，重连后重试", device_name)
            if ensure_connection(device_ip, device_name):
                success2, stdout2, stderr2 = run_adb_safe(
                    f"adb -s {device_ip} shell monkey -p {SHOPEE_PACKAGE} -c android.intent.category.LAUNCHER -s 1000 1",
                    device_name,
                    timeout=15
                )
                
                if success2 and ("Events injected:" in stdout2 or "Monkey finished" in stdout2):
                    Logger.log("✅ 重连后启动成功", device_name)
                    return True
    
    return False

def click_popup(device_ip, device_name):
    """点击弹窗"""
    Logger.log(f"🎯 点击弹窗 ({CLICK_X}, {CLICK_Y})", device_name)
    
    success, _, _ = run_adb_safe(f"adb -s {device_ip} shell input tap {CLICK_X} {CLICK_Y}", device_name, timeout=10, silent=True)
    
    if success:
        Logger.log(f"✅ 弹窗点击成功", device_name)
    else:
        Logger.log(f"❌ 弹窗点击失败", device_name)
    
    Logger.log(f"⏱️ 等待{CLICK_DELAY}秒确保弹窗完全过掉...", device_name)
    time.sleep(CLICK_DELAY)

def execute_deeplink_test(device_ip, device_name, deeplink):
    """执行deeplink测试"""
    if check_device_status(device_ip, device_name) != "device":
        Logger.log("⚠️ deeplink前检测到连接异常，尝试恢复", device_name)
        if not ensure_connection(device_ip, device_name):
            Logger.log("❌ deeplink前连接恢复失败", device_name)
            return False
    
    normalized_link = normalize_shopee_link(deeplink)
    
    try:
        Logger.log(f"🔗 访问链接: {normalized_link[:50]}...", device_name)
        
        run_adb_safe(f"adb -s {device_ip} shell monkey -p {SHOPEE_PACKAGE} 1", device_name, timeout=5, silent=True)
        time.sleep(1)
        
        cmd = f"adb -s {device_ip} shell am start -W -a android.intent.action.VIEW -d '{normalized_link}' {SHOPEE_PACKAGE}"
        success, stdout, stderr = run_adb_safe(cmd, device_name, timeout=10)
        
        if success and "Error" not in stderr:
            Logger.log(f"✅ 链接访问成功", device_name)
            return True
        else:
            if "device offline" in stderr or "device not found" in stderr:
                Logger.log("🔄 deeplink时连接异常，尝试恢复", device_name)
                if ensure_connection(device_ip, device_name):
                    success2, stdout2, stderr2 = run_adb_safe(cmd, device_name, timeout=10)
                    if success2 and "Error" not in stderr2:
                        Logger.log("✅ 重连后deeplink成功", device_name)
                        return True
            
            Logger.log(f"❌ 链接访问失败: {stderr}", device_name)
            return False
            
    except Exception as e:
        Logger.log(f"❌ deeplink异常: {e}", device_name)
        return False

def take_screenshot(device_ip, device_name, batch_num, cycle_num):
    """截图功能"""
    try:
        os.makedirs(SCREENSHOT_DIR, exist_ok=True)
        
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"{device_name}_{timestamp}.png"
        screenshot_path = os.path.join(SCREENSHOT_DIR, filename)
        
        Logger.log(f"📸 开始截图 - 设备:{device_name} 文件:{filename}", device_name)
        
        if os.name == 'nt':
            cmd = f'adb -s {device_ip} exec-out screencap -p > "{screenshot_path}"'
        else:
            cmd = f"adb -s {device_ip} exec-out screencap -p > '{screenshot_path}'"
            
        result = subprocess.run(cmd, shell=True, timeout=15)
        
        if result.returncode == 0 and os.path.exists(screenshot_path):
            file_size = os.path.getsize(screenshot_path)
            if file_size > 1000:
                Logger.log(f"✅ 截图成功 - 文件:{filename} 大小:{file_size}字节", device_name)
                return screenshot_path
            else:
                Logger.log(f"❌ 截图文件太小", device_name)
                try:
                    os.remove(screenshot_path)
                except:
                    pass
                return None
        else:
            Logger.log(f"❌ 截图命令失败", device_name)
            return None
    except Exception as e:
        Logger.log(f"❌ 截图异常: {e}", device_name)
        return None

def load_deeplinks():
    """加载deeplinks"""
    try:
        with open(DEEPLINK_FILE, encoding='utf-8') as f:
            content = f.read().strip()
            links = []
            
            for line in content.split('\n'):
                line = line.strip()
                if line and line.startswith('http'):
                    links.append(line)
            
            if not links:
                f.seek(0)
                try:
                    reader = csv.DictReader(f)
                    for row in reader:
                        url = row.get('url') or row.get('deeplink') or row.get('link')
                        if url and url.strip():
                            links.append(url.strip())
                except:
                    pass
            
            if links:
                Logger.log(f"✅ 加载{len(links)}条链接")
                return links
            else:
                Logger.log(f"❌ 文件中未找到有效链接")
                return ["https://shopee.tw/", "https://shopee.tw/search?keyword=test"]
            
    except Exception as e:
        Logger.log(f"❌ 无法加载文件: {DEEPLINK_FILE}, 错误: {e}")
        return ["https://shopee.tw/", "https://shopee.tw/search?keyword=test"]

def save_progress(device_name, stats):
    """保存进度"""
    try:
        progress_data = {
            'timestamp': time.time(),
            'device': device_name,
            'stats': stats
        }
        progress_file = f"progress_{device_name}.json"
        with open(progress_file, 'w', encoding='utf-8') as f:
            json.dump(progress_data, f, ensure_ascii=False, indent=2)
    except:
        pass

def device_worker(device_info, all_links, stop_event, device_index, total_devices):
    """设备工作线程 - 集成智能监控"""
    device_name = device_info["name"]
    device_ip = device_info["ip"]
    machine_id = device_info["machine_id"]
    machine_name = device_info["name"]
    
    stats = {
        'total_cycles': 0,
        'total_tested': 0,
        'total_success': 0,
        'start_time': time.time()
    }
    
    Logger.log(f"🚀 设备工作线程启动 - 设备索引:{device_index}/{total_devices}", device_name)
    
    # 错开启动时间
    startup_delay = 10 + device_index * 5
    Logger.log(f"⏱️ 错开启动，等待{startup_delay}秒", device_name)
    time.sleep(startup_delay)
    
    # 分配链接
    device_links = []
    for i in range(device_index, len(all_links), total_devices):
        device_links.append(all_links[i])
    
    Logger.log(f"📋 分配{len(device_links)}条链接给设备{device_name}", device_name)
    
    link_index = 0
    first_run = True
    
    try:
        while not stop_event.is_set() and link_index < len(device_links):
            stats['total_cycles'] += 1
            
            Logger.log(f"\n{'='*30}", device_name)
            Logger.log(f"🔄 第{stats['total_cycles']}轮测试开始", device_name)
            Logger.log(f"{'='*30}", device_name)
            
            # 确保Android运行
            if first_run:
                Logger.log("🔧 首次运行，确保Android系统运行", device_name)
                if not ensure_android_running(machine_name, device_name):
                    Logger.log("❌ 无法确保Android运行，跳过本轮", device_name)
                    continue
                first_run = False
            
            # 安装APK
            install_apk(machine_id, device_name)
            
            Logger.log(f"⏱️ 等待APK安装完成 {APK_INSTALL_WAIT}秒", device_name)
            time.sleep(APK_INSTALL_WAIT)
            
            # 启动Shopee
            shopee_opened = open_shopee(device_ip, device_name)
            
            if shopee_opened:
                Logger.log(f"⏱️ 等待Shopee完全启动 {APP_STARTUP_WAIT}秒", device_name)
                time.sleep(APP_STARTUP_WAIT)
                
                click_popup(device_ip, device_name)
                
                Logger.log(f"🎯 开始测试deeplinks", device_name)
                
                batch_tested = 0
                batch_success = 0
                
                while batch_tested < BATCH_SIZE and link_index < len(device_links) and not stop_event.is_set():
                    link = device_links[link_index]
                    link_index += 1
                    batch_tested += 1
                    stats['total_tested'] += 1
                    
                    Logger.log(f"📍 第{batch_tested}/{BATCH_SIZE}条 (设备总第{stats['total_tested']}条)", device_name)
                    
                    if execute_deeplink_test(device_ip, device_name, link):
                        batch_success += 1
                        stats['total_success'] += 1
                    
                    # 第三条截图
                    if batch_tested == 3:
                        Logger.log(f"📸 第三条deeplink完成，等待5秒后截图", device_name)
                        time.sleep(5)
                        take_screenshot(device_ip, device_name, stats['total_cycles'], batch_tested)
                        Logger.log(f"📸 截图完成，再等待3秒后继续", device_name)
                        time.sleep(3)
                    
                    # 测试间隔
                    if batch_tested < BATCH_SIZE and link_index < len(device_links):
                        Logger.log(f"⏱️ 等待{DEEPLINK_INTERVAL}秒后继续", device_name)
                        time.sleep(DEEPLINK_INTERVAL)
                
                # 统计
                success_rate = (batch_success / batch_tested * 100) if batch_tested > 0 else 0
                total_success_rate = (stats['total_success'] / stats['total_tested'] * 100) if stats['total_tested'] > 0 else 0
                
                Logger.log(f"📊 第{stats['total_cycles']}轮完成: {batch_tested}条, 成功{batch_success}条({success_rate:.1f}%)", device_name)
                Logger.log(f"📊 累计: {stats['total_tested']}条, 成功{stats['total_success']}条({total_success_rate:.1f}%)", device_name)
                
            else:
                Logger.log(f"❌ Shopee启动失败，跳过本轮测试", device_name)
            
            # 智能重置云机
            if link_index < len(device_links):
                Logger.log(f"🧠 使用智能监控重置云机", device_name)
                reset_cloud_machine(machine_id, device_name, device_ip)  # 传入device_ip启用智能监控
            
            save_progress(device_name, stats)
            
            if link_index < len(device_links):
                Logger.log(f"⏱️ 准备下一轮测试", device_name)
            else:
                Logger.log(f"🏁 设备分配的所有链接测试完成", device_name)
    
    except Exception as e:
        Logger.log(f"❌ 设备线程异常: {e}", device_name)
    
    # 最终统计
    elapsed_time = time.time() - stats['start_time']
    Logger.log(f"\n🏁 设备{device_name}测试结束", device_name)
    Logger.log(f"📊 总轮次: {stats['total_cycles']}", device_name)
    Logger.log(f"📊 总测试: {stats['total_tested']}条", device_name)
    Logger.log(f"📊 总成功: {stats['total_success']}条", device_name)
    Logger.log(f"📊 成功率: {(stats['total_success']/stats['total_tested']*100) if stats['total_tested'] > 0 else 0:.1f}%", device_name)
    Logger.log(f"⏱️ 运行时间: {elapsed_time/3600:.1f}小时", device_name)

def main():
    """主函数"""
    stop_event = threading.Event()
    
    def signal_handler(signum, frame):
        Logger.log("🛑 收到中断信号")
        stop_event.set()
    
    signal.signal(signal.SIGINT, signal_handler)
    
    Logger.log("🚀 启动多设备云机deeplink测试器 - 智能监控集成版")
    Logger.log(f"📡 云服务地址: {CLOUD_BASE_URL}")
    Logger.log(f"🖥️ 主机IP: {CLOUD_HOST_IP}")
    Logger.log(f"⚙️ 批次大小: {BATCH_SIZE}条/轮")
    Logger.log(f"🧠 核心优化: 智能云机状态监控，动态等待时间(通常30-90秒)")
    Logger.log(f"🛡️ 增强功能: offline自动恢复、智能ADB管理、稳定monkey启动")
    Logger.log(f"🎯 使用固定种子monkey启动(100%成功率)")
    Logger.log(f"⚡ 预期效果: 显著减少等待时间，平均节省50-110秒/轮")
    
    # 获取设备列表
    Logger.log("🔍 自动获取设备列表...")
    devices = CloudAPI.get_device_list()
    if not devices:
        Logger.log("❌ 未获取到设备列表")
        return
    
    device_list = []
    for device in devices:
        if device.get('state') == 'running':
            device_name = device.get('name', 'Unknown')
            device_ip = device.get('ip', 'Unknown')
            machine_id = device.get('id', 'Unknown')
            
            Logger.log(f"📱 设备: {device_name} - IP: {device_ip}")
            
            device_info = {
                'name': device_name,
                'ip': f"{device_ip}:5555",
                'machine_id': machine_id
            }
            device_list.append(device_info)
    
    Logger.log(f"✅ 发现{len(device_list)}个运行中的设备")
    
    if not device_list:
        Logger.log("❌ 没有运行中的设备")
        return
    
    # 加载链接
    all_links = load_deeplinks()
    if not all_links:
        Logger.log("❌ 未找到链接")
        return
    
    Logger.log(f"✅ 加载{len(all_links)}条链接")
    
    # 任务分配预览
    Logger.log("📋 任务分配预览:")
    for i, device in enumerate(device_list):
        device_link_count = len(range(i, len(all_links), len(device_list)))
        Logger.log(f"   {device['name']}: {device_link_count}条链接")
    
    try:
        # 启动设备线程
        with ThreadPoolExecutor(max_workers=len(device_list)) as executor:
            futures = []
            for device_index, device in enumerate(device_list):
                future = executor.submit(device_worker, device, all_links, stop_event, device_index, len(device_list))
                futures.append(future)
                Logger.log(f"✅ 启动设备: {device['name']} (索引:{device_index})", device['name'])
                time.sleep(2)
            
            # 等待完成
            for future in futures:
                try:
                    future.result()
                except Exception as e:
                    Logger.log(f"❌ 线程异常: {e}")
        
        Logger.log("🏁 所有测试完成")
        
    except KeyboardInterrupt:
        Logger.log("⏹️ 用户中断")
        stop_event.set()
    except Exception as e:
        Logger.log(f"❌ 程序异常: {e}")

if __name__ == "__main__":
    main()