#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Shopee应用专用启动器
基于测试结果优化，专注于最稳定的启动方式
"""

import subprocess
import time
import sys
from datetime import datetime
from typing import Tuple, List

class ShopeeOptimizedLauncher:
    def __init__(self, device_ip: str, package_name: str):
        self.device = device_ip
        self.package = package_name
        self.test_results = []
        
    def run_adb_command(self, command: str, timeout: int = 10) -> Tuple[bool, str]:
        """执行ADB命令，处理编码问题"""
        try:
            full_command = f"adb -s {self.device} {command}"
            result = subprocess.run(
                full_command.split(),
                capture_output=True,
                text=True,
                timeout=timeout,
                encoding='utf-8',
                errors='ignore'  # 忽略编码错误
            )
            
            if result.returncode == 0:
                return True, result.stdout.strip()
            else:
                return False, result.stderr.strip()
                
        except subprocess.TimeoutExpired:
            return False, f"命令超时 ({timeout}秒)"
        except Exception as e:
            return False, f"执行错误: {str(e)}"
    
    def force_stop_app(self) -> bool:
        """强制停止应用"""
        success, output = self.run_adb_command(f"shell am force-stop {self.package}")
        return success
    
    def check_app_running(self) -> bool:
        """检查应用是否正在运行"""
        success, output = self.run_adb_command(f"shell pidof {self.package}")
        return success and output.strip() != ""
    
    def get_current_activity(self) -> str:
        """获取当前前台Activity (Windows兼容)"""
        # Windows下使用findstr代替grep
        success, output = self.run_adb_command(r'shell "dumpsys activity activities | grep mResumedActivity"')
        if not success:
            # 如果grep失败，尝试获取完整输出再过滤
            success, full_output = self.run_adb_command("shell dumpsys activity activities")
            if success:
                lines = full_output.split('\n')
                for line in lines:
                    if 'mResumedActivity' in line and self.package in line:
                        return line.strip()
        return output
    
    def launch_method_monkey_stable(self) -> bool:
        """稳定的monkey启动方式"""
        success, output = self.run_adb_command(f"shell monkey -p {self.package} -c android.intent.category.LAUNCHER 1")
        return success and ("Events injected:" in output or "Monkey finished" in output)
    
    def launch_method_monkey_with_delay(self) -> bool:
        """带延迟的monkey启动 - 处理应用初始化"""
        success, output = self.run_adb_command(f"shell monkey -p {self.package} -c android.intent.category.LAUNCHER --throttle 500 1")
        return success and ("Events injected:" in output or "Monkey finished" in output)
    
    def launch_method_monkey_multiple_categories(self) -> bool:
        """多Category的monkey启动"""
        success, output = self.run_adb_command(f"shell monkey -p {self.package} -c android.intent.category.LAUNCHER -c android.intent.category.DEFAULT 1")
        return success and ("Events injected:" in output or "Monkey finished" in output)
    
    def launch_method_monkey_verbose(self) -> bool:
        """详细输出的monkey启动"""
        success, output = self.run_adb_command(f"shell monkey -p {self.package} -c android.intent.category.LAUNCHER -v -v 1")
        return success and ("Events injected:" in output or "Monkey finished" in output)
    
    def launch_method_monkey_random_seed(self) -> bool:
        """固定种子的monkey启动 - 保证一致性"""
        success, output = self.run_adb_command(f"shell monkey -p {self.package} -c android.intent.category.LAUNCHER -s 1000 1")
        return success and ("Events injected:" in output or "Monkey finished" in output)
    
    def get_real_activity_via_monkey(self) -> str:
        """通过monkey获取真实的启动Activity"""
        print("  🐒 通过monkey获取真实Activity...")
        
        # 停止应用
        self.force_stop_app()
        time.sleep(1)
        
        # 启动monkey
        success, output = self.run_adb_command(f"shell monkey -p {self.package} -c android.intent.category.LAUNCHER -v 1")
        
        if success:
            time.sleep(2)  # 等待应用完全启动
            
            # 获取当前Activity
            activity_info = self.get_current_activity()
            if activity_info and self.package in activity_info:
                print(f"  📱 找到Activity: {activity_info}")
                
                # 解析Activity名称
                import re
                match = re.search(r'(\S+)/(\S+)', activity_info)
                if match:
                    full_activity = f"{match.group(1)}/{match.group(2)}"
                    self.force_stop_app()
                    return full_activity
        
        self.force_stop_app()
        return ""
    
    def launch_method_real_activity(self) -> bool:
        """使用真实Activity启动"""
        real_activity = self.get_real_activity_via_monkey()
        if real_activity:
            print(f"  🎯 使用真实Activity: {real_activity}")
            success, output = self.run_adb_command(f"shell am start -n {real_activity}")
            return success and ("Starting:" in output or "Warning:" in output)
        return False
    
    def test_launch_method(self, method_name: str, launch_func, test_count: int = 10) -> dict:
        """测试特定启动方式"""
        print(f"\n🧪 测试启动方式: {method_name}")
        print(f"📊 测试次数: {test_count}")
        print("-" * 50)
        
        success_count = 0
        failed_tests = []
        total_time = 0
        
        for i in range(test_count):
            print(f"第 {i+1}/{test_count} 次测试: ", end="", flush=True)
            
            # 1. 强制停止应用
            self.force_stop_app()
            time.sleep(0.5)
            
            # 2. 尝试启动应用
            start_time = time.time()
            launch_success = launch_func()
            launch_time = time.time() - start_time
            total_time += launch_time
            
            if launch_success:
                # 3. 验证应用是否真的启动了
                time.sleep(1.5)  # 等待应用完全启动
                if self.check_app_running():
                    print(f"✅ 成功 ({launch_time:.2f}s)")
                    success_count += 1
                else:
                    print(f"❌ 命令成功但应用未运行")
                    failed_tests.append(f"测试{i+1}: 启动命令成功但应用未运行")
            else:
                print(f"❌ 启动失败")
                failed_tests.append(f"测试{i+1}: 启动命令失败")
            
            # 4. 停止应用准备下一次测试
            self.force_stop_app()
            time.sleep(0.5)
        
        # 计算统计信息
        success_rate = (success_count / test_count) * 100
        avg_time = total_time / test_count if test_count > 0 else 0
        
        result = {
            'method': method_name,
            'success_count': success_count,
            'total_count': test_count,
            'success_rate': success_rate,
            'avg_time': avg_time,
            'failed_tests': failed_tests
        }
        
        print(f"\n📈 {method_name} 结果:")
        print(f"   成功率: {success_rate:.1f}% ({success_count}/{test_count})")
        print(f"   平均耗时: {avg_time:.2f}秒")
        
        return result
    
    def run_optimized_stability_test(self, test_count_per_method: int = 10):
        """运行优化的稳定性测试"""
        print("=" * 60)
        print("🚀 Shopee应用优化启动稳定性测试")
        print("=" * 60)
        print(f"设备: {self.device}")
        print(f"应用: {self.package}")
        print(f"每种方式测试次数: {test_count_per_method}")
        print(f"开始时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        
        # 基于测试结果的优化方法列表
        test_methods = [
            ("方式1: 标准monkey启动", self.launch_method_monkey_stable),
            ("方式2: 延迟monkey启动", self.launch_method_monkey_with_delay),
            ("方式3: 固定种子monkey启动", self.launch_method_monkey_random_seed),
            ("方式4: 详细输出monkey启动", self.launch_method_monkey_verbose),
            ("方式5: 多Category monkey启动", self.launch_method_monkey_multiple_categories),
            ("方式6: 真实Activity启动", self.launch_method_real_activity),
        ]
        
        # 执行所有测试
        for method_name, method_func in test_methods:
            try:
                result = self.test_launch_method(method_name, method_func, test_count_per_method)
                self.test_results.append(result)
            except KeyboardInterrupt:
                print("\n⚠️ 用户中断测试")
                break
            except Exception as e:
                print(f"\n❌ {method_name} 测试出现异常: {str(e)}")
                continue
        
        # 显示最终结果
        self.show_final_results()
    
    def show_final_results(self):
        """显示最终测试结果"""
        print("\n" + "=" * 80)
        print("📊 Shopee应用启动稳定性测试 - 最终结果")
        print("=" * 80)
        
        if not self.test_results:
            print("❌ 没有完成任何测试")
            return
        
        # 按成功率排序
        sorted_results = sorted(self.test_results, key=lambda x: (x['success_rate'], -x['avg_time']), reverse=True)
        
        print(f"{'排名':<4} {'启动方式':<25} {'成功率':<8} {'平均耗时':<10} {'成功次数':<10}")
        print("-" * 80)
        
        for i, result in enumerate(sorted_results, 1):
            success_info = f"{result['success_count']}/{result['total_count']}"
            avg_time = f"{result['avg_time']:.2f}s"
            print(f"{i:<4} {result['method']:<25} {result['success_rate']:>6.1f}% {avg_time:>8} {success_info:>8}")
        
        # 推荐方式
        best_method = sorted_results[0]
        print(f"\n🏆 最推荐方式: {best_method['method']}")
        print(f"   ✅ 成功率: {best_method['success_rate']:.1f}%")
        print(f"   ⚡ 平均耗时: {best_method['avg_time']:.2f}秒")
        
        # 性能对比
        fastest_method = min(sorted_results, key=lambda x: x['avg_time'] if x['success_rate'] > 90 else float('inf'))
        if fastest_method['success_rate'] > 90:
            print(f"\n🚀 最快方式 (90%+成功率): {fastest_method['method']}")
            print(f"   ⚡ 平均耗时: {fastest_method['avg_time']:.2f}秒")
            print(f"   ✅ 成功率: {fastest_method['success_rate']:.1f}%")
        
        # 实用建议
        print(f"\n💡 实用建议:")
        print(f"   1. 日常使用推荐: {best_method['method']}")
        if fastest_method != best_method and fastest_method['success_rate'] > 90:
            print(f"   2. 追求速度推荐: {fastest_method['method']}")
        
        # 对应的ADB命令
        print(f"\n📝 推荐的ADB命令:")
        if "标准monkey" in best_method['method']:
            print(f"   adb -s {self.device} shell monkey -p {self.package} -c android.intent.category.LAUNCHER 1")
        elif "延迟monkey" in best_method['method']:
            print(f"   adb -s {self.device} shell monkey -p {self.package} -c android.intent.category.LAUNCHER --throttle 500 1")
        elif "固定种子" in best_method['method']:
            print(f"   adb -s {self.device} shell monkey -p {self.package} -c android.intent.category.LAUNCHER -s 1000 1")

def main():
    """主函数"""
    # 配置参数
    DEVICE_IP = "172.16.102.6:5555"
    PACKAGE_NAME = "com.shopee.tw"
    TEST_COUNT = 10  # 每种方式测试次数
    
    print("Shopee应用专用启动稳定性测试工具")
    print("基于monkey优化的高稳定性测试")
    print("-" * 50)
    
    # 创建测试器
    launcher = ShopeeOptimizedLauncher(DEVICE_IP, PACKAGE_NAME)
    
    # 运行测试
    try:
        launcher.run_optimized_stability_test(TEST_COUNT)
    except KeyboardInterrupt:
        print("\n⚠️ 测试被用户中断")
    except Exception as e:
        print(f"\n❌ 测试过程中出现错误: {str(e)}")
    
    print(f"\n✅ 测试完成 - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

if __name__ == "__main__":
    main()