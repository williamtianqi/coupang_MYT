import subprocess
import time
import csv
import json
import os
import datetime
import threading
from urllib.parse import quote_plus
from concurrent.futures import ThreadPoolExecutor
import queue

# ⚙️ 多设备配置
DEVICE_LIST = [
    {"name": "T2011", "ip": "172.16.101.2:5555"},
    {"name": "T2012", "ip": "172.16.101.3:5555"},
    {"name": "T2013", "ip": "172.16.102.4:5555"},
    {"name": "T2014", "ip": "172.16.102.5:5555"},
    # {"name": "T1001", "ip": "172.16.101.3:5555"},
    # {"name": "T1002", "ip": "172.16.101.4:5555"},
    # {"name": "T1001-2", "ip": "172.16.104.8:5555"},
    # {"name": "T1002-2", "ip": "172.16.104.9:5555"},
    # {"name": "T1005", "ip": "172.16.103.1:5555"},
    # {"name": "T1003", "ip": "172.16.104.11:5555"},
]

# ⚙️ 核心配置
DEEPLINK_FILE = "data1.csv"          # 支持CSV/JSON格式
RETRY_COUNT = 3                      # 失败重试次数
SCHEME_WHITELIST = ["https://", "http://", "shopee://", "myapp://"]
SHOPEE_PACKAGE = "com.shopee.tw"

# 24小时测试配置
TEST_DURATION_HOURS = 24             # 测试持续时间（小时）
BASE_WAIT_TIME = 40                  # 每次请求后等待时间(秒)
MAX_WAIT_TIME = 40                   # 最大等待时间(秒)
APP_RESTART_INTERVAL = 10            # 每测试10条重启一次应用
APP_RESTART_WAIT_TIME = 3            # 应用重启后等待时间(秒)
PROGRESS_REPORT_INTERVAL = 300       # 每5分钟报告一次进度(秒)
PERFORMANCE_LOG_INTERVAL = 60        # 每1分钟记录性能数据(秒)
CONNECTION_CHECK_INTERVAL = 30       # 每30秒检查连接状态
LOG_FILE = "deeplink_24h_test.log"
PERFORMANCE_LOG_FILE = "performance_24h.csv"

# 缓存清理配置
ENABLE_CACHE_CLEAR = True
CACHE_CLEAR_METHOD = "cache_only"    # "cache_only", "data_full", "temp_files"

# 并发控制
MAX_WORKERS = len(DEVICE_LIST)
TASK_QUEUE_SIZE = 1000

class Logger:
    """线程安全的日志记录器"""
    _lock = threading.Lock()
    
    @staticmethod
    def log(message, print_to_console=True, device_name="MAIN"):
        """记录日志到文件并可选择打印到控制台"""
        timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        log_entry = f"[{timestamp}][{device_name}] {message}"
        
        with Logger._lock:
            try:
                with open(LOG_FILE, "a", encoding="utf-8") as f:
                    f.write(log_entry + "\n")
            except Exception as e:
                if print_to_console:
                    print(f"❌ 写入日志失败: {str(e)}")
            
            if print_to_console:
                print(f"[{device_name}] {message}")

class PerformanceMonitor:
    """性能监控器"""
    def __init__(self):
        self._lock = threading.Lock()
        self.performance_data = []
        self.last_record_time = time.time()
        
        # 初始化CSV文件
        self._init_performance_csv()
    
    def _init_performance_csv(self):
        """初始化性能CSV文件"""
        headers = [
            "timestamp", "elapsed_hours", "total_tested", "total_success", "total_failed", 
            "success_rate", "current_rate_per_minute", "avg_rate_per_minute",
            "estimated_24h_total", "devices_active", "app_restarts", "cache_clears"
        ]
        
        try:
            with open(PERFORMANCE_LOG_FILE, "w", newline="", encoding="utf-8") as f:
                writer = csv.writer(f)
                writer.writerow(headers)
        except Exception as e:
            Logger.log(f"❌ 初始化性能CSV失败: {str(e)}")
    
    def record_performance(self, stats):
        """记录性能数据"""
        with self._lock:
            current_time = time.time()
            summary = stats.get_summary()
            
            # 计算当前速率（最近一分钟）
            current_rate = 0
            if len(self.performance_data) > 0:
                time_diff = current_time - self.last_record_time
                tested_diff = summary['total_tested'] - (self.performance_data[-1]['total_tested'] if self.performance_data else 0)
                current_rate = (tested_diff / time_diff * 60) if time_diff > 0 else 0
            
            # 计算预估24小时总量
            elapsed_hours = summary['elapsed_minutes'] / 60
            estimated_24h = (summary['total_tested'] / elapsed_hours * 24) if elapsed_hours > 0 else 0
            
            # 统计活跃设备和重启次数
            devices_active = sum(1 for device_stat in summary['device_stats'].values() if device_stat['tested'] > 0)
            total_restarts = sum(device_stat['app_restarts'] for device_stat in summary['device_stats'].values())
            total_cache_clears = sum(device_stat['cache_clears'] for device_stat in summary['device_stats'].values())
            
            perf_data = {
                "timestamp": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "elapsed_hours": elapsed_hours,
                "total_tested": summary['total_tested'],
                "total_success": summary['total_success'],
                "total_failed": summary['total_failed'],
                "success_rate": summary['success_rate'],
                "current_rate_per_minute": current_rate,
                "avg_rate_per_minute": summary['rate_per_minute'],
                "estimated_24h_total": estimated_24h,
                "devices_active": devices_active,
                "app_restarts": total_restarts,
                "cache_clears": total_cache_clears
            }
            
            self.performance_data.append(perf_data)
            self.last_record_time = current_time
            
            # 写入CSV
            try:
                with open(PERFORMANCE_LOG_FILE, "a", newline="", encoding="utf-8") as f:
                    writer = csv.writer(f)
                    writer.writerow([
                        perf_data["timestamp"], f"{perf_data['elapsed_hours']:.2f}",
                        perf_data["total_tested"], perf_data["total_success"], perf_data["total_failed"],
                        f"{perf_data['success_rate']:.2f}%", f"{perf_data['current_rate_per_minute']:.2f}",
                        f"{perf_data['avg_rate_per_minute']:.2f}", f"{perf_data['estimated_24h_total']:.0f}",
                        perf_data["devices_active"], perf_data["app_restarts"], perf_data["cache_clears"]
                    ])
            except Exception as e:
                Logger.log(f"❌ 写入性能CSV失败: {str(e)}")

class DeviceManager:
    """设备管理器"""
    
    def __init__(self, device_info):
        self.name = device_info["name"]
        self.ip = device_info["ip"]
        self.connected = False
        self.last_check_time = 0
        self.last_success_time = time.time()
        
    def connect_device(self):
        """连接到指定的ADB设备"""
        Logger.log(f"🔗 正在连接设备: {self.ip}", device_name=self.name)
        try:
            subprocess.run("adb start-server", shell=True, capture_output=True, text=True, timeout=10)
            
            cmd = f"adb connect {self.ip}"
            result = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=15)
            
            if "connected" in result.stdout.lower() or "already connected" in result.stdout.lower():
                verify = subprocess.run(f"adb -s {self.ip} shell echo connected", 
                                      shell=True, capture_output=True, text=True, timeout=5)
                if "connected" in verify.stdout.lower():
                    self.connected = True
                    Logger.log(f"✅ 设备连接成功", device_name=self.name)
                    return True
                else:
                    Logger.log(f"⚠️ 设备连接失败，验证不通过", device_name=self.name)
                    return False
            else:
                Logger.log(f"❌ 设备连接失败: {result.stdout.strip()}", device_name=self.name)
                return False
        except subprocess.TimeoutExpired:
            Logger.log(f"❌ 连接超时", device_name=self.name)
            return False
        except Exception as e:
            Logger.log(f"❌ 连接异常: {str(e)}", device_name=self.name)
            return False
    
    def check_device_connected(self):
        """检查设备是否已连接"""
        try:
            cmd = "adb devices"
            result = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=5)
            return self.ip in result.stdout and "device" in result.stdout
        except:
            return False
    
    def ensure_connection(self):
        """确保设备连接"""
        current_time = time.time()
        
        if current_time - self.last_check_time > CONNECTION_CHECK_INTERVAL:
            self.last_check_time = current_time
            if not self.check_device_connected():
                Logger.log("⚠️ 设备断开连接，尝试重连...", device_name=self.name)
                self.connected = self.connect_device()
        
        return self.connected
    
    def execute_deeplink(self, deeplink):
        """执行深度链接测试"""
        if not self.ensure_connection():
            Logger.log("❌ 设备连接失败，跳过此链接", device_name=self.name)
            return False, 0
        
        normalized_link = DeeplinkValidator.normalize_shopee_link(deeplink)
        
        for attempt in range(RETRY_COUNT + 1):
            cmd = f"adb -s {self.ip} shell am start -a android.intent.action.VIEW -d '{normalized_link}'"
            
            try:
                result = subprocess.run(cmd, shell=True,
                                      capture_output=True,
                                      text=True,
                                      timeout=15)
                
                if result.returncode == 0 and "Error" not in result.stderr:
                    self.last_success_time = time.time()
                    return True, attempt + 1
                else:
                    Logger.log(f"⚠️ 执行可能有问题，返回码: {result.returncode}", device_name=self.name)
                    
            except subprocess.TimeoutExpired:
                Logger.log(f"⏱️ 命令超时 (第{attempt+1}次)", device_name=self.name)
            except Exception as e:
                Logger.log(f"❌ 执行异常: {str(e)}", device_name=self.name)
            
            if attempt < RETRY_COUNT:
                time.sleep(1)
        
        return False, RETRY_COUNT + 1
    
    def clear_app_cache(self):
        """清理应用缓存"""
        if not self.ensure_connection():
            return False
        
        if not ENABLE_CACHE_CLEAR:
            return True
        
        try:
            if CACHE_CLEAR_METHOD == "cache_only":
                cmd = f"adb -s {self.ip} shell pm clear-cache {SHOPEE_PACKAGE}"
                result = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=15)
                return result.returncode == 0
            elif CACHE_CLEAR_METHOD == "data_full":
                cmd = f"adb -s {self.ip} shell pm clear {SHOPEE_PACKAGE}"
                result = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=15)
                return result.returncode == 0
            else:
                return True
        except Exception as e:
            Logger.log(f"❌ 清理缓存异常: {str(e)}", device_name=self.name)
            return False
    
    def kill_app(self, clear_cache=True):
        """强制停止应用并可选择清理缓存"""
        if not self.ensure_connection():
            return False
        
        try:
            cmd = f"adb -s {self.ip} shell am force-stop {SHOPEE_PACKAGE}"
            result = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=10)
            
            if result.returncode == 0:
                if clear_cache and ENABLE_CACHE_CLEAR:
                    self.clear_app_cache()
                time.sleep(APP_RESTART_WAIT_TIME)
                return True
            return False
            
        except Exception as e:
            Logger.log(f"❌ 停止应用异常: {str(e)}", device_name=self.name)
            return False

class DeeplinkValidator:
    @staticmethod
    def is_valid(deeplink):
        """验证深度链接合法性"""
        return any(deeplink.startswith(s) for s in SCHEME_WHITELIST)
    
    @staticmethod
    def normalize_shopee_link(link):
        """标准化Shopee链接格式"""
        if link.startswith('/'):
            link = f"https://shopee.tw{link}"
        elif not link.startswith(('http://', 'https://')):
            link = f"https://shopee.tw/{link.lstrip('/')}"
        return link

class TestStatistics:
    """增强的测试统计信息"""
    def __init__(self):
        self._lock = threading.Lock()
        self.total_tested = 0
        self.total_success = 0
        self.total_failed = 0
        self.device_stats = {device["name"]: {
            "tested": 0, "success": 0, "failed": 0,
            "app_restarts": 0, "cache_clears": 0,
            "last_activity": time.time()
        } for device in DEVICE_LIST}
        self.start_time = time.time()
        self.failed_links = []
        self.hourly_stats = {}  # 每小时统计
        
    def record_result(self, device_name, link, success):
        """记录测试结果"""
        with self._lock:
            current_time = time.time()
            self.total_tested += 1
            self.device_stats[device_name]["tested"] += 1
            self.device_stats[device_name]["last_activity"] = current_time
            
            # 记录每小时统计
            hour_key = datetime.datetime.now().strftime("%Y-%m-%d %H:00")
            if hour_key not in self.hourly_stats:
                self.hourly_stats[hour_key] = {"tested": 0, "success": 0, "failed": 0}
            
            self.hourly_stats[hour_key]["tested"] += 1
            
            if success:
                self.total_success += 1
                self.device_stats[device_name]["success"] += 1
                self.hourly_stats[hour_key]["success"] += 1
            else:
                self.total_failed += 1
                self.device_stats[device_name]["failed"] += 1
                self.hourly_stats[hour_key]["failed"] += 1
                self.failed_links.append({"link": link, "time": current_time, "device": device_name})
    
    def record_app_restart(self, device_name):
        """记录应用重启"""
        with self._lock:
            self.device_stats[device_name]["app_restarts"] += 1
    
    def record_cache_clear(self, device_name):
        """记录缓存清理"""
        with self._lock:
            self.device_stats[device_name]["cache_clears"] += 1
    
    def get_summary(self):
        """获取统计摘要"""
        with self._lock:
            elapsed_time = time.time() - self.start_time
            rate_per_minute = (self.total_tested / (elapsed_time / 60)) if elapsed_time > 0 else 0
            
            return {
                "total_tested": self.total_tested,
                "total_success": self.total_success,
                "total_failed": self.total_failed,
                "success_rate": (self.total_success / self.total_tested * 100) if self.total_tested > 0 else 0,
                "elapsed_minutes": elapsed_time / 60,
                "rate_per_minute": rate_per_minute,
                "device_stats": self.device_stats.copy(),
                "failed_links": self.failed_links.copy(),
                "hourly_stats": self.hourly_stats.copy()
            }

class LinkProvider:
    """链接提供器 - 支持循环使用有限的链接"""
    def __init__(self, links):
        self.original_links = links
        self.current_index = 0
        self.cycle_count = 0
        self._lock = threading.Lock()
    
    def get_next_link(self):
        """获取下一个链接（循环使用）"""
        with self._lock:
            if not self.original_links:
                return None
            
            link = self.original_links[self.current_index]
            self.current_index += 1
            
            if self.current_index >= len(self.original_links):
                self.current_index = 0
                self.cycle_count += 1
                Logger.log(f"🔄 完成第 {self.cycle_count} 轮链接循环 (共{len(self.original_links)}条链接)")
            
            return link
    
    def get_stats(self):
        """获取链接使用统计"""
        with self._lock:
            return {
                "total_links": len(self.original_links),
                "cycles_completed": self.cycle_count,
                "current_position": self.current_index
            }

def load_deeplinks():
    """智能加载多格式数据源"""
    try:
        if DEEPLINK_FILE.endswith('.csv'):
            with open(DEEPLINK_FILE, encoding='utf-8') as f:
                reader = csv.DictReader(f)
                links = []
                for row in reader:
                    url = row.get('url') or row.get('deeplink') or row.get('link')
                    if url:
                        links.append(url.strip())
                return links
                        
        elif DEEPLINK_FILE.endswith('.json'):
            with open(DEEPLINK_FILE, encoding='utf-8') as f:
                data = json.load(f)
                if isinstance(data, list):
                    return [item if isinstance(item, str) else item.get('url', '') for item in data]
                elif 'links' in data:
                    return [item.get('uri', item.get('url', '')) for item in data]
                else:
                    return []
                    
    except FileNotFoundError:
        Logger.log(f"❌ 文件未找到: {DEEPLINK_FILE}")
        return []
    except Exception as e:
        Logger.log(f"❌ 文件加载失败: {str(e)}")
        return []

def worker_thread(device_manager, link_provider, stats, stop_event):
    """24小时测试工作线程"""
    Logger.log(f"🚀 24小时测试线程启动", device_name=device_manager.name)
    
    # 连接设备
    if not device_manager.connect_device():
        Logger.log(f"❌ 设备连接失败，工作线程退出", device_name=device_manager.name)
        return
    
    processed_count = 0
    
    while not stop_event.is_set():
        try:
            # 获取下一个链接
            link = link_provider.get_next_link()
            if not link:
                Logger.log(f"❌ 没有可用链接", device_name=device_manager.name)
                break
            
            processed_count += 1
            
            # 执行测试
            success, attempts = device_manager.execute_deeplink(link)
            stats.record_result(device_manager.name, link, success)
            
            # 应用重启和缓存清理
            if processed_count % APP_RESTART_INTERVAL == 0:
                if device_manager.kill_app(clear_cache=True):
                    stats.record_app_restart(device_manager.name)
                    if ENABLE_CACHE_CLEAR:
                        stats.record_cache_clear(device_manager.name)
            
            # 等待指定时间
            if not stop_event.wait(BASE_WAIT_TIME):
                continue  # 如果是正常等待完成，继续下一个循环
            else:
                break  # 如果是收到停止信号，退出循环
            
        except Exception as e:
            Logger.log(f"❌ 工作线程异常: {str(e)}", device_name=device_manager.name)
            if not stop_event.wait(5):  # 等待5秒后重试
                continue
            else:
                break
    
    Logger.log(f"✅ 工作线程结束，共处理 {processed_count} 条链接", device_name=device_manager.name)

def print_progress_summary(stats, link_provider, elapsed_hours):
    """打印详细进度摘要"""
    summary = stats.get_summary()
    link_stats = link_provider.get_stats()
    
    Logger.log(f"\n{'='*80}")
    Logger.log(f"📊 24小时测试实时报告 (已运行: {elapsed_hours:.2f} 小时 / {TEST_DURATION_HOURS} 小时)")
    Logger.log(f"{'='*80}")
    
    # 基础统计
    Logger.log(f"📈 总体统计:")
    Logger.log(f"  测试总量: {summary['total_tested']} | 成功: {summary['total_success']} | 失败: {summary['total_failed']}")
    Logger.log(f"  成功率: {summary['success_rate']:.2f}% | 当前速率: {summary['rate_per_minute']:.2f} 链接/分钟")
    
    # 预估统计
    estimated_24h = (summary['total_tested'] / elapsed_hours * 24) if elapsed_hours > 0 else 0
    remaining_hours = TEST_DURATION_HOURS - elapsed_hours
    estimated_remaining = summary['rate_per_minute'] * 60 * remaining_hours
    
    Logger.log(f"📊 预估统计:")
    Logger.log(f"  预估24小时总量: {estimated_24h:.0f} 条")
    Logger.log(f"  剩余时间: {remaining_hours:.2f} 小时")
    Logger.log(f"  预估还能处理: {estimated_remaining:.0f} 条")
    
    # 链接循环统计
    Logger.log(f"🔄 链接循环统计:")
    Logger.log(f"  原始链接数: {link_stats['total_links']}")
    Logger.log(f"  已完成循环: {link_stats['cycles_completed']} 轮")
    Logger.log(f"  当前位置: {link_stats['current_position']}/{link_stats['total_links']}")
    
    # 设备性能
    Logger.log(f"📱 设备性能:")
    active_devices = 0
    for device_name, device_stat in summary['device_stats'].items():
        if device_stat['tested'] > 0:
            active_devices += 1
            device_success_rate = (device_stat['success'] / device_stat['tested'] * 100) if device_stat['tested'] > 0 else 0
            last_activity = time.time() - device_stat['last_activity']
            Logger.log(f"  {device_name}: {device_stat['tested']}条 | 成功率: {device_success_rate:.1f}% | "
                      f"重启: {device_stat['app_restarts']}次 | 最后活动: {last_activity:.0f}秒前")
    
    Logger.log(f"  活跃设备: {active_devices}/{len(DEVICE_LIST)}")

def save_final_report(stats, link_provider, actual_duration):
    """保存最终测试报告"""
    summary = stats.get_summary()
    link_stats = link_provider.get_stats()
    
    report = {
        "test_info": {
            "start_time": datetime.datetime.fromtimestamp(stats.start_time).isoformat(),
            "end_time": datetime.datetime.now().isoformat(),
            "planned_duration_hours": TEST_DURATION_HOURS,
            "actual_duration_hours": actual_duration,
            "completion_rate": (actual_duration / TEST_DURATION_HOURS * 100) if TEST_DURATION_HOURS > 0 else 0
        },
        "performance_summary": {
            "total_tested": summary['total_tested'],
            "total_success": summary['total_success'],
            "total_failed": summary['total_failed'],
            "success_rate": summary['success_rate'],
            "average_rate_per_minute": summary['rate_per_minute'],
            "average_rate_per_hour": summary['rate_per_minute'] * 60,
            "estimated_24h_capacity": (summary['total_tested'] / actual_duration * 24) if actual_duration > 0 else 0
        },
        "link_usage": {
            "original_links_count": link_stats['total_links'],
            "cycles_completed": link_stats['cycles_completed'],
            "total_link_executions": summary['total_tested'],
            "average_executions_per_link": summary['total_tested'] / link_stats['total_links'] if link_stats['total_links'] > 0 else 0
        },
        "device_performance": summary['device_stats'],
        "hourly_breakdown": summary['hourly_stats'],
        "configuration": {
            "base_wait_time": BASE_WAIT_TIME,
            "app_restart_interval": APP_RESTART_INTERVAL,
            "device_count": len(DEVICE_LIST),
            "cache_clear_enabled": ENABLE_CACHE_CLEAR,
            "cache_clear_method": CACHE_CLEAR_METHOD
        },
        "failed_links_sample": summary['failed_links'][-100:] if summary['failed_links'] else []  # 最后100个失败
    }
    
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    report_file = f"24h_test_report_{timestamp}.json"
    
    try:
        with open(report_file, 'w', encoding='utf-8') as f:
            json.dump(report, f, ensure_ascii=False, indent=2)
        Logger.log(f"✅ 最终报告已保存到 {report_file}")
    except Exception as e:
        Logger.log(f"❌ 保存最终报告失败: {str(e)}")
    
    return report

def main():
    """主函数：执行24小时性能测试"""
    Logger.log("🚀 启动24小时云手机Deeplink性能测试")
    Logger.log(f"⏰ 测试持续时间: {TEST_DURATION_HOURS} 小时")
    Logger.log(f"📱 测试设备数量: {len(DEVICE_LIST)} 台")
    Logger.log(f"⏱️ 每次请求等待: {BASE_WAIT_TIME} 秒")
    Logger.log(f"🔄 每 {APP_RESTART_INTERVAL} 次请求重启应用")
    Logger.log(f"🧹 缓存清理: {'启用' if ENABLE_CACHE_CLEAR else '禁用'} ({CACHE_CLEAR_METHOD})")
    
    # 理论性能计算
    avg_time_per_request = BASE_WAIT_TIME + (APP_RESTART_WAIT_TIME / APP_RESTART_INTERVAL)
    theoretical_per_device_24h = int(24 * 3600 / avg_time_per_request)
    theoretical_total_24h = theoretical_per_device_24h * len(DEVICE_LIST)
    
    Logger.log(f"📊 理论性能预估:")
    Logger.log(f"  单设备24小时理论处理量: {theoretical_per_device_24h} 条")
    Logger.log(f"  {len(DEVICE_LIST)}设备24小时理论总处理量: {theoretical_total_24h} 条")
    Logger.log(f"  理论平均速率: {theoretical_total_24h/24:.0f} 条/小时")
    
    # 加载并验证链接
    all_links = load_deeplinks()
    if not all_links:
        Logger.log("❌ 未找到可测试的链接")
        return
    
    valid_links = [link for link in all_links if link and DeeplinkValidator.is_valid(link)]
    Logger.log(f"✅ 加载有效链接 {len(valid_links)} 条 (将循环使用)")
    
    if not valid_links:
        Logger.log("❌ 没有有效的链接可供测试")
        return
    
    # 初始化组件
    stats = TestStatistics()
    link_provider = LinkProvider(valid_links)
    performance_monitor = PerformanceMonitor()
    stop_event = threading.Event()
    
    # 创建设备管理器
    device_managers = [DeviceManager(device) for device in DEVICE_LIST]
    
    # 启动工作线程
    threads = []
    for device_manager in device_managers:
        thread = threading.Thread(target=worker_thread, args=(device_manager, link_provider, stats, stop_event))
        thread.daemon = True
        thread.start()
        threads.append(thread)
    
    Logger.log(f"🎯 开始24小时性能测试...")
    test_start_time = time.time()
    last_progress_time = time.time()
    last_performance_time = time.time()
    
    try:
        while True:
            time.sleep(10)  # 每10秒检查一次
            
            current_time = time.time()
            elapsed_time = current_time - test_start_time
            elapsed_hours = elapsed_time / 3600
            
            # 检查是否达到24小时
            if elapsed_hours >= TEST_DURATION_HOURS:
                Logger.log(f"⏰ 达到预设测试时间 {TEST_DURATION_HOURS} 小时，停止测试")
                break
            
            # 定期进度报告
            if current_time - last_progress_time >= PROGRESS_REPORT_INTERVAL:
                print_progress_summary(stats, link_provider, elapsed_hours)
                last_progress_time = current_time
            
            # 性能数据记录
            if current_time - last_performance_time >= PERFORMANCE_LOG_INTERVAL:
                performance_monitor.record_performance(stats)
                last_performance_time = current_time
    
    except KeyboardInterrupt:
        Logger.log("\n👋 用户手动停止测试...")
    
    # 停止所有线程
    Logger.log("🛑 正在停止所有测试线程...")
    stop_event.set()
    
    # 等待线程结束
    for thread in threads:
        thread.join(timeout=30)
    
    # 计算实际测试时间
    actual_duration = (time.time() - test_start_time) / 3600
    
    # 最终统计报告
    Logger.log("\n" + "="*80)
    Logger.log("📊 24小时性能测试最终报告")
    Logger.log("="*80)
    
    final_report = save_final_report(stats, link_provider, actual_duration)
    
    summary = final_report['performance_summary']
    link_usage = final_report['link_usage']
    
    Logger.log(f"⏰ 测试时长: {actual_duration:.2f} 小时 (计划: {TEST_DURATION_HOURS} 小时)")
    Logger.log(f"📈 性能结果:")
    Logger.log(f"  总处理量: {summary['total_tested']} 条")
    Logger.log(f"  成功: {summary['total_success']} | 失败: {summary['total_failed']}")
    Logger.log(f"  成功率: {summary['success_rate']:.2f}%")
    Logger.log(f"  平均速率: {summary['average_rate_per_minute']:.2f} 条/分钟")
    Logger.log(f"  平均速率: {summary['average_rate_per_hour']:.0f} 条/小时")
    Logger.log(f"  预估24小时容量: {summary['estimated_24h_capacity']:.0f} 条")
    
    Logger.log(f"🔄 链接使用情况:")
    Logger.log(f"  原始链接: {link_usage['original_links_count']} 条")
    Logger.log(f"  完成循环: {link_usage['cycles_completed']} 轮")
    Logger.log(f"  平均每条链接被执行: {link_usage['average_executions_per_link']:.1f} 次")
    
    # 与理论值对比
    actual_efficiency = (summary['total_tested'] / actual_duration) / (theoretical_total_24h / 24) * 100 if actual_duration > 0 else 0
    Logger.log(f"📊 效率分析:")
    Logger.log(f"  理论24小时处理量: {theoretical_total_24h} 条")
    Logger.log(f"  实际效率: {actual_efficiency:.1f}% (相对于理论值)")
    
    Logger.log("✅ 24小时性能测试完成！")
    Logger.log(f"📋 详细报告: {final_report}")
    Logger.log(f"📋 性能数据: {PERFORMANCE_LOG_FILE}")
    Logger.log(f"📋 详细日志: {LOG_FILE}")

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        Logger.log("\n👋 程序被用户中断")
        exit(0)
    except Exception as e:
        Logger.log(f"\n❌ 程序异常: {str(e)}")
        import traceback
        traceback.print_exc()
        exit(1)