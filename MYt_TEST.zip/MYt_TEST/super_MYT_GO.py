#!/usr/bin/env python3
"""
修改版云机群控脚本 - 取消重置，改为卸载重装循环
修改内容：
1. 取消重置机器步骤
2. 完成deeplink测试后卸载shopee
3. 重新安装shopee
4. 调用随机设备信息API
5. 成功后继续下一轮测试

流程：初始安装 -> 启动APP -> deeplink测试 -> 卸载 -> 重装 -> 随机设备信息 -> 循环
"""

import subprocess
import time
import csv
import json
import requests
import urllib.parse
import datetime
import os
import threading
import re
from concurrent.futures import ThreadPoolExecutor
import signal
import sys

# 云服务配置
CLOUD_BASE_URL = "http://127.0.0.1:9000"
CLOUD_HOST_IP = "172.16.253.249"
APK_PATH = "C:\\Program Files (x86)\\WuhanMoyuntengNetWork\\MYT_Zeus\\Shared\\shopee-tw-3-28-34.apk"

# 应用配置
SHOPEE_PACKAGE = "com.shopee.tw"
DEEPLINK_FILE = "shopee_deals_10k.csv"
BATCH_SIZE = 7

# 验证过的时间配置
APP_STARTUP_WAIT = 8       # 应用启动后等待时间
CLICK_DELAY = 9            # 点击后等待时间 - 确保弹窗完全过掉
DEEPLINK_INTERVAL = 4      # deeplink间隔时间
STATUS_CHECK_INTERVAL = 5  # 状态检查间隔

# 验证过的点击坐标
CLICK_X = 340
CLICK_Y = 1160

# 截图配置
SCREENSHOT_DIR = "screenshots"
LOG_FILE = "complete_cloud_control.log"

class Logger:
    _lock = threading.Lock()
    
    @staticmethod
    def log(message, device="MAIN"):
        timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        log_entry = f"[{timestamp}][{device}] {message}"
        
        with Logger._lock:
            try:
                with open(LOG_FILE, "a", encoding="utf-8") as f:
                    f.write(log_entry + "\n")
            except:
                pass
            print(log_entry)

class CloudAPI:
    """云机API控制类"""
    
    @staticmethod
    def get_device_list():
        """获取设备列表"""
        url = f"{CLOUD_BASE_URL}/dc_api/v1/list/{CLOUD_HOST_IP}"
        try:
            response = requests.get(url, timeout=30)
            if response.status_code == 200:
                data = response.json()
                if data.get('code') == 200 and 'data' in data:
                    return data['data']
            return []
        except Exception as e:
            Logger.log(f"❌ 获取设备列表失败: {e}")
            return []
    
    @staticmethod
    def get_device_status(machine_id):
        """获取单个设备状态"""
        try:
            devices = CloudAPI.get_device_list()
            for device in devices:
                if device.get('id') == machine_id:
                    return device.get('state', ''), device
            return 'unknown', None
        except Exception as e:
            Logger.log(f"⚠️ 获取状态异常: {e}")
            return 'error', None
    
    @staticmethod
    def run_android_container(machine_name, device_name):
        """运行Android容器"""
        url = f"{CLOUD_BASE_URL}/run/{CLOUD_HOST_IP}/{machine_name}"
        try:
            Logger.log("🏃 启动Android容器", device_name)
            response = requests.get(url, timeout=60)
            
            if response.status_code == 200:
                data = response.json()
                if data.get('code') == 200:
                    Logger.log("✅ Android容器启动成功", device_name)
                    return True
                else:
                    Logger.log(f"❌ Android容器启动失败: {data}", device_name)
                    return False
            else:
                Logger.log(f"❌ HTTP错误: {response.status_code}", device_name)
                return False
                
        except Exception as e:
            Logger.log(f"❌ 启动Android容器异常: {e}", device_name)
            return False
    
    @staticmethod
    def check_android_boot_status(machine_name, device_name):
        """检查Android启动状态"""
        url = f"{CLOUD_BASE_URL}/get_android_boot_status/{CLOUD_HOST_IP}/{machine_name}"
        params = {"isblock": 0, "timeout": 10}
        
        Logger.log("🔍 检查Android启动状态", device_name)
        max_attempts = 36  # 最多检查3分钟
        
        for attempt in range(max_attempts):
            try:
                response = requests.get(url, params=params, timeout=15)
                
                if response.status_code == 200:
                    data = response.json()
                    code = data.get('code')
                    msg = data.get('msg', '')
                    
                    if code == 200 and "启动完成" in msg:
                        Logger.log("✅ Android系统启动完成!", device_name)
                        return True
                    elif code == 201 and "启动未完成" in msg:
                        Logger.log(f"📱 Android启动中... ({attempt + 1}/{max_attempts})", device_name)
                        time.sleep(5)
                        continue
                    else:
                        Logger.log(f"❌ Android启动失败: code={code}, msg={msg}", device_name)
                        return False
                else:
                    Logger.log(f"⚠️ HTTP错误: {response.status_code}", device_name)
                    time.sleep(5)
                    continue
                    
            except Exception as e:
                Logger.log(f"⚠️ 检查异常: {e}", device_name)
                time.sleep(5)
                continue
        
        Logger.log("❌ Android启动检查超时", device_name)
        return False
    
    @staticmethod
    def install_apk(machine_name, device_name):
        """安装APK - 修复路径权限问题"""
        encoded_path = urllib.parse.quote(APK_PATH)
        url = f"{CLOUD_BASE_URL}/install_apk/{CLOUD_HOST_IP}/{machine_name}?local={encoded_path}"
        
        try:
            Logger.log("📦 开始安装APK，等待响应...", device_name)
            response = requests.get(url, timeout=120)  # 2分钟超时
            
            if response.status_code == 200:
                data = response.json()
                code = data.get('code')
                msg = data.get('msg', '')
                
                Logger.log(f"📋 安装响应: code={code}, msg={msg}", device_name)
                
                if code == 0 and msg == 'Success':
                    Logger.log("✅ APK安装成功", device_name)
                    return True
                elif "Can't open file" in msg and "/data/" in msg:
                    Logger.log("⚠️ 检测到路径权限问题，尝试修复...", device_name)
                    return CloudAPI.fix_apk_path_and_install(machine_name, device_name, msg)
                else:
                    Logger.log(f"❌ 安装失败: code={code}, msg={msg}", device_name)
                    return False
            else:
                Logger.log(f"❌ HTTP错误: {response.status_code}", device_name)
                return False
                
        except requests.exceptions.Timeout:
            Logger.log("⚠️ 安装请求超时，检查APK是否实际安装成功", device_name)
            return CloudAPI.check_apk_installed(machine_name, device_name)
        except Exception as e:
            Logger.log(f"❌ 安装异常: {e}", device_name)
            return False
    
    @staticmethod
    def uninstall_apk(machine_name, device_name, package_name=SHOPEE_PACKAGE):
        """卸载APK - 使用云服务API接口"""
        url = f"{CLOUD_BASE_URL}/uninstall_apk/{CLOUD_HOST_IP}/{machine_name}/{package_name}"
        
        try:
            Logger.log(f"🗑️ 开始卸载 {package_name}", device_name)
            response = requests.get(url, timeout=60)
            
            if response.status_code == 200:
                data = response.json()
                code = data.get('code')
                msg = data.get('msg', '')
                
                Logger.log(f"📋 卸载响应: code={code}, msg={msg}", device_name)
                
                if code == 200:
                    Logger.log("✅ APK卸载成功", device_name)
                    return True
                elif code == 0:
                    Logger.log("❌ 容器不存在", device_name)
                    return False
                elif code == 1:
                    Logger.log("❌ 主机不通", device_name)
                    return False
                elif code == 2:
                    Logger.log("❌ 当前Android主机未运行", device_name)
                    return False
                elif code == 3:
                    Logger.log("❌ 卸载失败! 请检查Android网络!", device_name)
                    return False
                elif code == 4:
                    Logger.log("❌ 获取容器api 接口失败!", device_name)
                    return False
                else:
                    Logger.log(f"❌ 卸载失败: code={code}, msg={msg}", device_name)
                    return False
            else:
                Logger.log(f"❌ HTTP错误: {response.status_code}", device_name)
                return False
                
        except Exception as e:
            Logger.log(f"❌ 卸载异常: {e}", device_name)
            return False
    
    @staticmethod
    def get_random_devinfo(machine_name, device_name):
        """获取随机设备信息"""
        url = f"{CLOUD_BASE_URL}/random_devinfo_async/{CLOUD_HOST_IP}/{machine_name}"
        
        try:
            Logger.log("🎲 请求随机设备信息", device_name)
            response = requests.get(url, timeout=30)
            
            if response.status_code == 200:
                data = response.json()
                code = data.get('code')
                msg = data.get('msg', '')
                
                Logger.log(f"📋 随机设备信息响应: code={code}, msg={msg}", device_name)
                
                if code == 200:
                    Logger.log("✅ 随机设备信息设置成功", device_name)
                    return True
                elif code == 0:
                    Logger.log("❌ 容器不存在", device_name)
                    return False
                elif code == 1:
                    Logger.log("❌ 主机不通", device_name)
                    return False
                elif code == 2:
                    Logger.log("❌ 当前Android主机未运行", device_name)
                    return False
                elif code == 3:
                    Logger.log("❌ 随机设备信息失败! 请检查Android网络!", device_name)
                    return False
                elif code == 4:
                    Logger.log("❌ 获取容器api 接口失败!", device_name)
                    return False
                else:
                    Logger.log(f"❌ 未知错误: code={code}, msg={msg}", device_name)
                    return False
            else:
                Logger.log(f"❌ HTTP错误: {response.status_code}", device_name)
                return False
                
        except Exception as e:
            Logger.log(f"❌ 随机设备信息请求异常: {e}", device_name)
            return False
    
    @staticmethod
    def fix_apk_path_and_install(machine_name, device_name, error_msg):
        """修复APK路径权限问题并重新安装"""
        try:
            # 从错误信息中提取APK文件名
            match = re.search(r'/data/([^/\s]+\.apk)', error_msg)
            if not match:
                Logger.log("❌ 无法从错误信息中提取APK文件名", device_name)
                return False
            
            apk_filename = match.group(1)
            old_path = f"/data/{apk_filename}"
            new_path = f"/data/local/tmp/{apk_filename}"
            
            Logger.log(f"🔧 移动APK文件: {old_path} → {new_path}", device_name)
            
            # 创建目标目录
            mkdir_success, mkdir_output = CloudAPI.shell_command(machine_name, device_name, "mkdir -p /data/local/tmp")
            if not mkdir_success:
                Logger.log(f"❌ 创建目录失败: {mkdir_output}", device_name)
                return False
            
            # 移动文件
            mv_success, mv_output = CloudAPI.shell_command(machine_name, device_name, f"mv {old_path} {new_path}")
            if not mv_success:
                Logger.log(f"❌ 移动文件失败: {mv_output}", device_name)
                return False
            
            # 设置权限
            chmod_success, chmod_output = CloudAPI.shell_command(machine_name, device_name, f"chmod 644 {new_path}")
            
            # 重新安装APK
            Logger.log("🔄 使用正确路径重新安装APK", device_name)
            install_success, install_output = CloudAPI.shell_command(machine_name, device_name, f"pm install {new_path}")
            
            if install_success and "Success" in install_output:
                Logger.log("✅ APK路径修复后安装成功", device_name)
                
                # 清理文件
                CloudAPI.shell_command(machine_name, device_name, f"rm {new_path}")
                
                return True
            else:
                Logger.log(f"❌ 修复后安装仍失败: {install_output}", device_name)
                return False
                
        except Exception as e:
            Logger.log(f"❌ 修复APK路径异常: {e}", device_name)
            return False
    
    @staticmethod
    def check_apk_installed(machine_name, device_name):
        """检查APK是否已安装 - 使用shell API"""
        Logger.log(f"🔍 检查{SHOPEE_PACKAGE}是否已安装", device_name)
        
        command = f"pm list packages | grep {SHOPEE_PACKAGE}"
        success, output = CloudAPI.shell_command(machine_name, device_name, command)
        
        if success and SHOPEE_PACKAGE in output:
            Logger.log("✅ APK已安装成功", device_name)
            return True
        else:
            Logger.log("❌ APK未安装", device_name)
            return False
    
    @staticmethod
    def run_apk(machine_name, device_name, package_name=SHOPEE_PACKAGE):
        """启动APK"""
        url = f"{CLOUD_BASE_URL}/run_apk/{CLOUD_HOST_IP}/{machine_name}/{package_name}"
        try:
            Logger.log(f"🚀 启动APP: {package_name}", device_name)
            response = requests.get(url, timeout=60)
            
            if response.status_code == 200:
                data = response.json()
                code = data.get('code')
                msg = data.get('msg', '')
                
                Logger.log(f"📋 启动响应: code={code}", device_name)
                
                if code == 200:
                    Logger.log("✅ APP启动成功", device_name)
                    Logger.log(f"⏱️ 等待APP完全加载 {APP_STARTUP_WAIT}秒", device_name)
                    time.sleep(APP_STARTUP_WAIT)
                    return True
                else:
                    Logger.log(f"❌ APP启动失败: code={code}, msg={msg}", device_name)
                    return False
            else:
                Logger.log(f"❌ HTTP错误: {response.status_code}", device_name)
                return False
                
        except Exception as e:
            Logger.log(f"❌ 启动异常: {e}", device_name)
            return False
    
    @staticmethod
    def shell_command(machine_name, device_name, command):
        """执行shell命令 - 使用正确的/shell API接口"""
        url = f"{CLOUD_BASE_URL}/shell/{CLOUD_HOST_IP}/{machine_name}"
        data = {"cmd": command}
        
        try:
            response = requests.post(url, json=data, timeout=30)
            if response.status_code == 200:
                result = response.json()
                code = result.get('code', 0)
                msg = result.get('msg', '')
                shell_code = result.get('shell_code', -1)
                
                if code == 200 and shell_code == 0:
                    return True, msg
                else:
                    return False, msg
            else:
                return False, f"HTTP错误: {response.status_code}"
        except Exception as e:
            return False, f"请求异常: {e}"
    
    @staticmethod
    def adb_deeplink(machine_name, device_name, deeplink):
        """使用shell API执行deeplink"""
        # 标准化链接
        if deeplink.startswith('/'):
            normalized_link = f"https://shopee.tw{deeplink}"
        elif not deeplink.startswith(('http://', 'https://')):
            normalized_link = f"https://shopee.tw/{deeplink.lstrip('/')}"
        else:
            normalized_link = deeplink
        
        command = f"am start -a android.intent.action.VIEW -d '{normalized_link}'"
        
        try:
            Logger.log(f"🔗 Shell访问: {normalized_link[:50]}...", device_name)
            success, output = CloudAPI.shell_command(machine_name, device_name, command)
            
            if success and "Error" not in output:
                Logger.log("✅ 链接访问成功", device_name)
                return True
            else:
                Logger.log(f"❌ 链接访问失败: {output}", device_name)
                return False
        except Exception as e:
            Logger.log(f"❌ 链接访问异常: {e}", device_name)
            return False
    
    @staticmethod
    def adb_screenshot(machine_name, device_name, batch_num, cycle_num):
        """使用shell API截图（简化版本）"""
        try:
            Logger.log(f"📸 Shell截图命令", device_name)
            
            # 截图到设备的/data目录
            timestamp = datetime.datetime.now().strftime("%m%d_%H%M%S")
            remote_path = f"/data/screenshot_{timestamp}.png"
            command = f"screencap -p {remote_path}"
            
            success, output = CloudAPI.shell_command(machine_name, device_name, command)
            
            if success:
                Logger.log(f"✅ 截图已保存到设备: {remote_path}", device_name)
                return remote_path
            else:
                Logger.log(f"❌ 截图命令失败: {output}", device_name)
                return None
        except Exception as e:
            Logger.log(f"❌ 截图异常: {e}", device_name)
            return None

class ADBController:
    """ADB控制类 - 使用shell API"""
    
    @staticmethod
    def click_popup(machine_name, device_name):
        """点击弹窗 - 使用shell API"""
        Logger.log(f"🎯 Shell点击弹窗 ({CLICK_X}, {CLICK_Y})", device_name)
        
        command = f"input tap {CLICK_X} {CLICK_Y}"
        success, output = CloudAPI.shell_command(machine_name, device_name, command)
        
        if success:
            Logger.log("✅ 弹窗点击成功", device_name)
            Logger.log(f"⏱️ 等待弹窗完全过掉 {CLICK_DELAY}秒", device_name)
            time.sleep(CLICK_DELAY)
            Logger.log("✅ 弹窗处理完成", device_name)
            return True
        else:
            Logger.log(f"❌ 弹窗点击失败: {output}", device_name)
            return False

def load_deeplinks():
    """加载deeplinks - 支持纯文本和CSV格式"""
    try:
        with open(DEEPLINK_FILE, encoding='utf-8') as f:
            content = f.read().strip()
            links = []
            
            # 首先尝试按行分割（纯文本格式）
            for line in content.split('\n'):
                line = line.strip()
                if line and line.startswith('http'):
                    links.append(line)
            
            # 如果没有找到链接，尝试CSV格式
            if not links:
                f.seek(0)
                try:
                    reader = csv.DictReader(f)
                    for row in reader:
                        url = row.get('url') or row.get('deeplink') or row.get('link')
                        if url and url.strip():
                            links.append(url.strip())
                except:
                    pass
            
            Logger.log(f"✅ 加载{len(links)}条链接")
            return links if links else ["https://shopee.tw/", "https://shopee.tw/search?keyword=test"]
            
    except Exception as e:
        Logger.log(f"❌ 加载链接失败: {e}")
        return ["https://shopee.tw/", "https://shopee.tw/search?keyword=test"]

def save_progress(device_name, stats):
    """保存进度"""
    try:
        progress_data = {
            'timestamp': time.time(),
            'device': device_name,
            'stats': stats
        }
        progress_file = f"progress_{device_name}.json"
        with open(progress_file, 'w', encoding='utf-8') as f:
            json.dump(progress_data, f, ensure_ascii=False, indent=2)
    except:
        pass

def device_worker(device_info, all_links, stop_event):
    """设备工作线程 - 统一流程版本（每轮都是：安装→启动→测试→卸载）"""
    device_name = device_info["name"]
    machine_id = device_info["id"]
    machine_name = device_info["name"]
    
    stats = {
        'total_cycles': 0,
        'total_tested': 0,
        'total_success': 0,
        'start_time': time.time()
    }
    
    Logger.log(f"🚀 设备工作线程启动", device_name)
    Logger.log(f"📱 设备信息: {device_name}", device_name)
    
    link_index = 0
    
    try:
        while not stop_event.is_set() and link_index < len(all_links):
            stats['total_cycles'] += 1
            
            Logger.log(f"\n{'='*30}", device_name)
            Logger.log(f"🔄 第{stats['total_cycles']}轮测试开始", device_name)
            Logger.log(f"{'='*30}", device_name)
            
            # 步骤1: 安装APK
            Logger.log("1️⃣ 安装Shopee APK", device_name)
            if not CloudAPI.install_apk(machine_name, device_name):
                Logger.log("❌ APK安装失败，跳过本轮", device_name)
                continue
            
            # 步骤2: 启动APP
            Logger.log("2️⃣ 启动Shopee APP", device_name)
            if not CloudAPI.run_apk(machine_name, device_name):
                Logger.log("❌ APP启动失败，跳过本轮", device_name)
                continue
            
            # 步骤3: Shell点击弹窗
            Logger.log("3️⃣ Shell点击弹窗", device_name)
            ADBController.click_popup(machine_name, device_name)
            
            # 步骤4: deeplink测试
            Logger.log("4️⃣ 开始deeplink测试", device_name)
            
            batch_tested = 0
            batch_success = 0
            
            while batch_tested < BATCH_SIZE and link_index < len(all_links) and not stop_event.is_set():
                link = all_links[link_index]
                link_index += 1
                batch_tested += 1
                stats['total_tested'] += 1
                
                Logger.log(f"📍 第{batch_tested}/{BATCH_SIZE}条 (总第{stats['total_tested']}条)", device_name)
                
                # 执行deeplink测试
                if CloudAPI.adb_deeplink(machine_name, device_name, link):
                    batch_success += 1
                    stats['total_success'] += 1
                
                # 在第3条时截图
                if batch_tested == 3:
                    Logger.log("📸 第三条完成，截图", device_name)
                    CloudAPI.adb_screenshot(machine_name, device_name, stats['total_cycles'], batch_tested)
                
                # 验证过的间隔时间
                if batch_tested < BATCH_SIZE and link_index < len(all_links):
                    Logger.log(f"⏱️ 等待{DEEPLINK_INTERVAL}秒后继续", device_name)
                    time.sleep(DEEPLINK_INTERVAL)
            
            # 步骤5: 卸载APP
            Logger.log("5️⃣ 卸载Shopee APP", device_name)
            CloudAPI.uninstall_apk(machine_name, device_name)  # 即使失败也继续
            
            # 步骤6: 请求随机设备信息（除了最后一轮）
            if link_index < len(all_links):
                Logger.log("6️⃣ 请求随机设备信息", device_name)
                CloudAPI.get_random_devinfo(machine_name, device_name)  # 即使失败也继续
            
            # 统计本轮结果
            success_rate = (batch_success / batch_tested * 100) if batch_tested > 0 else 0
            total_success_rate = (stats['total_success'] / stats['total_tested'] * 100) if stats['total_tested'] > 0 else 0
            
            Logger.log(f"📊 第{stats['total_cycles']}轮完成: {batch_tested}条, 成功{batch_success}条({success_rate:.1f}%)", device_name)
            Logger.log(f"📊 累计: {stats['total_tested']}条, 成功{stats['total_success']}条({total_success_rate:.1f}%)", device_name)
            
            # 保存进度
            save_progress(device_name, stats)
            
            # 检查是否还有更多链接
            if link_index >= len(all_links):
                Logger.log("🏁 所有链接测试完成", device_name)
                break
    
    except Exception as e:
        Logger.log(f"❌ 设备线程异常: {e}", device_name)
        import traceback
        Logger.log(f"❌ 异常详情: {traceback.format_exc()}", device_name)
    
    # 最终统计
    elapsed_time = time.time() - stats['start_time']
    Logger.log(f"\n🏁 设备{device_name}测试结束", device_name)
    Logger.log(f"📊 总轮次: {stats['total_cycles']}", device_name)
    Logger.log(f"📊 总测试: {stats['total_tested']}条", device_name)
    Logger.log(f"📊 总成功: {stats['total_success']}条", device_name)
    Logger.log(f"📊 成功率: {(stats['total_success']/stats['total_tested']*100) if stats['total_tested'] > 0 else 0:.1f}%", device_name)
    Logger.log(f"⏱️ 运行时间: {elapsed_time/3600:.1f}小时", device_name)

def main():
    """主函数"""
    stop_event = threading.Event()
    
    def signal_handler(signum, frame):
        Logger.log("🛑 收到中断信号")
        stop_event.set()
    
    signal.signal(signal.SIGINT, signal_handler)
    
    Logger.log("🚀 启动统一流程云机群控脚本")
    Logger.log(f"📡 云服务地址: {CLOUD_BASE_URL}")
    Logger.log(f"🖥️ 主机IP: {CLOUD_HOST_IP}")
    Logger.log(f"📦 APK路径: {APK_PATH}")
    Logger.log(f"⚙️ 批次大小: {BATCH_SIZE}条/轮")
    Logger.log(f"⚙️ 验证过的时间: APP启动{APP_STARTUP_WAIT}秒, 点击后{CLICK_DELAY}秒, deeplink间隔{DEEPLINK_INTERVAL}秒")
    Logger.log("🔄 统一流程: 安装APK → 启动APP → 点击弹窗 → deeplink测试 → 卸载APP → 随机设备信息 → 循环")
    Logger.log("🚀 多设备并行执行，每轮都是相同的完整流程")
    
    # 获取设备列表
    devices = CloudAPI.get_device_list()
    if not devices:
        Logger.log("❌ 未获取到设备列表")
        return
    
    # 筛选running状态的设备
    running_devices = [d for d in devices if d.get('state') == 'running']
    Logger.log(f"✅ 发现{len(running_devices)}个运行中的设备")
    
    if not running_devices:
        Logger.log("❌ 没有运行中的设备")
        return
    
    # 显示设备信息
    for device in running_devices:
        Logger.log(f"📱 设备: {device.get('name', 'Unknown')} - IP: {device.get('ip', 'Unknown')}")
    
    # 加载deeplinks
    all_links = load_deeplinks()
    if not all_links:
        Logger.log("❌ 未找到链接")
        return
    
    try:
        # 启动设备线程
        with ThreadPoolExecutor(max_workers=len(running_devices)) as executor:
            futures = []
            for device in running_devices:
                future = executor.submit(device_worker, device, all_links, stop_event)
                futures.append(future)
                Logger.log(f"✅ 启动设备: {device.get('name', 'Unknown')}")
                time.sleep(10)  # 错开启动
            
            # 等待完成
            for future in futures:
                try:
                    future.result()
                except Exception as e:
                    Logger.log(f"❌ 线程异常: {e}")
        
        Logger.log("🏁 所有测试完成")
        
    except KeyboardInterrupt:
        Logger.log("⏹️ 用户中断")
        stop_event.set()
    except Exception as e:
        Logger.log(f"❌ 程序异常: {e}")

if __name__ == "__main__":
    main()